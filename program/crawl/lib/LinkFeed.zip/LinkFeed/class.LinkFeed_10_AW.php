<?php

require_once 'text_parse_helper.php';
define('API_KEY_10', 'ecbea00d726390bcb40252e4e35436fb');

class LinkFeed_10_AW
{
	function __construct($aff_id,$oLinkFeed)
	{
		$this->oLinkFeed = $oLinkFeed;
		$this->info = $oLinkFeed->getAffById($aff_id);
		$this->debug = isset($oLinkFeed->debug) ? $oLinkFeed->debug : false;
		
		$this->file = "programlog_{$aff_id}_".date("Ymd_His").".csv";
		$this->isRedirect = false;
	}
	
	function LoginDarwin()
	{
		$strDarwinSuccString = "MEGA INFORMATION TECHNOLOGY LIMITED";
		//http://www.affiliatewindow.com/darwinRedirect.php?r=/affiliate/80151
		$request = array("AffId" => $this->info["AffId"],"method" => "get","postdata" => "",);
		$strUrl = "http://www.affiliatewindow.com/darwinRedirect.php?r=/affiliate/80151";
		$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
	echo	$result = $r["content"];
		if(strpos($result, $strDarwinSuccString) !== false)
		{
			echo "we have logined Darwin before.\n";
			return true;
		}
		elseif(strpos($result,"You've been redirected to Darwin") === false)
		{
			mydie("die: redirect to Darwin failed.\n");
		}
		else
		{
			echo "redirect to succ.\n";
		}
		
		exit;
		$request["postdata"] = "email=info%40couponsnapshot.co.uk&password=cluj0c3do9D93D&formuserloginlogin=";
		$request["method"] = "post";
		$strUrl = "https://darwin.affiliatewindow.com/login";
		$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
		$result = $r["content"];
		if(strpos($result,$strDarwinSuccString) === false)
		{
			mydie("die: failed to login Darwin.\n");
		}
		else
		{
			echo "login Darwin succ.\n";
		}
	}

	private function getSoapClient()
	{
		if (empty($this->soapClient))
		{
			$AW_API_NAMESPACE = 'http://api.productserve.com/';
			$oUser = new stdClass();
			$oUser->sApiKey = API_KEY_10;
			$client = new SoapClient('http://v3.core.com.productserve.com/ProductServeService.wsdl', array('trace'=>true, 'compression'=> SOAP_COMPRESSION_ACCEPT | SOAP_COMPRESSION_GZIP | SOAP_COMPRESSION_DEFLATE));
			$oHeader  = new SoapHeader($AW_API_NAMESPACE, 'UserAuthentication', $oUser, true, $AW_API_NAMESPACE);
			$aHeaders = array($oHeader);
			$aHeaders[] = new SoapHeader($AW_API_NAMESPACE, 'getQuota', true, true, $AW_API_NAMESPACE);
			$client->__setSoapHeaders($aHeaders);
			ini_set("soap.wsdl_cache_enabled", 1);
			ini_set('soap.wsdl_cache_ttl', 86400);
			ini_set('default_socket_timeout', 300);
			$this->soapClient = $client;
		}
		return $this->soapClient;
	}
	
	private function loginRedirect()
	{
		if (!$this->isRedirect)
		{
			$this->oLinkFeed->LoginIntoAffService($this->info["AffId"],$this->info);
//			$successString = "/awin/affiliate/80151/navigation/merchants";
			$successString = '/awin/affiliate/80151';
			$request = array("AffId" => $this->info["AffId"], "method" => "get", "postdata" => "",);
			$url = 'https://darwin.affiliatewindow.com/awin/affiliate/80151';
			$r = $this->oLinkFeed->GetHttpResult($url, $request);
			if(strpos($r['content'], $successString) === false)
				mydie("die: failed to Redirect.\n");
			if (preg_match('@href="(.*?)"\s+class=""\s+>\s+Banners\s+</a>\s+</li>@', $r['content'], $g))
			{
				$url = trim($g[1]);
				if (!empty($url))
				{
					$url = 'https://darwin.affiliatewindow.com' . $url;
					$r = $this->oLinkFeed->GetHttpResult($url, $request);
					$this->isRedirect = true;
				}
				else
					mydie("die: failed to Redirect.\n");
			}
			else
				mydie("die: failed to Redirect.\n");
		}
	}
	
	function GetAllLinksFromAffByMerID($merinfo)
	{
		$arr_return = array("AffectedCount" => 0, "UpdatedCount" => 0, "Detail" => array(), );
		$request = array("AffId" => $this->info["AffId"],"method" => "post","postdata" => "",);

		// coupon by api
		// coupon by api get the same data as csv feed ?
		// stopped.
/*
		$client = $this->getSoapClient();
		$params = array('iMerchantId' => $merinfo['IdInAff']);
		$data = $client->getDiscountCodes($params);
		if (!empty($data->oDiscountCode->iMerchantId)) // one result
			$data->oDiscountCode = array(@$data->oDiscountCode);
		$links = array();
		foreach ((array)@$data->oDiscountCode as $v)
		{
			$link = array(
					"AffId" => $this->info["AffId"],
					"AffMerchantId" => $merinfo['IdInAff'],
					"AffLinkId" => '',
					"LinkName" => sprintf('%s', html_entity_decode(@$v->sDescription)),
					"LinkDesc" => '',
					"LinkStartDate" => parse_time_str(@$v->sStartDate, null, false),
					"LinkEndDate" => parse_time_str(@$v->sEndDate, null, false),
					"LinkPromoType" => 'COUPON',
					"LinkHtmlCode" => '',
					"LinkCode" => sprintf('%s', @$v->sCode),
					"LinkAffUrl" => sprintf('%s', @$v->sUrl),
					"LinkOriginalUrl" => "",
					"DataSource" => "63",
			);
			$link['LinkHtmlCode'] = create_link_htmlcode($link);
			if (empty($link['LinkName']) && !empty($link['LinkCode']))
				$link['LinkName'] = sprintf('Use code: %s at %s', $link['LinkCode'], $merinfo['MerchantName']);
			$this->oLinkFeed->fixEnocding($this->info, $link, "feed");
			$link['AffLinkId'] = md5(sprintf("%s_%s_%s_%s", $link['AffMerchantId'], $link['LinkCode'], $link['LinkEndDate'], $link['LinkName']));
			if (empty($link['AffMerchantId']) || empty($link['AffLinkId']) || empty($link['LinkName']))
				continue;
			$links[] = $link;
			$arr_return['AffectedCount'] ++;
		}
		echo sprintf("prgram:%s call api getDiscountCodes...%s result(s) find.\n", $merinfo['IdInAff'], count($links));
		if (count($links) > 0)
			$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);
*/

		// banner & text links by page
		$this->loginRedirect();
		// banner
		$base_url = 'https://www.affiliatewindow.com/affiliates/get_code_all.php?getcode=getcode&mid=%s&bannertab=bannertab&bannertype=1&linktype=1&groups=All';
		$url = sprintf($base_url, $merinfo['IdInAff']);
		$r = $this->oLinkFeed->GetHttpResult($url, $request);
		$content = $r['content'];
		$links = array();
		if (preg_match_all('@<form name="frm\d+">(.*?)</form>@ms', $content, $chapters))
		{
			foreach ((array)$chapters[1] as $chapter)
			{
				$link = array(
						"AffId" => $this->info["AffId"],
						"AffMerchantId" => $merinfo['IdInAff'],
						"LinkDesc" => '',
						"LinkStartDate" => '0000-00-00 00:00:00',
						"LinkEndDate" => '0000-00-00 00:00:00',
						"LinkPromoType" => 'N/A',
						"LinkOriginalUrl" => "",
						"DataSource" => "13",
				);
				if (preg_match('@valign="top"><b>(.*?)</b>@', $chapter, $g))
					$link['LinkName'] = $g[1];
				if (preg_match('@Last Updated:(.*?)<@', $chapter, $g))
					$link['LinkStartDate'] = parse_time_str(trim($g[1]), null, false);
				if (preg_match('@\)"><img src="(.*?)"@', $chapter, $g))
					$link['LinkImageUrl'] = $g[1];
				if (preg_match('@<\!--START MERCHANT:.*?-->\s+(.*?)\s+<\!--END MERCHANT:.*?-->@ms', $chapter, $g))
				{
					$link['LinkHtmlCode'] = $g[1];
					if (preg_match('@s=(\d+)\&@', $g[1], $g1))
						$link['AffLinkId'] = $g1[1];
				}
				$link['LinkPromoType'] = $this->oLinkFeed->getPromoTypeByLinkContent($link['LinkName']);
				if (empty($link['LinkName']) || empty($link['LinkHtmlCode']) || empty($link['AffLinkId']))
					continue;
				$this->oLinkFeed->fixEnocding($this->info, $link, "feed");
				$links[] = $link;
				$arr_return['AffectedCount'] ++;
			}
		}
		echo sprintf("get banner link...%s result(s) find.\n", count($links));
		if (count($links) > 0)
			$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);

		// text
		$base_url = 'https://www.affiliatewindow.com/affiliates/get_code_all.php?mid=%s&getcode=getcode&linkingmethod=3&linkname=Text&linktype=23';
		$url = sprintf($base_url, $merinfo['IdInAff']);
		$r = $this->oLinkFeed->GetHttpResult($url, $request);
		$content = $r['content'];
		$links = array();
		if (preg_match_all('@<textarea(.*?)</textarea>@ms', $content, $chapters))
		{
			foreach ((array)$chapters[1] as $key => $chapter)
			{
				if (preg_match('@<\!--START MERCHANT:@', $chapter, $g))
					continue;
				if (preg_match('@">(.*?)</textarea>@ms', $chapters[0][$key], $g))
					$text = html_entity_decode(trim($g[1]));
				else
					continue;
				$link = array(
						"AffId" => $this->info["AffId"],
						"AffMerchantId" => $merinfo['IdInAff'],
						"LinkDesc" => '',
						"LinkStartDate" => '0000-00-00 00:00:00',
						"LinkEndDate" => '0000-00-00 00:00:00',
						"LinkPromoType" => 'N/A',
						"LinkOriginalUrl" => "",
						"DataSource" => "13",
				);
				$link['LinkName'] = strip_tags($text);
				$link['LinkHtmlCode'] = $text;
				if (preg_match('@\&linkid=(\d+)\&@', $text, $g))
					$link['AffLinkId'] = $g[1];
				$link['LinkPromoType'] = $this->oLinkFeed->getPromoTypeByLinkContent($link['LinkName']);
				$code = get_linkcode_by_text($link['LinkName']);
				if (!empty($code))
				{
					$link['LinkCode'] = $code;
					$link['LinkPromoType'] = 'coupon';
				}
				if (empty($link['LinkName']) || empty($link['LinkHtmlCode']) || empty($link['AffLinkId']))
					continue;
				$this->oLinkFeed->fixEnocding($this->info, $link, "feed");
				$links[] = $link;
				$arr_return['AffectedCount'] ++;
			}
		}
		echo sprintf("get text link...%s result(s) find.\n", count($links));
		if (count($links) > 0)
			$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);

		return $arr_return;
	}

	function getCouponFeed()
	{
		// csv feed.
		$arr_return = array("AffectedCount" => 0,"UpdatedCount" => 0,"Detail" => array(),);
		$request = array("AffId" => $this->info["AffId"], "method" => "get","postdata" => "",);
		$url = "http://www.affiliatewindow.com/affiliates/discount_vouchers.php?user=80151&password=46d151f42ac6e0db6fbc1cf29edfcba2&export=csv";
		$r = $this->oLinkFeed->GetHttpResult($url, $request);
		$content = $r['content'];
		$data = @fgetcsv_str($content);
		$links = array();
		foreach ((array)$data as $v)
		{
			$link = array(
					"AffId" => $this->info["AffId"],
					"AffMerchantId" => $v['merchant_id'],
					"AffLinkId" => '',
					"LinkName" => sprintf('%s', @$v['description']),
					"LinkDesc" => '',
					"LinkStartDate" => parse_time_str(@$v['start_date']),
					"LinkEndDate" => parse_time_str(@$v['end_date']),
					"LinkPromoType" => 'COUPON',
					"LinkHtmlCode" => '',
					"LinkOriginalUrl" => "",
					"LinkImageUrl" => "",
					"LinkCode" => sprintf('%s', @$v['code']),
					"LinkAffUrl" => sprintf('%s', @$v['url']),
					"DataSource" => "13",
			);
			
			if ($link['LinkCode'] == '******')
				continue;
			if ($this->oLinkFeed->getPromoTypeByLinkContent($link['LinkName']) == 'free shipping')
				$link['LinkPromoType'] = 'free shipping';
			$link['LinkHtmlCode'] = create_link_htmlcode($link);
			if (empty($link['LinkName']) && !empty($link['LinkCode']))
				$link['LinkName'] = sprintf('%s. Use code: %s', @$v['program_name'], $link['LinkCode']);
			$link['AffLinkId'] = md5(sprintf("%s_%s_%s_%s", $link['AffMerchantId'], $link['LinkCode'], $link['LinkEndDate'], $link['LinkName']));
			if (empty($link['AffMerchantId']) || empty($link['AffLinkId']) || empty($link['LinkName']))
				continue;
			$this->oLinkFeed->fixEnocding($this->info, $link, "feed");
			$links[] = $link;
			$arr_return['AffectedCount'] ++;
			if (empty($link['LinkCode']) && $link['LinkPromoType'] != 'free shipping')
			{
				$emptys[] = $link;
				continue;
			}
			if (($arr_return['AffectedCount'] % 100) == 0)
			{
				$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);
				$links = array();
			}
		}
		echo sprintf("get coupon by csv...%s result(s) find.\n", $arr_return['AffectedCount']);
		if (count($links) > 0)
			$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);
		return $arr_return;
	}

	function GetProgramFromAff()
	{
		$check_date = date("Y-m-d H:i:s");
		echo "Craw Program start @ {$check_date}\r\n";
		$this->GetProgramByPage();
		$this->checkProgramOffline($this->info["AffId"], $check_date);
		echo "Craw Program end @ ".date("Y-m-d H:i:s")."\r\n";
	}

	function GetProgramByPage()
	{
		echo "\tGet Program by page start\r\n";
		$objProgram = new ProgramDb();
		$arr_prgm = array();
		$program_num = 0;
		$request = array("AffId" => $this->info["AffId"],"method" => "get","postdata" => "",);

		//step 1,login
		//$this->oLinkFeed->clearHttpInfos($this->info["AffId"]);//re-login each time		
		$this->oLinkFeed->LoginIntoAffService($this->info["AffId"],$this->info);
		//$this->LoginDarwin();

		//step 2,get SupportDeepurl
		$str_url = "https://darwin.affiliatewindow.com/user/redirect/v1/type/affiliate/r/YWZmaWxpYXRlcy9jdXN0b21pc2VfbGluay5waHA%3D/id/80151";
		$tmp_arr = $this->oLinkFeed->GetHttpResult($str_url, $request);
		$result = $tmp_arr["content"];
		$result = trim($this->oLinkFeed->ParseStringBy2Tag($result, array('Select Advertiser', '<select', 'name="merchantId"', '>'), '</select>'));
		$matches = array();
		preg_match_all('/value="(\d*)"/', $result, $matches);
		$hasSupportDeepurl = false;
		$SupportDeepurl_arr = array();
		if(count($matches) && isset($matches[1]) && count($matches[1]) > 100){
			$hasSupportDeepurl = true;
			$SupportDeepurl_arr = array_flip($matches[1]);
		}

		//step 3, get programs from csv feed.
		$allstatus = array(
			"active" => "approval",
			"notJoined" => "not apply",
			"pendingApproval" => "pending",
			"merchantSuspended" => "declined",
			"merchantRejected" => "declined",
			"closed" => "siteclosed",
		);
		$title = '"advertiserId","programmeName"';
		foreach($allstatus as $status_aff => $status)
		{
			$cache_file = $this->oLinkFeed->fileCacheGetFilePath($this->info["AffId"],"$status_aff" . ".dat","cache_merchant");
			if(!$this->oLinkFeed->fileCacheIsCached($cache_file))
			{
				$request["method"] = "get";
				$strUrlAllMerchant = "http://darwin.affiliatewindow.com/affiliate/80151/merchant-directory/export/?membershipStatus=" . $status_aff . "&view=+";
				$r = $this->oLinkFeed->GetHttpResult($strUrlAllMerchant,$request);
				$result = $r["content"];
				if(stripos($result,$title) === false)
				{
					print_r($r);
					mydie("die: get merchant csv file failed, title not found \n");
				}
				$this->oLinkFeed->fileCachePut($cache_file,$result);
			}
			if(!file_exists($cache_file)) mydie("die: merchant csv file does not exist. \n");

			//Open CSV File
			$arr_title = array();
			$col_count = 0;
			$fhandle = fopen($cache_file, 'r');
			$first = true;
			while($line = fgetcsv($fhandle, 50000))
			{
				if($first)
				{
					// [0] => advertiserId [1] => programmeName [2] => conversionRate [3] => approvalRate [4] => validationTime [5] => epc [6] => joinDate [7] => paymentStatus [8] => paymentRiskLevel [9] => awinIndex [10] => feedEnabled [11] => productReporting [12] => commissionMin [13] => commissionMax [14] => leadMin [15] => leadMax [16] => cookieLength [17] => parentSectors [18] => subSectors [19] => primarySector 
					if($line[0] != 'advertiserId') mydie("die: title is wrong. \n");
					$arr_title = $line;
					$col_count = sizeof($arr_title);
					$first = false;
					continue;
				}
				if($line[0] == '' || $line[0] == 'advertiserId') continue;
				if(sizeof($line) != $col_count)
				{
					echo "warning: invalid line found: " . implode(",",$line) . "\n";
					continue;
				}
				$row = array();
				foreach($arr_title as $i => $title)
					$row[$title] = $line[$i];

				$prgm_url = "https://darwin.affiliatewindow.com/awin/affiliate/80151/merchant-profile/{$row["advertiserId"]}";
				$request["method"] = "get";
				$request["postdata"] = "";
				$prgm_arr = $this->oLinkFeed->GetHttpResult($prgm_url, $request);
				$prgm_detail = $prgm_arr["content"];
				$MobileFriendly = 'UNKNOWN';
				if (preg_match('@<h4>Mobile Optimised</h4>\s+<div.*?>\s+(.*?)\s+<@', $prgm_detail, $g))
				{
					if (strtoupper($g[1]) == 'YES')
						$MobileFriendly = 'YES';
					else if (strtoupper($g[1]) == 'NO')
						$MobileFriendly = 'NO';
				}
				$desc = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, '<div id="descriptionLongContent" class="accountDescription inlineTextArea">', '</div>'));
				$Homepage = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('id="website"', 'href="'), '"'));
				$tmp_contacts = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('Email', '"mailto:'), '"'));
				$Contacts = "";
				if($tmp_contacts){
					$Contacts = "Email: {$tmp_contacts}";
				}

				$term_url = "https://darwin.affiliatewindow.com/awin/affiliate/80151/merchant-profile-terms/{$row["advertiserId"]}";
				$term_arr = $this->oLinkFeed->GetHttpResult($term_url, $request);
				$term_detail = $term_arr["content"];
				$TermAndCondition = trim($this->oLinkFeed->ParseStringBy2Tag($term_detail, '<div id="termsFreeTextContent" class="inlineTextArea">', '</div>'));

				if($status_aff == "active"){
					$Partnership = "Active";
					$StatusInAff = "Active";
				}elseif($status_aff == "notJoined"){
					$Partnership = "NoPartnership";
					$StatusInAff = "Active";
				}elseif($status_aff == "pendingApproval"){
					$Partnership = "Pending";
					$StatusInAff = "Active";
				}elseif($status_aff == "merchantSuspended" || $status_aff == "merchantRejected"){
					$Partnership = "Declined";
					$StatusInAff = "Active";
				}else{
					$Partnership = "NoPartnership";
					$StatusInAff = "Offline";
				}

				$check_status_url = "https://www.affiliatewindow.com/affiliates/get_code_all.php?getcode=getcode&mid={$row["advertiserId"]}&summarytab=summarytab&groups=All&linktype=3&parenttype=3";
				$status_arr = $this->oLinkFeed->GetHttpResult($check_status_url, $request);
				$status_detail = $status_arr["content"];
				if(stripos($status_detail, "Invalid merchant ID") !== false)
					$StatusInAff = 'Offline';

				$arr_prgm[$row["advertiserId"]] = array(
					"Name" => addslashes(html_entity_decode(trim($row["programmeName"]))),
					"AffId" => $this->info["AffId"],
					"Contacts" => addslashes($Contacts),
					"IdInAff" => $row["advertiserId"],
					"JoinDate" => date("Y-m-d H:i:s", strtotime($row["joinDate"])),
					"StatusInAffRemark" => $status_aff,
					"StatusInAff" => $StatusInAff,						//'Active','TempOffline','Offline'
					"Partnership" => $Partnership,						//'NoPartnership','Active','Pending','Declined','Expired','WeDeclined'
					"Description" => addslashes($desc),
					"Homepage" => $Homepage,
					"CookieTime" => addslashes($row["cookieLength"]),
					"EPCDefault" => $row["epc"],
					"TermAndCondition" => addslashes($TermAndCondition),
					"LastUpdateTime" => date("Y-m-d H:i:s"),
					"DetailPage" => $prgm_url,
					"CommissionExt" => addslashes(implode('-', array_filter(array($row['commissionMin'], $row['commissionMax'])))),
					"MobileFriendly" => $MobileFriendly,
				);
				if($hasSupportDeepurl){
					$SupportDeepurl = 'NO';
					if(isset($SupportDeepurl_arr[$row["advertiserId"]])){
						$SupportDeepurl = 'YES';
					}
					$arr_prgm[$row["advertiserId"]]["SupportDeepUrl"] = $SupportDeepurl;
				}
				$program_num++;
				if(count($arr_prgm) >= 100){
					$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
					$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
					$arr_prgm = array();
				}
			}
			if(count($arr_prgm)){
				$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
				$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
				$arr_prgm = array();
			}
		}
		echo "\tGet Program by api end\r\n";
		if($program_num < 10){
			mydie("die: program count < 10, please check program.\n");
		}
		echo "\tUpdate ({$program_num}) program.\r\n";
		echo "\tSet program country int.\r\n";
		$objProgram->setCountryInt($this->info["AffId"]);
	}

	function checkProgramOffline($AffId, $check_date){
		$objProgram = new ProgramDb();
		$prgm = array();
		$prgm = $objProgram->getNotUpdateProgram($this->info["AffId"], $check_date);

		if(count($prgm) > 30){
			mydie("die: too many offline program (".count($prgm).").\n");
		}else{
			$objProgram->setProgramOffline($this->info["AffId"], $prgm);
			echo "\tSet (".count($prgm).") offline program.\r\n";
		}
	}
}

