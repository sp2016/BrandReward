<?php

require_once 'text_parse_helper.php';
define('API_KEY_115', 'b40ae5f6e26e496a848fd8066c02e5c2');

class LinkFeed_115_Commission_Factory
{
	function __construct($aff_id,$oLinkFeed)
	{
		$this->oLinkFeed = $oLinkFeed;
		$this->info = $oLinkFeed->getAffById($aff_id);
		$this->debug = isset($oLinkFeed->debug) ? $oLinkFeed->debug : false;
		
		$this->file = "programlog_{$aff_id}_".date("Ymd_His").".csv";
		$this->password = "Y7P%267Bf7w0jy8";
	}
	
	function Login()
	{
		$strUrl = "https://dashboard.commissionfactory.com.au/LogIn/";
		$request = array(
			"method" => "get",
			"postdata" => "",
		);
		$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
		$result = $r["content"];
		$__EVENTVALIDATION = urlencode($this->oLinkFeed->ParseStringBy2Tag($result, array('name="__EVENTVALIDATION"', 'value="'), '"'));
		$__VIEWSTATE = urlencode($this->oLinkFeed->ParseStringBy2Tag($result, array('name="__VIEWSTATE"', 'value="'), '"'));

		$strUrl = "https://dashboard.commissionfactory.com.au/LogIn/";
		$request = array(
			"AffId" => $this->info["AffId"],
			"method" => "post",
			"postdata" => "",
		);
		$request["postdata"] = "__ASYNCPOST=true&__EVENTARGUMENT=&__EVENTTARGET=&__EVENTVALIDATION={$__EVENTVALIDATION}&__VIEWSTATE={$__VIEWSTATE}&ctl00%24cphBody%24btnLogIn=Log%20In&ctl00%24cphBody%24txtPassword={$this->password}&ctl00%24cphBody%24txtUsername=couponsnapshot&ctl00%24ctl05=ctl00%24ctl05%7Cctl00%24cphBody%24btnLogIn";		
		$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
		$result = $r["content"];
		if(stripos($result,'Affiliate') === false)
		{
			mydie("die: failed to login.\n");
		}
		else
		{
			echo "login succ.\n";
		}
	}
	
	function GetMerchantListFromAff()
	{
		$arr_return = array("AffectedCount" => 0,"UpdatedCount" => 0);
		$request = array("AffId" => $this->info["AffId"],"method" => "get","postdata" => "");

		//step 2,get all exists merchant
		$arrAllExistsMerchants = $this->oLinkFeed->GetAllExistsAffMerIDForCheckByAffID($this->info["AffId"]);

		$strUrl = sprintf("https://api.commissionfactory.com.au/V1/Affiliate/Merchants?apiKey=%s", API_KEY_115);
		$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
		$result = $r["content"];

		$result = json_decode($result);

		foreach($result as $v){
			$strMerID = intval($v->Id);
			if($strMerID < 1) continue;

			$strMerName = trim($v->Name);
			$strStatus = trim($v->Status);
			
			if($strStatus == "Joined"){
				$strStatus = "approval";
			}elseif($strStatus == "Pending"){
				$strStatus = "pending";
			}elseif($strStatus == "Not Joined"){
				$strStatus = "not apply";
			}else{
				$strStatus = "siteclosed";
			}
			$arr_return["AffectedCount"] ++;
			$arr_update = array(
				"AffMerchantId" => $strMerID,
				"AffId" => $this->info["AffId"],
				"MerchantName" => $strMerName,
				"MerchantEPC30d" => "",
				"MerchantEPC" => "",
				"MerchantStatus" => $strStatus,	//'not apply','pending','approval','declined','expired','siteclosed'
				"MerchantRemark" => ""
			);
			$this->oLinkFeed->fixEnocding($this->info,$arr_update,"merchant");
			//print_r($arr_update);
			if($this->oLinkFeed->UpdateMerchantToDB($arr_update,$arrAllExistsMerchants))
				$arr_return["UpdatedCount"] ++;
		}
		$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateAllExistsAffMerIDButCannotFetched($this->info["AffId"], $arrAllExistsMerchants);
		return $arr_return;
	}
	
	function getCouponFeed()
	{	
		$arr_return = array("AffectedCount" => 0,"UpdatedCount" => 0,"Detail" => array());
		$request = array("AffId" => $this->info["AffId"],"method" => "get","postdata" => "");
			
		$all_merchant = $this->oLinkFeed->getAllAffMerchant($this->info["AffId"]);
		$arrToUpdate = array();
		
		$strUrl = sprintf("https://api.commissionfactory.com.au/V1/Affiliate/Coupons?apiKey=%s", API_KEY_115);
		$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
		$result = $r["content"];
		
		$result = json_decode($result);
		
		foreach($result as $v){
			$link_id = intval($v->Id);
			if($link_id < 1) continue;
			
//<EndDate i:nil="true"/>
			
			$aff_mer_id = trim($v->MerchantId);
			if(!isset($all_merchant[$aff_mer_id])) continue;
			
			$link_name  = trim($v->MerchantName);
			$link_desc  = trim($v->Description);
			$html_code 	= trim($v->TrackingCode);
			$promo_type = "coupon";
			$couponcode = trim($v->Code);
			$LinkOriginalUrl = trim($v->TargetUrl);
			$LinkAffUrl = trim($v->TrackingUrl);
			
			if ($couponcode == "NA") $couponcode = "";
			
			if ($couponcode != '') $link_desc .= '. Coupon Code: '.$couponcode;
			
			$start_date = "0000-00-00 00:00:00";
			if(isset($v->StartDate) && $v->StartDate > 0){
				$start_date = trim($v->StartDate);
				$start_date = date("Y-m-d H:i:s", strtotime($start_date));
			}
			
			$end_date = "0000-00-00 00:00:00";
			if(isset($v->EndDate) && $v->EndDate > 0){
				$end_date  	= trim($v->EndDate);
				$end_date = date("Y-m-d H:i:s", strtotime($end_date));
			}
			
			$arr_one_link = array(
				"AffId" => $this->info["AffId"],
				"AffMerchantId" => $aff_mer_id,
				"AffLinkId" => $link_id,
				"LinkName" =>  $link_name,
				"LinkDesc" =>  $link_desc,
				"LinkStartDate" => $start_date,
				"LinkEndDate" => $end_date,
				"LinkPromoType" => $promo_type,
				"LinkHtmlCode" => $html_code,
				"LinkCode" => $couponcode,
				"LinkOriginalUrl" => $LinkOriginalUrl,
				"LinkImageUrl" => '',
				"LinkAffUrl" => $LinkAffUrl,
				"DataSource" => 53,
			);

			$this->oLinkFeed->fixEnocding($this->info,$arr_one_link,"feed");
			$arrToUpdate[] = $arr_one_link;
			$arr_return["AffectedCount"] ++;
			if(!isset($arr_return["Detail"][$aff_mer_id]["AffectedCount"]))
				$arr_return["Detail"][$aff_mer_id]["AffectedCount"] = 0;
			$arr_return["Detail"][$aff_mer_id]["AffectedCount"] ++;
			if(sizeof($arrToUpdate) > 100)
			{
				$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($arrToUpdate);
				$arrToUpdate = array();
			}
		}
		
		if(sizeof($arrToUpdate) > 0)
		{
			$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($arrToUpdate);
			$arrToUpdate = array();
		}
		return $arr_return;
	}
	
	function GetAllLinksFromAffByMerID($merinfo)
	{
		$aff_id = $this->info["AffId"];
		$arr_return = array("AffectedCount" => 0, "UpdatedCount" => 0, );
		$request = array("AffId" => $this->info["AffId"], "method" => "get", "postdata" => "", );
		
		$url = sprintf('https://api.commissionfactory.com.au/V1/Affiliate/Banners?apiKey=%s&merchantId=%s', API_KEY_115, $merinfo['IdInAff']);
		$r = $this->oLinkFeed->GetHttpResult($url, $request);
		if (empty($r) || empty($r['code']) || $r['code'] != 200 || empty($r['content']))
			return $arr_return;
		$content = $r['content'];
		$data = @json_decode($content, true);
		if (empty($data) || !is_array($data))
			return $arr_return;
		$links = array();
		foreach ($data as $v)
		{
			$link = array(
					"AffId" => $this->info["AffId"],
					"AffMerchantId" => $merinfo['IdInAff'],
					"AffLinkId" => $v['Id'],
					"LinkName" => $v['Name'],
					"LinkDesc" => $v['AltText'],
					"LinkStartDate" => parse_time_str($v['DateModified'], 'Y-m-d H:i:s', false),
					"LinkEndDate" => '0000-00-00',
					"LinkPromoType" => 'N/A',
					"LinkOriginalUrl" => "",
					"LinkHtmlCode" => $v['TrackingCode'],
					"LinkAffUrl" => $v['TrackingUrl'],
					"DataSource" => "53",
			);
			$link['LinkPromoType'] = $this->oLinkFeed->getPromoTypeByLinkContent($link['LinkName']);
			if (empty($link['AffLinkId']) || empty($link['LinkName']))
				continue;
			$arr_return['AffectedCount'] ++;
			$links[] = $link;
		}
		echo sprintf("%s link(s) found. sleep 5 secound...\n", count($links));
		sleep(5);
		if (count($links) > 0)
			$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);
		return $arr_return;
	}

	function GetProgramFromAff()
	{
		$check_date = date("Y-m-d H:i:s");
		echo "Craw Program start @ {$check_date}\r\n";

		$this->GetProgramFromByApi();
		$this->checkProgramOffline($this->info["AffId"], $check_date);

		echo "Craw Program end @ ".date("Y-m-d H:i:s")."\r\n";
	}
	
	function GetProgramFromByPage()
	{
		echo "\tGet Program by page start\r\n";
		$program_num = 0;

		//step 1,login
		//$this->oLinkFeed->LoginIntoAffService($this->info["AffId"],$this->info);
		$this->Login();
		
		//login
		/*$strUrl = "https://dashboard.commissionfactory.com.au/LogIn/";
		$request = array(
			"method" => "get",
			"postdata" => "",
		);
		$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
		$result = $r["content"];	
		$__EVENTVALIDATION = urlencode($this->oLinkFeed->ParseStringBy2Tag($result, array('name="__EVENTVALIDATION"', 'value="'), '"'));	
		$__VIEWSTATE = urlencode($this->oLinkFeed->ParseStringBy2Tag($result, array('name="__VIEWSTATE"', 'value="'), '"'));		
		
		$strUrl = "https://dashboard.commissionfactory.com.au/LogIn/";
		$request = array(
			"AffId" => $this->info["AffId"],
			"method" => "post",
			"postdata" => "",
		);
		$request["postdata"] = "__ASYNCPOST=true&__EVENTARGUMENT=&__EVENTTARGET=&__EVENTVALIDATION={$__EVENTVALIDATION}&__VIEWSTATE={$__VIEWSTATE}&ctl00%24cphBody%24btnLogIn=Log%20In&ctl00%24cphBody%24txtPassword=90xierHJ%5E%26&ctl00%24cphBody%24txtUsername=couponsnapshot&ctl00%24ctl05=ctl00%24ctl05%7Cctl00%24cphBody%24btnLogIn";		
		$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);*/
		
		//get para
		$strUrl = "http://dashboard.commissionfactory.com.au/Affiliate/Merchants/";
		$request = array(
			"AffId" => $this->info["AffId"],
			"method" => "get",
			"postdata" => "",
		);	
		$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
		$result = $r["content"];	
	
		$__EVENTVALIDATION = urlencode($this->oLinkFeed->ParseStringBy2Tag($result, array('name="__EVENTVALIDATION"', 'value="'), '"'));	
		$__VIEWSTATE = urlencode($this->oLinkFeed->ParseStringBy2Tag($result, array('name="__VIEWSTATE"', 'value="'), '"'));
	
		//	PageSize:50
		//  PageIndex:1
		

		$objProgram = new ProgramDb();
		$arr_prgm = array();
		
		echo "\tGet New Offer\r\n";
		$nNumPerPage = 10;
		$bHasNextPage = true;
		$nPageNo = 1;		
		while($bHasNextPage){
			$strUrl = "http://dashboard.commissionfactory.com.au/Affiliate/Merchants/";
			$start = $nPageNo - 1;
			$request = array(
				"AffId" => $this->info["AffId"],
				"method" => "post",
				"postdata" => "",
			);
			$request["postdata"] = "__ASYNCPOST=true&__EVENTARGUMENT=PageIndex%3A{$start}&__EVENTTARGET=ctl00%24ctl00%24cphBody%24cphBody%24pgeMerchants&__EVENTVALIDATION={$__EVENTVALIDATION}&__LASTFOCUS=&__VIEWSTATE={$__VIEWSTATE}&ctl00%24ctl00%24cphBody%24cphBody%24lstCategory=0&ctl00%24ctl00%24cphBody%24cphBody%24lstStatus=0&ctl00%24ctl00%24cphBody%24cphBody%24lstType=0&ctl00%24ctl00%24cphBody%24cphBody%24txtSearch=&ctl00%24ctl00%24ctl05=ctl00%24ctl00%24ctl05%7Cctl00%24ctl00%24cphBody%24cphBody%24pgeMerchants";			
			$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
			$result = $r["content"];
			
			$total = intval($this->oLinkFeed->ParseStringBy2Tag($result, array('<div id="cphBody_cphBody_pgeMerchants">', '</select>', 'of'), '('));
			if(($nPageNo) >= $total){
				$bHasNextPage = false;
			}

			$result = explode("|", $result);
			//print_r($result);

			$program_list = "";
			foreach($result as $v){
				if(stripos($v, '<table class="grid" cellpadding="0" cellspacing="0">') !== false){
					$program_list = $v;
					break;
				}
			}
			$strLineStart = '<span class="tooltip">';

			$nLineStart = 0;
			while ($nLineStart >= 0){
				$nLineStart = stripos($program_list, $strLineStart, $nLineStart);
				if ($nLineStart === false) break;

				$desc = $this->oLinkFeed->ParseStringBy2Tag($program_list, '<span class="content">', '<a style="color: #ffffff; ', $nLineStart);
				$Homepage = $this->oLinkFeed->ParseStringBy2Tag($program_list, 'href="', '"', $nLineStart);
				$strMerName = $this->oLinkFeed->ParseStringBy2Tag($program_list, '<td>', '<br />', $nLineStart);
				$Category = $this->oLinkFeed->ParseStringBy2Tag($program_list, '<span style="color: #808080;">', '</span>', $nLineStart);
				$Commission = $this->oLinkFeed->ParseStringBy2Tag($program_list, '<td class="nowrap">', '</td>', $nLineStart);
				$JoinDate = $this->oLinkFeed->ParseStringBy2Tag($program_list, '<td class="right">', '</td>', $nLineStart);
				$strMerID = $this->oLinkFeed->ParseStringBy2Tag($program_list, array('<td class="nowrap">','href="'), '/"', $nLineStart);
				$StatusInAffRemark = $this->oLinkFeed->ParseStringBy2Tag($program_list, '>', '</a></td>', $nLineStart);
				
				if($StatusInAffRemark == 'Joined'){
					$Partnership = 'Active';
				}elseif($StatusInAffRemark == 'Pending'){
					$Partnership = 'Pending';
				}else{
					$Partnership = 'NoPartnership';
				}

				$JoinDate = str_replace('/', '-', $JoinDate);
				$JoinDate = date("Y-m-d H:i:s", strtotime($JoinDate));
				$prgm_url = "http://dashboard.commissionfactory.com.au/Affiliate/Merchants/{$strMerID}/";

				$arr_prgm[$strMerID] = array(
					"Name" => addslashes(trim($strMerName)),
					"AffId" => $this->info["AffId"],
					"Homepage" => $Homepage,
					"IdInAff" => $strMerID,
					"JoinDate" => $JoinDate,
					"StatusInAffRemark" => addslashes($StatusInAffRemark),
					"StatusInAff" => 'Active',						//'Active','TempOffline','Offline'
					"Partnership" => $Partnership,				//'NoPartnership','Active','Pending','Declined','Expired','Removed'
					"Description" => addslashes($desc),
					"LastUpdateTime" => date("Y-m-d H:i:s"),
					"DetailPage" => $prgm_url,
				);
				$program_num++;

				if(count($arr_prgm) >= 100){
					$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
					$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
					$arr_prgm = array();
				}
			}
			$nPageNo++;
		}
		if(count($arr_prgm)){
			$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
			$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
			unset($arr_prgm);
		}
		echo "\tGet Program by page end\r\n";
		if($program_num < 10){
			mydie("die: program count < 10, please check program.\n");
		}
		echo "\tUpdate ({$program_num}) program.\r\n";
		echo "\tSet program country int.\r\n";
		$objProgram->setCountryInt($this->info["AffId"]);
	}

	function GetProgramFromByApi()
	{
		echo "\tGet Program by api start\r\n";

		$this->Login();
		$objProgram = new ProgramDb();
		$arr_prgm = array();
		$program_num = 0;

		$request = array("AffId" => $this->info["AffId"],"method" => "get","postdata" => "");
		$strUrl = "https://api.commissionfactory.com.au/V1/Affiliate/Merchants?apiKey=b40ae5f6e26e496a848fd8066c02e5c2";
		$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
		$result = $r["content"];

		$result = json_decode($result);

		foreach($result as $v){
			$strMerID = intval($v->Id);
			if($strMerID < 1) continue;

			$strMerName = trim($v->Name);
			$Homepage = trim($v->TargetUrl);
			$CategoryExt = trim($v->Category);
			$StatusInAffRemark = trim($v->Status);
			$desc = trim($v->Summary);
			$CommissionExt = trim($v->CommissionRate) . " " . trim($v->CommissionType);
			$AffDefaultUrl = trim($v->TrackingUrl);

			$JoinDate = trim($v->DateCreated);
			$JoinDate = date("Y-m-d H:i:s", strtotime($JoinDate));

			if($StatusInAffRemark == "Joined"){
				$StatusInAff = "Active";
				$Partnership = "Active";
			}elseif($StatusInAffRemark == "Pending"){
				$strStatus = "Active";
				$Partnership = "Pending";
			}elseif($StatusInAffRemark == "Not Joined"){
				$strStatus = "Active";
				$Partnership = "NoPartnership";
			}else{
				$strStatus = "Active";
				$Partnership = "NoPartnership";
			}
			$prgm_url = "http://dashboard.commissionfactory.com.au/Affiliate/Merchants/{$strMerID}/";
			$prgm_arr = $this->oLinkFeed->GetHttpResult($prgm_url,$request);
			$prgm_detail = $prgm_arr["content"];

			$custom_commission = $this->oLinkFeed->ParseStringBy2Tag($prgm_detail, 'Custom Commission Rate', 'Description');
			$custom_commission = trim(strip_tags($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, 'Custom Commission Rate', 'Description')));
			//$custom_commission = str_replace(PHP_EOL, '', $custom_commission);
			$custom_commission = str_replace(array("\r", "\n", "\t"), "", $custom_commission);

			if($custom_commission){
				$CommissionExt = $custom_commission;
			}

			$arr_prgm[$strMerID] = array(
				"Name" => addslashes(trim($strMerName)),
				"AffId" => $this->info["AffId"],
				"Homepage" => $Homepage,
				"CategoryExt" => $CategoryExt,
				"IdInAff" => $strMerID,
				"JoinDate" => $JoinDate,
				"CommissionExt" => addslashes($CommissionExt),
				"StatusInAffRemark" => addslashes($StatusInAffRemark),
				"StatusInAff" => 'Active',						//'Active','TempOffline','Offline'
				"Partnership" => $Partnership,				//'NoPartnership','Active','Pending','Declined','Expired','Removed'
				"Description" => addslashes($desc),
				"LastUpdateTime" => date("Y-m-d H:i:s"),
				"DetailPage" => $prgm_url,
				"SupportDeepUrl" => 'YES',
				"AffDefaultUrl" => addslashes($AffDefaultUrl)
			);
			$program_num++;

			if(count($arr_prgm) >= 100){
				$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
				$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
				$arr_prgm = array();
			}
		}
		if(count($arr_prgm)){
			$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
			$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
			unset($arr_prgm);
		}

		echo "\tGet Program by api end\r\n";
		if($program_num < 10){
			mydie("die: program count < 10, please check program.\n");
		}
		echo "\tUpdate ({$program_num}) program.\r\n";
		echo "\tSet program country int.\r\n";
		$objProgram->setCountryInt($this->info["AffId"]);
	}
	
	function checkProgramOffline($AffId, $check_date){
		$objProgram = new ProgramDb();
		$prgm = array();
		$prgm = $objProgram->getNotUpdateProgram($this->info["AffId"], $check_date);
		if(count($prgm) > 30){
			mydie("die: too many offline program (".count($prgm).").\n");
		}else{
			$objProgram->setProgramOffline($this->info["AffId"], $prgm);
			echo "\tSet (".count($prgm).") offline program.\r\n";
		}
	}
}

