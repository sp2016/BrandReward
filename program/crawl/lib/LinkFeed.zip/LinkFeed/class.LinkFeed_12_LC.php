<?php

require_once 'text_parse_helper.php';
define('API_KEY_12', '21fcc451660cc5561a2ca3af6a049fac');

class LinkFeed_12_LC
{
	function __construct($aff_id,$oLinkFeed)
	{
		$this->oLinkFeed = $oLinkFeed;
		$this->info = $oLinkFeed->getAffById($aff_id);
		$this->debug = isset($oLinkFeed->debug) ? $oLinkFeed->debug : false;
		
		$this->file = "programlog_{$aff_id}_".date("Ymd_His").".csv";
	}
	
	function LoginIntoAffService()
	{
		//get para __VIEWSTATE and then process default login
		if(!isset($this->info["AffLoginPostStringOrig"])) $this->info["AffLoginPostStringOrig"] = $this->info["AffLoginPostString"];
		
		$request = array(
			"AffId" => $this->info["AffId"],
			"method" => "post",
			"postdata" => "",
		);

		$strUrl = $this->info["AffLoginUrl"];
		$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
		$result = $r["content"];
		
		$arr_hidden_name = array(
			"curdate" => "",
			"loginkey" => "",
		);
		
		$pattern = "/<input name=\\\"(.*)\\\" value=\\\"(.*)\\\" type=\\\"hidden\\\">/iu";
		if(!preg_match_all($pattern,$result,$matches)) mydie("die: LoginIntoAffService failed curdate not found\n");

		foreach($matches[1] as $i => $name)
		{
			if(isset($arr_hidden_name[$name])) $arr_hidden_name[$name] = $matches[2][$i];
		}
		
		foreach($arr_hidden_name as $name => $value)
		{
			if(empty($value)) mydie("die: LoginIntoAffService failed $name not found\n");
		}

		$this->getLoginCheckCode($arr_hidden_name);

		$arr_replace_from = array();
		$arr_replace_to = array();
		foreach($arr_hidden_name as $name => $value)
		{
			$arr_replace_from[] = "{" . $name . "}";
			$arr_replace_to[] = $value;
		}
		
		$this->info["AffLoginPostString"] = str_replace($arr_replace_from,$arr_replace_to,$this->info["AffLoginPostStringOrig"]);
		$this->oLinkFeed->LoginIntoAffService($this->info["AffId"],$this->info,2,true,true,false);
		return "stophere";
	}
	
	function getLoginCheckCode(&$arr)
	{
		$t2 = strrev("123" . $arr["loginkey"] . $arr["curdate"]);
		$t = "";
		for($i=0;$i<strlen($t2);$i+=3)  $t .= $t2[$i];
		for($i=0;$i<strlen($t2);$i+=2)  $t .= $t2[$i];
		$arr["dest"] = substr($t,0,32);
	}

	function getCouponFeed()
	{
		$arr_return = array("AffectedCount" => 0, "UpdatedCount" => 0, "Detail" => array(), );
		$request = array("AffId" => $this->info["AffId"], "method" => "post", "postdata" => "",);
		$links = array();
		// get promotion from api.
		// get coupon from csv feed is discard. login and use the url like this.
		// $url = 'https://www.linkconnector.com/member/coupons_feeds.php?key=VERSGgBDBmlfPVBnADdUZwNl&saveAs=true&types=CFOD&rptcols=,,0,2,3,4,5,6,8,9,10';
		// currently use the api to get the promotion data.
		// the api returns more records than the csv feed, and returns program id other than csv feed.
		$url = "http://www.linkconnector.com/api/";
		$request['postdata'] = array("Key" => API_KEY_12, "Function" => "getFeedPromotion");
		$r = $this->oLinkFeed->GetHttpResult($url, $request);
		$content = $r['content'];
		$data = @csv_string_to_array($content);
		$count = 0;
		foreach ((array)$data as $v)
		{
			$link = array(
					"AffId" => $this->info["AffId"],
					"AffMerchantId" => sprintf('%s_%s', $v['MerchantID'], $v['CampaignID']),
					"AffLinkId" => sprintf('%s', $v['PromoID']),
					"LinkName" => $v['HeadLineTitle'],
					"LinkDesc" => '',
					"LinkStartDate" => parse_time_str($v['Entry Date'], null, false),
					"LinkEndDate" => parse_time_str($v['Expires'], null, true),
					"LinkPromoType" => 'COUPON',
					"LinkHtmlCode" => $v['Banner'],
					"LinkOriginalUrl" => '',
					"LinkImageUrl" => '',
					"LinkAffUrl" => $v['TrackingURL'],
					"DataSource" => "10",
			);
			if ($v['PromoType'] == 'FreeShipping')
				$link['LinkPromoType'] = 'free shipping';
			if ($v['Scope'] == 'Private')
				$link['LinkDesc'] .= '|Scope: Private';
			if (empty($link['LinkName']) || empty($link['AffMerchantId']) || empty($link['AffLinkId']))
				continue;
			$this->oLinkFeed->fixEnocding($this->info, $link, "feed");
			$arr_return["AffectedCount"] ++;
			$count ++;
			$links[] = $link;
			if (($arr_return['AffectedCount'] % 100) == 0 && count($links) > 0)
			{
				$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);
				$links = array();
			}
		}
		echo sprintf("call api getFeedPromotion... %s links(s) found. \n", $count);

		// text or banner links and deep links
		$request = array("AffId" => $this->info["AffId"], "method" => "post", "postdata" => "",);
		$url = "http://www.linkconnector.com/api/";
		$functions = array('getLinkDeep', 'getLinkHTML');
		foreach ($functions as $function)
		{
			$count = 0;
			$request['postdata'] = array("Key" => API_KEY_12, "Function" => $function);
			$r = $this->oLinkFeed->GetHttpResult($url, $request);
			$content = $r['content'];
			$data = @csv_string_to_array($content);
			foreach ((array)$data as $v)
			{
				$link = array(
						"AffId" => $this->info["AffId"],
						"AffMerchantId" => sprintf('%s_%s', $v['MerchantID'], $v['CampaignID']),
						"AffLinkId" => sprintf('%s', @$v['LinkID']),
						"LinkName" => @$v['LinkName'],
						"LinkDesc" => '',
						"LinkStartDate" => '0000-00-00',
						"LinkEndDate" => '0000-00-00',
						"LinkPromoType" => 'N/A',
						"LinkHtmlCode" => @$v['HTMLCode'],
						"LinkOriginalUrl" => '',
						"LinkImageUrl" => '',
						"LinkAffUrl" => '',
						"DataSource" => "10",
				);
				if ($function == 'getLinkDeep')
				{
					$link['AffLinkId'] = sprintf('deep_%s_%s', $v['MerchantID'], $v['CampaignID']);
					$link['LinkName'] = sprintf('Deep link of %s - %s', $v['Merchant'], $v['Campaign']);
					$link['LinkAffUrl'] = $v['DeepLinkURL'];
					$link['LinkHtmlCode'] = create_link_htmlcode($link);
				}
				else
				{
					if (preg_match('@a href="(.*?)"@', $link['LinkHtmlCode'], $g))
						$link['LinkAffUrl'] = $g[1];
					if (preg_match('@img src="(.*?)"@', $link['LinkHtmlCode'], $g))
						$link['LinkImageUrl'] = $g[1];
				}
				$link['LinkPromoType'] = $this->oLinkFeed->getPromoTypeByLinkContent($link['LinkName']);
				if (empty($link['AffLinkId']) || empty($link['LinkName']) || empty($link['LinkHtmlCode']) || empty($link['AffMerchantId']))
					continue;
				$this->oLinkFeed->fixEnocding($this->info, $link, "feed");
				$arr_return["AffectedCount"] ++;
				$count ++;
				$links[] = $link;
				if (($arr_return['AffectedCount'] % 100) == 0 && count($links) > 0)
				{
					$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);
					$links = array();
				}
			}
			echo sprintf("call api %s... %s links(s) found. \n", $function, $count);
		}
		if(count($links) > 0)
			$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);

		return $arr_return;
	}

	function getInvalidLinks()
	{
		$request = array("AffId" => $this->info["AffId"], "method" => "get", "postdata" => "",);
		$url = 'https://www.linkconnector.com/member/reports.htm?rpt=invalidclick&ddPeriod=Last_3_weeks&s_sort=0&s_order=desc&Display=250';
		$this->oLinkFeed->LoginIntoAffService($this->info["AffId"], $this->info, 1, false);
		$r = $this->oLinkFeed->GetHttpResult($url, $request);
		$content = $r['content'];
		if (preg_match('@<tbody class="lcTable lcTableReport">(.*?)</tbody>@ms', $content, $g))
			$content = $g[1];
		preg_match_all('@<tr id="row\d+" class="lcTable lcTableReport tblRow\d+">(.*?)</tr>@ms', $content, $chapters);
		$links = array();
		foreach ((array)$chapters[1] as $chapter)
		{
			preg_match_all('@<td style="text-align:left;" class="lcTable lcTableReport.*?>(.*?)</td>@ms', $chapter, $g);
			if (empty($g) || empty($g[1]) || !is_array($g[1]) || count($g[1]) != 6)
				continue;
			$link = array(
					'affiliate' => $this->info["AffId"],
					'LinkID' => '',
					'ReferralUrl' => trim($g[1][2]),
					'ProgramName' => trim(html_entity_decode($g[1][4])),
					'OccuredDate' => parse_time_str(trim($g[1][0]), null, false),
					'Reason' => str_force_utf8(trim(html_entity_decode($g[1][1]))),
			);
			if ($link['ReferralUrl'] == 'N/A')
				$link['ReferralUrl'] = '';
			if (preg_match('@a.*?href="(.*?lid=(\d+))@', $g[1][5], $a))
			{
				$link['LinkID'] = $a[2];
				$link['Details'] = str_force_utf8(trim(html_entity_decode(strip_tags($g[1][5]))));
			}
			if (empty($link['LinkID']))
				continue;
			$links[] = $link;
		}
		return $links;
	}

	function getMessage()
	{
		$messages = array();
		$request = array("AffId" => $this->info["AffId"], "method" => "get", "postdata" => "",);
		$this->oLinkFeed->LoginIntoAffService($this->info["AffId"], $this->info);
		$url = 'https://www.linkconnector.com/member/home.htm';
		$r = $this->oLinkFeed->GetHttpResult($url, $request);
		$content = $r['content'];
		if (preg_match('@<div class="tblHeadTitle">\s+Messages(.*?)<div class="tblHeadTitle">@ms', $content, $g));
			$content = $g[1];
		preg_match_all('@<tr class="lcTable lcTableList">(.*?)</tr>@ms', $content, $chapters);
		foreach ((array)$chapters[1] as $chapter)
		{
			$data = array(
					'affid' => $this->info["AffId"],
					'messageid' => '',
					'sender' => '',
					'title' => '',
					'content' => '',
					'created' => '0000-00-00',
			);
			if (preg_match('@<a href="(.*?msgID=(\d+))".*?>(.*?)</a>@ms', $chapter, $g))
			{
				$data['content_url'] = $g[1];
				$data['title'] = trim(html_entity_decode(strip_tags($g[3])));
				$data['messageid'] = $g[2];
			}
			else
				continue;
			$messages[] = $data;
		}
		return $messages;
	}

	function getMessageDetail($data)
	{
		$request = array("AffId" => $this->info["AffId"], "method" => "get", "postdata" => "",);
		$this->oLinkFeed->LoginIntoAffService($this->info["AffId"], $this->info);
		$url = $data['content_url'];
		$r = $this->oLinkFeed->GetHttpResult($url, $request);
		$content = $r['content'];
		if (preg_match('@<td class="msgDate">(.*?)<@ms', $content, $g))
			$data['created'] = parse_time_str(trim($g[1]), null, false);
		if (preg_match('@<td class="msgText".*?>(.*?)</td>@ms', $content, $g))
			$data['content'] = str_force_utf8(html_entity_decode($g[1]));
		return $data;
	}

	function GetAllLinksFromAffByMerID($merinfo)
	{
		$arr_return = array("AffectedCount" => 0, "UpdatedCount" => 0, );
		return $arr_return;
	}

	function getProgramCategory()
	{
		global $mer_cat;
		if(count($mer_cat)) return $mer_cat;
		$categoryUrl = "https://www.linkconnector.com/member/list.htm";
		$request = array(
			"AffId" => $this->info["AffId"],
			"method" => "post",
			"postdata" => "", 
		);
		$request["postdata"] = "refreshvariable=true";
		$r = $this->oLinkFeed->GetHttpResult($categoryUrl,$request);
		$result = $r["content"];
	
		$category_arr = array();
		$cate_tmp = $this->oLinkFeed->ParseStringBy2Tag($result ,array('select','ddCategory','>'), '</select>');
		$cate_tmp = preg_replace("/[\\r|\\n|\\r\\n|\\t]/is", '', $cate_tmp);
		$cate_tmp = explode("</option>", $cate_tmp);
		
		foreach($cate_tmp as $v){
			$cat_id = $this->oLinkFeed->ParseStringBy2Tag($v , '<option value = "', '"');
			if(empty($cat_id)) continue;
			$cat_val = $this->oLinkFeed->ParseStringBy2Tag($v , '>');
			$category_arr[$cat_id] = $cat_val;
		}		
		//print_r($category_arr);
		
		foreach($category_arr as $cat_id => $cat_val){
			$nNumPerPage = 100;
			$bHasNextPage = true;
			$nPageNo = 1;
			
			$categoryUrl = "https://www.linkconnector.com/member/list.htm";
			while($bHasNextPage)
			{
				$request["postdata"] = "refreshvariable=true&Page=".$nPageNo."&ddCategory=$cat_id&ddDisplay=".$nNumPerPage."&ddDisplay=".$nNumPerPage;
				$r = $this->oLinkFeed->GetHttpResult($categoryUrl,$request);
				$result = $r["content"];
				
				//parse HTML
				$nLineStart = 0;
				$nTotalPage = $this->oLinkFeed->ParseStringBy2Tag($result, array('per page | Page:','&nbsp;&nbsp;of '), '</td>', $nLineStart);
				if($nTotalPage === false) mydie("die: nTotalPage not found\n");
				$nTotalPage = intval($nTotalPage);
				if($nTotalPage < $nPageNo) break;
				
				$nLineStart = 0;
				$nTmpNoFound = stripos($result, 'No Records Found', $nLineStart);
				if($nTmpNoFound !== false) break;
				
				$strLineStart = '<tr class="lcTable lcTableReport tblRow';

				$nLineStart = 0;
				$bStart = true;
				$item_count = 0;
				while ($nLineStart >= 0)
				{
					//print "Process $Cnt  ";
					$nLineStart = stripos($result, $strLineStart, $nLineStart);
					if ($nLineStart === false) break;
					
					$strMerName = $this->oLinkFeed->ParseStringBy2Tag($result, '<td style="text-align:center;" class="lcTable lcTableReport tblCellFirst">', '&nbsp;', $nLineStart);
					if($strMerName === false) break;
					$strMerName = trim(html_entity_decode($strMerName));
					
					$mer_cat[$strMerName] = $cat_val;
				}
				
				$nPageNo++;
				if ($nTotalPage < $nPageNo) break;
			}
		}
		
		return $mer_cat;
	}
	
	function getProgramByStatus($status)
	{
		$arr_return = array("AffectedCount" => 0,"UpdatedCount" => 0,);
		$request = array(
			"AffId" => $this->info["AffId"],
			"method" => "post",
			"postdata" => "", 
		);
		
		$objProgram = new ProgramDb();
		$arr_prgm = array();
		
		echo "get $status merchants for LC\n";
		$nNumPerPage = 100;
		$bHasNextPage = true;
		$nPageNo = 1;
		
		$cnt = 0;
		
		$mer_cat = array();
		$mer_cat = $this->getProgramCategory();
		//print_r($mer_cat);		

		$strUrl = "https://www.linkconnector.com/member/amerchants.htm?Type=" . $status;
		while($bHasNextPage)
		{
			/*if($nPageNo == 1)
			{
				$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
				$result = $r["content"];
			}
			else
			{
				$request["postdata"] = "refreshvariable=true&Page=".$nPageNo."&s_sort=&s_order=&ddMerchants=&ddCampaignStatus=Active&ddDisplay=".$nNumPerPage."&ddDisplay=".$nNumPerPage;
				$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
				$result = $r["content"];
			}
			*/
			$request["postdata"] = "refreshvariable=true&Page=".$nPageNo."&s_sort=&s_order=&ddMerchants=&ddCampaignStatus=Active&ddDisplay=".$nNumPerPage."&ddDisplay=".$nNumPerPage;
			$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
			$result = $r["content"];		

			print "Get $status Merchant List : Page: $nPageNo  <br>\n";

			//parse HTML
			$nLineStart = 0;
			$nTotalPage = $this->oLinkFeed->ParseStringBy2Tag($result, array('per page | Page:','&nbsp;&nbsp;of '), '</td>', $nLineStart);
			if($nTotalPage === false) mydie("die: nTotalPage not found\n");
			$nTotalPage = intval($nTotalPage);
			if($nTotalPage < $nPageNo) break;
			
			$nLineStart = 0;
			$nTmpNoFound = stripos($result, 'No Records Found', $nLineStart);
			if($nTmpNoFound !== false) break;

			$strLineStart = '<tr class="lcTable lcTableReport tblRow';

			$nLineStart = 0;
			$bStart = true;
			$item_count = 0;
			while ($nLineStart >= 0)
			{
				//print "Process $Cnt  ";
				$nLineStart = stripos($result, $strLineStart, $nLineStart);
				if ($nLineStart === false) break;
				// Merchant Campaign 	Campaign Type 	Events 	7 EPC 	90 EPC 	# Approved Websites 	Actions

				$item_count ++;
				echo "item_count=$item_count","\n";
				//name
				$strMerName = $this->oLinkFeed->ParseStringBy2Tag($result, '<td style="text-align:center;" class="lcTable lcTableReport tblCellFirst">', '</td>', $nLineStart);
				if($strMerName === false) break;
				$strMerName = html_entity_decode(trim($strMerName));
				
				//category
				$CategoryExt = isset($mer_cat[$strMerName]) ? $mer_cat[$strMerName] : "";			
				
				//ID
				$strCampID = $this->oLinkFeed->ParseStringBy2Tag($result, 'campaigns.htm?cid=', '&mid=', $nLineStart);
				if($strCampID === false) break;
				$strCampID = trim($strCampID);

				$strMerID = $this->oLinkFeed->ParseStringBy2Tag($result, '&mid=', "',", $nLineStart);
				if($strMerID === false) break;
				$strMerID = trim($strMerID);
				if($strMerID == "")
				{
					echo "warning: strMerID not found\n";
					continue;
				}
				
				$mer_detail_url = "https://www.linkconnector.com/member/campaigns.htm?cid=$strCampID&mid=$strMerID";
				
				$strMerID = $strMerID.'_'.$strCampID;

				$strCampName = $this->oLinkFeed->ParseStringBy2Tag($result, array('OnMouseOut', '">'), '</a>', $nLineStart);
				if($strCampName === false) break;
				if($strMerName == "")
				{
                                        echo "warning: strMerName not found\n";
                                        continue;
                                }
				
				$strCampName = html_entity_decode(trim($strCampName));
				$strMerName = $strMerName . ' - '. $strCampName;
				
				$strEPC = $strEPC90d = -1;
				$strEvents = "";
				
				if($status == "Sum")
				{
					$tofind = '<td style="text-align:center;white-space:nowrap" class="lcTable lcTableReport">';
					$strEvents = $this->oLinkFeed->ParseStringBy2Tag($result,$tofind,'</td>', $nLineStart);
					if($strEvents === false)
					{
						echo "warning: strEvents not found\n";
						continue;
					}
					$strEPC = $this->oLinkFeed->ParseStringBy2Tag($result,$tofind, '</td>', $nLineStart);
					if($strEPC === false)
					{       
						echo "warning: strEPC not found\n";
						continue;
					}
					
					$strEPC90d = $this->oLinkFeed->ParseStringBy2Tag($result,$tofind, '</td>', $nLineStart);
					if($strEPC90d === false)
					{       
						echo "warning: strEPC30d not found\n";
						continue;
					}
	
					$strEPC = trim($strEPC);
					$strEPC90d = trim($strEPC90d);
					$this->active_programs[] = $strMerID;
				}
				
				if($status == "Pending"){
					if (!empty($this->active_programs) && in_array($strMerID, $this->active_programs))
					{
						echo sprintf("program id: %s, name: %s is in active program list and ignore.\n", $strMerID, $strMerName);
						continue;
					}
					$Partnership = 'Pending';
					$StatusInAff = "Active";
				}
				elseif($status == "Declined"){
					$Partnership = 'Declined';
					$StatusInAff = "Active";
				}
				elseif($status == "Dropped"){
					$Partnership = 'NoPartnership';
					$StatusInAff = "Offline";
				}
				elseif($status == "Sum"){
					$Partnership = 'Active';
					$StatusInAff = "Active";
				}
				else{
					mydie("die: wrong status($status)");
				}
				
				//program
				//commission
				$CommissionExt = trim($strEvents);
				//EPCDefault 7d
				$EPCDefault = $strEPC;
				//EPC90d
				$EPC90d = $strEPC90d;
				
				//program_detail				
				$prgm_url = $mer_detail_url;
				$prgm_arr = $this->oLinkFeed->GetHttpResult($prgm_url, $request);
				$prgm_detail = $prgm_arr["content"];
				
				$prgm_line = 0;
				$prgm_campname = $this->oLinkFeed->ParseStringBy2Tag($prgm_detail,array('Campaign:','<td style="font-weight:bold;text-align:left" class="lcTable lcTableForm tblCellLast">'),'</td>', $prgm_line);
				$prgm_camptype = $this->oLinkFeed->ParseStringBy2Tag($prgm_detail,array('Campaign Type:','<td style="font-weight:bold;text-align:left" class="lcTable lcTableForm tblCellLast">'),'</td>', $prgm_line);
				$Homepage = $this->oLinkFeed->ParseStringBy2Tag($prgm_detail,array('Website:','<td style="font-weight:bold;text-align:left" class="lcTable lcTableForm tblCellLast">'),'</td>', $prgm_line);
				$JoinDate = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail,array('Start Date:','<td style="font-weight:bold;text-align:left" class="lcTable lcTableForm tblCellLast">'),'</td>', $prgm_line));			
				if($JoinDate){
					//$JoinDate = date("Y-m-d H:i:s", strtotime($JoinDate));
					$JoinDate_tmp = $JoinDate;
					$JoinDate = substr($JoinDate_tmp, 6, 4) . "-" . substr($JoinDate_tmp, 0, 2) . "-" .substr($JoinDate_tmp, 3, 2) . " " . "00:00:00";
				}
				
				//$prgm_end = $this->oLinkFeed->ParseStringBy2Tag($prgm_detail,array('End Date:','<td style="font-weight:bold;text-align:left" class="lcTable lcTableForm tblCellLast">'),'</td>', $prgm_line);
				$prgm_status = $this->oLinkFeed->ParseStringBy2Tag($prgm_detail,array('Status:','<td style="font-weight:bold;text-align:left" class="lcTable lcTableForm tblCellLast">'),'</td>', $prgm_line);
				
				$desc = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, "<span style='font-weight:bold'>Description: </span>", '</td>', $prgm_line));
				$TermAndCondition = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array("<span style='font-weight:bold'>Campaign Terms and Conditions: </span>", '<table style="margin:8px 0px">'), '</table>', $prgm_line));
				$ReturnDays = $this->oLinkFeed->ParseStringBy2Tag($prgm_detail,array('Expire Tracking',"<div style='border:none;'>"),'</div>', $prgm_line);
				
				$SEMPolicyExt = "";
				$sem_tmp = $this->oLinkFeed->ParseStringBy2Tag($prgm_detail,array('Search Engine Marketing Allowed:','<td style="vertical-align:top;">'),'</td>');
				if($sem_tmp){
					$SEMPolicyExt = "Search Engine Marketing Allowed:" . $sem_tmp;					
				}
				$sem_tmp = $this->oLinkFeed->ParseStringBy2Tag($prgm_detail,array('Search Engine Marketing Restrictions:','<td style="vertical-align:top;">'),'</td>');
				if($sem_tmp){
					$SEMPolicyExt .= "Search Engine Marketing Restrictions:" . $sem_tmp;					
				}
				
				$TermAndCondition = preg_replace("/[\\r|\\n|\\r\\n|\\t]/is", '', $TermAndCondition);
				$TermAndCondition = explode("</tr><tr>", $TermAndCondition);
				
				foreach($TermAndCondition as $k => $v){
					if(stripos($v, "Search Engine Marketing Allowed") || stripos($v, "Search Engine Marketing Restrictions")){
						unset($TermAndCondition[$k]);
					}
					if($v == '<td style="vertical-align:top;"></td>'){
						unset($TermAndCondition[$k]);
					}
				}
				$TermAndCondition = "<table>".implode("</tr><tr>", $TermAndCondition)."</table>";
			
				$arr_prgm[$strMerID] = array(
					"Name" => addslashes(html_entity_decode(trim($strMerName))),
					"AffId" => $this->info["AffId"],
					"IdInAff" => $strMerID,
					"StatusInAff" => $StatusInAff,						//'Active','TempOffline','Offline'
					"StatusInAffRemark" => addslashes($status),
					"Partnership" => $Partnership,						//'NoPartnership','Active','Pending','Declined','Expired','WeDeclined'
					"JoinDate" => $JoinDate,
					"CategoryExt" => $CategoryExt,
					//"CreateDate" => $prgm_start,
					//"DropDate" => $prgm_end,
					"SEMPolicyExt" => addslashes($SEMPolicyExt),
					"Description" => addslashes($desc),
					"Homepage" => addslashes($Homepage),
					"CommissionExt" => addslashes($CommissionExt),
					"EPCDefault" => addslashes(preg_replace("/[^0-9.]/", "", $EPCDefault)),
					"EPC90d" => addslashes(preg_replace("/[^0-9.]/", "", $EPC90d)),
					"CookieTime" => $ReturnDays,					
					"TermAndCondition" => addslashes($TermAndCondition),					
					"LastUpdateTime" => date("Y-m-d H:i:s"),
					"DetailPage" => $prgm_url,
				);
				$cnt++;
				//print_r($arr_prgm);
				//exit;
				if(count($arr_prgm) >= 200){
					$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
					$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
					$arr_prgm = array();
				}
			}
			
			if(count($arr_prgm)){
				$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
				$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
				$arr_prgm = array();
			}

			$nPageNo++;
			if ($nTotalPage < $nPageNo) break;
		}//per page
		if(count($arr_prgm)){
			$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
			$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
			$arr_prgm = array();
		}
		
		//$objProgram->setProgramOffline($this->info["AffId"]);
		$objProgram->setCountryInt($this->info["AffId"]);
		
		return $cnt;
	}
	
	function GetProgramByPage()
	{
		echo "\tGet Program by page start\r\n";		
		$program_num = 0;
		//step 1,login
		$this->oLinkFeed->LoginIntoAffService($this->info["AffId"],$this->info,1,false);
		
		// some program in pending lists, but also in active lists, save the list of active program, and ignore when in pending list
		$this->active_programs = array();

		//step 2,get all exists merchant
		//$arrAllExistsMerchants = $this->oLinkFeed->GetAllExistsAffMerIDForCheckByAffID($this->info["AffId"]);
		
		//$arrStatus4List = array("Sum","Pending","Declined","Dropped");
		//ike 20101127, their Declined page is wrong? contains many dup merchants??
		$arrStatus4List = array("Sum","Pending");
		foreach($arrStatus4List as $status)
		{
			$program_num += $this->getProgramByStatus($status);		
		}
		
		echo "\tGet Program by page end\r\n";
		
		if($program_num < 10){
			mydie("die: program count < 10, please check program.\n");
		}
		
		echo "\tUpdate ({$program_num}) program.\r\n";		
	}
	
	function GetProgramFromAff()
	{	
		$check_date = date("Y-m-d H:i:s");
		echo "Craw Program start @ {$check_date}\r\n";
		
		$this->GetProgramByPage();		
		$this->checkProgramOffline($this->info["AffId"], $check_date);

		echo "Craw Program end @ ".date("Y-m-d H:i:s")."\r\n";
	}
	
	function checkProgramOffline($AffId, $check_date){		
		$objProgram = new ProgramDb();
		$prgm = array();
		$prgm = $objProgram->getNotUpdateProgram($this->info["AffId"], $check_date);
		
		if(count($prgm) > 30){
			mydie("die: too many offline program (".count($prgm).").\n");
		}else{			
			$objProgram->setProgramOffline($this->info["AffId"], $prgm);
			echo "\tSet (".count($prgm).") offline program.\r\n";
		}
	}
}
?>
