<?php

require_once 'text_parse_helper.php';

class LinkFeed_152_Belboon
{
	var $info = array(
		"ID" => "152",
		"Name" => "Belboon",
		"IsActive" => "YES",
		"ClassName" => "LinkFeed_152_Belboon",
		"LastCheckDate" => "1970-01-01",
	);
	
	function __construct($aff_id,$oLinkFeed)
	{
		$this->oLinkFeed = $oLinkFeed;
		$this->info = $oLinkFeed->getAffById($aff_id);
		$this->debug = isset($oLinkFeed->debug) ? $oLinkFeed->debug : false;
		
		$this->file = "programlog_{$aff_id}_".date("Ymd_His").".csv";
		$this->soapClient = null;
	}
	
	function GetAllLinksFromAffByMerID($merinfo)
	{
		$arr_return = array("AffectedCount" => 0, "UpdatedCount" => 0, "Detail" => array(), );
		return $arr_return;
	}
	
	private function getSoapClient()
	{
		if (!$this->soapClient)
		{
			$config = array('login' => 'couponsnapshot', 'password' => 'jU3QXucpWBKsgfPr5jzs', 'trace' => true);
			$client  = new SoapClient("http://api.belboon.com/?wsdl", $config);
			$this->soapClient = $client;
		}
		return $this->soapClient;
	}

	// the soap call failed often.
	// try another 2 times when failed.
	private function soapCall_152($method)
	{
		$args = func_get_args();
		array_shift($args);
		$client = $this->getSoapClient();
		$handler = array($client, $method);
		$retry = 3;
		$r = null;
		do 
		{
			$retry --;
			try
			{
				$r = call_user_func_array($handler, $args);
			}
			catch (Exception $e)
			{
				echo sprintf("Exception raised: %s, Retry:%s\n", $e->getMessage(), $retry);
			}
		}while($retry >= 0 && empty($r));
		return $r;
	}

	function getCouponFeed()
	{
		$arr_return = array("AffectedCount" => 0,"UpdatedCount" => 0,"Detail" => array());
		$request = array("AffId" => $this->info["AffId"], "method" => "get", "postdata" => "");

		// coupon by api
		$platformIds = array(576890, 576894);	//DE-576894
		$limit = 100;
		foreach ($platformIds as $platformId)
		{
			$page = 0;
			do
			{
				$links = array();
				// api params:
				// adPlatformIds programId query hasPartnership voucherCode voucherType validFrom validTo orderBy limit offset
				$r = $this->soapCall_152('getVoucherCodes', array($platformId), null, null, true, null, null, null, null, array('programId'=> 'ASC'), $limit, $limit * $page);
				if(empty($r) || empty($r->handler) || empty($r->handler->voucherCodes) || !is_array($r->handler->voucherCodes) || count($r->handler->voucherCodes) < 1)
					break;
				foreach($r->handler->voucherCodes as $v)
				{
					$link = array(
							"AffId" => $this->info["AffId"],
							"AffMerchantId" => $v['programid'],
							"AffLinkId" => $v['id'],
							"LinkName" => trim(html_entity_decode($v['name'])),
							"LinkDesc" => trim(html_entity_decode($v['voucherdescription'])),
							"LinkStartDate" => parse_time_str($v['voucherstart']),
							"LinkEndDate" => parse_time_str($v['voucherend']),
							"LinkPromoType" => 'COUPON',
							"LinkHtmlCode" => trim(html_entity_decode($v['publishercode'])),
							"LinkCode" => $v['vouchercode'],
							"LinkOriginalUrl" => "",
							"LinkImageUrl" => '',
							"LinkAffUrl" => '',
							"DataSource" => 54,
					);
					if (empty($link['LinkName']))
					{
						$link['LinkName'] = sprintf('%s Coupon.', trim(html_entity_decode($v['programname'])));
						if (!empty($link['LinkCode']))
							$link['LinkName'] .= sprintf('Use Code: %s', $link['LinkCode']);
					}
					if (preg_match('@a href="(.*?)"@', $link['LinkHtmlCode'], $g))
						$link['LinkAffUrl'] = $g[1];
					if (empty($link['AffMerchantId']) || empty($link['AffLinkId']))
						continue;
					$this->oLinkFeed->fixEnocding($this->info, $link, "feed");
					$links[] = $link;
					$arr_return["AffectedCount"] ++;
				}
				echo sprintf("get link form api(voucherCodes)...platformId:%s, page:%s, %s link(s) found.\n", $platformId, $page, count($links));
				if (count($links) > 0)
					$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);
				$page++;
			}while ($page < 1000);
		}

		// links by api.
		// stopped. the api Maximum of requests per hour reached.
		// changed to get the links form the page in the GetAllLinksFromAffByMerID function
		/*
		foreach ($platformIds as $platformId)
		{
			$page = 0;
			do
			{
				$links = array();
				// api params: 
				// adPlatformIds, hasPartnership, programId, adType, adWidth, adHeight, orderBy, limit, offset
				$r = $this->soapCall_152('searchCommonAds', array($platformId), true, null, null, null, null, array('programId'=> 'ASC'), $limit, $limit * $page);
				if(empty($r) || empty($r->handler) || empty($r->handler->commonAds) || !is_array($r->handler->commonAds) || count($r->handler->commonAds) < 1)
					break;
				foreach($r->handler->commonAds as $v)
				{
					if (empty($v['adid']))
						continue;
					$link = array(
							"AffId" => $this->info["AffId"],
							"AffMerchantId" => $v['programid'],
							"AffLinkId" => $platformId . "_" . $v['adid'],
							"LinkName" => trim(html_entity_decode($v['adname'])),
							"LinkDesc" => trim(html_entity_decode($v['linktext'])),
							"LinkStartDate" => '0000-00-00',
							"LinkEndDate" => '0000-00-00',
							"LinkPromoType" => 'DEAL',
							"LinkHtmlCode" => trim(html_entity_decode($v['adcodecomplete'])),
							"LinkCode" => '',
							"LinkOriginalUrl" => "",
							"LinkImageUrl" => $v['viewimgurl'],
							"LinkAffUrl" => $v['linkurl'],
							"DataSource" => 54,
					);
					$link['LinkPromoType'] = $this->oLinkFeed->getPromoTypeByLinkContent($link['LinkName'] . " " . $link['LinkDesc'] . " " . $link['LinkHtmlCode']);
					if (empty($link['AffMerchantId']) || empty($link['AffLinkId']) || empty($link['LinkName']))
						continue;
					$this->oLinkFeed->fixEnocding($this->info, $link, "feed");
					$links[] = $link;
					$arr_return["AffectedCount"] ++;
				}
				echo sprintf("get link form api(commonAds)...platformId:%s, page:%s, %s link(s) found.\n", $platformId, $page, count($links));
				if (count($links) > 0)
					$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);
				$page++;
			}while ($page < 1000);
		}
		*/

		// get links from page
		$request = array("AffId" => $this->info["AffId"], "method" => "post", "postdata" => "", );
		$this->oLinkFeed->LoginIntoAffService($this->info["AffId"],$this->info);
		list ($limit, $offset, $coupon) = array(100, 0, 0);
		do 
		{
			$request = array("AffId" => $this->info["AffId"], "method" => "post", "postdata" => "PagingPartnershipListAffiliateProgram=100", );
			$url = sprintf('https://ui.belboon.com/ShowPartnershipList,mid.43,Offset.%s/DoHandlePartnershipList.en.html', $offset);
			$r = $this->oLinkFeed->GetHttpResult($url, $request);
			$content = $r['content'];
			preg_match_all('@"(/ShowPartnershipOverview,mid\.(\d+)/DoHandlePartnership,id\.(\d+),partnershipid\.\d+,programid\.(\d+)\.en\.html)"@', $content, $programs);
			if (empty($programs) || empty($programs[1]) || !is_array($programs[1]))
				break;
			foreach ((array)$programs[1] as $key => $program)
			{
				$page_offset = 0;
				//do
				//{
					$request = array("AffId" => $this->info["AffId"], "method" => "post", "postdata" => "PagingAdlist=100", );
					$url = sprintf('https://ui.belboon.com/ShowPartnershipOverview,mid.%s,Offset.%s/DoHandlePartnership,id.%s,partnershipid.%s,programid.%s.en.html',
							$programs[2][$key], $page_offset, $programs[3][$key], $programs[3][$key], $programs[4][$key]);
					$r = $this->oLinkFeed->GetHttpResult($url, $request);
					$content = $r['content'];
					preg_match_all('@<\!-- Werbemittelname -->.*?toggleCode\((\d+)\).*?</textarea>@ms', $content, $chapters);
					if (empty($chapters) || empty($chapters[0]) || !is_array($chapters[0]))
						break;
					$links = array();
					$coupon = 0;
					foreach ((array)$chapters[0] as $link_key => $v)
					{
						$link = array(
								"AffId" => $this->info["AffId"],
								"AffMerchantId" => $programs[4][$key],
								"AffLinkId" => $chapters[1][$link_key],
								"LinkName" => '',
								"LinkDesc" => '',
								"LinkStartDate" => '0000-00-00',
								"LinkEndDate" => '0000-00-00',
								"LinkPromoType" => 'N/A',
								"LinkHtmlCode" => '',
								"LinkCode" => '',
								"LinkOriginalUrl" => "",
								"LinkImageUrl" => '',
								"LinkAffUrl" => '',
								"DataSource" => 54,
						);
						if (preg_match('@margin:10px;float:left;"><strong>(.*?)</strong>@', $v, $g))
							$link['LinkName'] = trim(html_entity_decode(strip_tags($g[1])));
						if (preg_match('@<textarea.*?>(.*?)</textarea>@ms', $v, $g))
						{
							$link['LinkHtmlCode'] = $g[1];
							$link['LinkDesc'] = trim(html_entity_decode(strip_tags($g[1])));
						}
						if (preg_match('@<img src="(.*?)"@', $link['LinkHtmlCode'], $g))
							$link['LinkImageUrl'] = $g[1];
						if (preg_match('@<a href="(.*?)"@', $link['LinkHtmlCode'], $g))
							$link['LinkAffUrl'] = $g[1];
						$link['LinkPromoType'] = $this->oLinkFeed->getPromoTypeByLinkContent($link['LinkName'] . ' ' . $link['LinkDesc']);
						$code = get_linkcode_by_text($link['LinkName'] . '|' . $link['LinkDesc']);
						if (!empty($code))
						{
							$link['LinkCode'] = $code;
							$link['LinkPromoType'] = 'COUPON';
						}
						if (preg_match('@-->Voucher code</th>@', $v, $g))
						{
							$link['LinkPromoType'] = 'COUPON';
							if (preg_match('@\'normalnodeco\'.*?>(.*?)</a>@', $v, $g))
							{
								$link['LinkCode'] = trim(strip_tags($g[1]));
								$coupon ++;
							}
						}
						if (empty($link['LinkName']) || empty($link['AffLinkId']) || empty($link['LinkHtmlCode']))
							continue;
						$count_link ++;
						$this->oLinkFeed->fixEnocding($this->info, $link, "feed");
						$links[] = $link;
						$arr_return["AffectedCount"] ++;
					}
					echo sprintf("get links by page...program:%s, offset:%s, %s links(s) found. (%s)\n", $programs[3][$key], $page_offset, count($links), $coupon);
					if(count($links) > 0)
						$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);
					$page_offset += count($chapters[0]);
				//}while(count($chapters[0]) >= $limit);
			}
			$offset += count($programs[0]);
		}while(count($programs[1]) >= $limit);
		return $arr_return;
	}

	function GetProgramFromAff()
	{
		$check_date = date("Y-m-d H:i:s");
		echo "Craw Program start @ {$check_date}\r\n";
		$this->GetProgramByApi();
		$this->checkProgramOffline($this->info["AffId"], $check_date);
		echo "Craw Program end @ ".date("Y-m-d H:i:s")."\r\n";
	}
	
	function GetProgramByApi()
	{
		echo "\tGet Program by api start\r\n";
		$objProgram = new ProgramDb();
		$arr_prgm = array();
		$program_num = 0;

		$adPlatformId_arr = array(	576890,	//
									576894	//DE
									);
		$config = array(
						'login' => 'couponsnapshot',
						'password' => 'jU3QXucpWBKsgfPr5jzs',
						'trace' => true
						);
		$client  = new SoapClient("http://api.belboon.com/?wsdl", $config);
		try {
			$client  = new SoapClient("http://api.belboon.com/?wsdl", $config);

			$page = 0;
			$hasNextPage = true;
			while($hasNextPage){
				$limit = 100;
				$start = $limit * $page;
				$result = $client->getPrograms(
												576890, // adPlatformId
												null, // programLanguage
												null, // partnershipStatus
												null, // query
												array('programid' => 'ASC'), // orderBy
												$limit, // limit
												$start // offset
												);
				if(!count($result->handler->programs)){
					$hasNextPage = false;
					break;
				}
				if($page > 100){
					mydie("die: page max > 100.\n");
				}
				foreach($result->handler->programs as $prgm){
					$strMerID = $prgm['programid'];
					if(!$strMerID) continue;

					$Partnership = "NoPartnership";
					$StatusInAffRemark = $prgm['partnershipstatus'];
					if($StatusInAffRemark == 'PARTNERSHIP'){
						$Partnership = 'Active';
					}elseif($StatusInAffRemark == 'REJECTED'){
						$Partnership = 'Declined';
					}elseif($StatusInAffRemark == 'PENDING'){
						$Partnership = 'Pending';
					}elseif($StatusInAffRemark == 'PAUSED'){
						$Partnership = 'Expired';
					}elseif($StatusInAffRemark == 'AVAILABLE'){
						$Partnership = 'NoPartnership';
					}

					$CommissionExt = '
									commissionsaleminpercent: '.$prgm['commissionsaleminpercent'].',
									commissionsalemaxpercent: '.$prgm['commissionsalemaxpercent'].',
									commissionsaleminfix: '.$prgm['commissionsaleminfix'].',
									commissionsalemaxfix: '.$prgm['commissionsalemaxfix'].',
									commissionleadmin: '.$prgm['commissionleadmin'].',
									commissionleadmax: '.$prgm['commissionleadmax'].',
									commissionclickmin: '.$prgm['commissionclickmin'].',
									commissionclickmax: '.$prgm['commissionclickmax'].',
									commissionviewmin: '.$prgm['commissionviewmin'].',
									commissionviewmax: '.$prgm['commissionviewmax'];

					//$result = $client->getProgramDetails(342);
					$arr_prgm[$strMerID] = array(
						"AffId" => $this->info["AffId"],
						"IdInAff" => $strMerID,
						"Name" => addslashes($prgm['programname']),
						"TargetCountryExt" => addslashes($prgm['programlanguage']),
						"TargetCountryInt" => addslashes($prgm['programlanguage']),
						"Homepage" => $prgm['advertiserurl'],
						"Description" => addslashes($prgm['programdescription']),
						"TermAndCondition" => addslashes($prgm['programterms']),
						"StatusInAffRemark" => addslashes($StatusInAffRemark),
						"StatusInAff" => 'Active',						//'Active','TempOffline','Offline'
						"Partnership" => $Partnership,					//'NoPartnership','Active','Pending','Declined','Expired','WeDeclined'
						"DetailPage" => $prgm['programregisterurl'],
						"LastUpdateTime" => date("Y-m-d H:i:s"),
						"CommissionExt" => addslashes($CommissionExt),
					);
					
					$program_num++;
					if(count($arr_prgm) >= 100){
						$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
						$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
						$arr_prgm = array();
					}
				}
				$page++;
			}
		} catch( Exception $e ) {
			mydie("die: Api error.\n");
		}
		if(count($arr_prgm)){
			$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
			$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
			unset($arr_prgm);
		}
		echo "\tGet Program by api end\r\n";
		if($program_num < 10){
			mydie("die: program count < 10, please check program.\n");
		}
		echo "\tUpdate ({$program_num}) program.\r\n";
		echo "\tSet program country int.\r\n";
		$objProgram->setCountryInt($this->info["AffId"]);
	}

	function checkProgramOffline($AffId, $check_date){
		$objProgram = new ProgramDb();
		$prgm = array();
		$prgm = $objProgram->getNotUpdateProgram($this->info["AffId"], $check_date);

		if(count($prgm) > 30){
			mydie("die: too many offline program (".count($prgm).").\n");
		}else{
			$objProgram->setProgramOffline($this->info["AffId"], $prgm);
			echo "\tSet (".count($prgm).") offline program.\r\n";
		}
	}
}
