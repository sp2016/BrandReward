<?php

require_once 'text_parse_helper.php';

class LinkFeed_15_Zanox
{
	var $info = array(
		"ID" => "15",
		"Name" => "Zanox",
		"IsActive" => "YES",
		"ClassName" => "LinkFeed_15_Zanox",
		"LastCheckDate" => "1970-01-01",
	);

	function __construct($aff_id,$oLinkFeed)
	{
		$this->oLinkFeed = $oLinkFeed;
		$this->info = $oLinkFeed->getAffById($aff_id);
		$this->debug = isset($oLinkFeed->debug) ? $oLinkFeed->debug : false;
		
		$this->file = "programlog_{$aff_id}_".date("Ymd_His").".csv";
		$this->soapClient = null;
	}

	private function getSoapClient()
	{
		require_once INCLUDE_ROOT."wsdl/zanox-api_client/ApiClient.php";
	
		if (!is_object($this->soapClient))
		{
			$client = ApiClient::factory(PROTOCOL_SOAP);
			$client->setConnectId("80A516E42488A9CD9505");
			$client->setSecretKey("baec48B6992947+DACa2c73a7f0645/24e2E6647");
			$this->soapClient = $client;
		}
		return $this->soapClient;
	}

	// the soap call failed often.
	// try another 2 times when failed.
	private function soapCall_15($method)
	{
		$args = func_get_args();
		array_shift($args);
		$client = $this->getSoapClient();
		$handler = array($client, $method);
		$retry = 3;
		$r = null;
		do
		{
			$retry --;
			try
			{
				$r = call_user_func_array($handler, $args);
			}
			catch (Exception $e)
			{
				echo sprintf("Exception raised: %s, Retry:%s\n", $e->getMessage(), $retry);
			}
		}while($retry >= 0 && empty($r));
		return $r;
	}

	function getCouponFeed()
	{
		$arr_return = array("AffectedCount" => 0,"UpdatedCount" => 0,"Detail" => array());
		$pagesize = 50;
		$page = 0;
		do
		{
			$links = array();
			$data = $this->soapCall_15('SearchIncentives', null, null, null, null, $page, $pagesize);
			if (empty($data) || empty($data->total))
				break;
			if (!empty($data->incentiveItems) && !empty($data->incentiveItems->incentiveItem))
				$items = $data->incentiveItems->incentiveItem;
			else if (!empty($data->incentiveItem))
				$items = $data->incentiveItem;
			else
				break;
			foreach ($items as $v)
			{
				$link = array(
						"AffId" => $this->info["AffId"],
						"AffMerchantId" => $v->program->id,
						"AffLinkId" => $v->id,
						"LinkStartDate" => parse_time_str(@$v->startDate, 'Y-m-d H:i:s', false),
						"LinkEndDate" => parse_time_str(@$v->endDate, 'Y-m-d H:i:s', false),
						"LinkPromoType" => 'COUPON',
						"LinkHtmlCode" => '',
						"LinkCode" => sprintf('%s', @$v->couponCode),
						"LinkOriginalUrl" => '',
						"LinkImageUrl" => '',
						"LinkAffUrl" => '',
						"DataSource" => 29,
				);
				if (!empty($v->admedia->admediumItem) && is_array($v->admedia->admediumItem) && !empty($v->admedia->admediumItem[0]))
				{
					$i = $v->admedia->admediumItem[0];
					$link['LinkName'] = @$i->name;
					$link['LinkDesc'] = @$i->description;
					if (!empty($i->trackingLinks) && !empty($i->trackingLinks->trackingLink) && is_array($i->trackingLinks->trackingLink)
							&& !empty($i->trackingLinks->trackingLink[0]))
					{
						$link['LinkAffUrl'] = $i->trackingLinks->trackingLink[0]->ppc;
						$link['LinkAffUrl'] = preg_replace('@\&zpar9=\[\[\w+\]\]@', '', $link['LinkAffUrl']);
						if (!empty($i->width) && !empty($i->height) && $i->width > 1 && $i->height > 1)
							$link['LinkImageUrl'] = $v->admedia->admediumItem[0]->trackingLinks->trackingLink[0]->ppv;
					}
					$link['LinkHtmlCode'] = @$i->code;
				}
				if (empty($link['LinkName']))
					$link['LinkName'] = $v->name;
				if (!empty($v->restrictions))
					$link['LinkDesc'] .= $v->restrictions;
				if (!empty($v->info4customer))
					$link['LinkDesc'] .= $v->info4customer;
				if (empty($link['LinkHtmlCode']) && !empty($link['LinkAffUrl']))
					$link['LinkHtmlCode'] = create_link_htmlcode_image($link);
				if ($v->incentiveType == 'noShippingCosts')
					$link['LinkPromoType'] = 'free shipping';
				if (empty($link['AffLinkId']) || empty($link['AffMerchantId']) || empty($link['LinkName']))
					continue;
				if (empty($link['LinkAffUrl']) && empty($link['LinkCode']))
					continue;
				$this->oLinkFeed->fixEnocding($this->info, $link, "feed");
				$links[] = $link;
				$arr_return['AffectedCount'] ++;
			}
			$total = $data->total;
			echo sprintf("searchIncentives... page: %s, %s link(s) found.\n", $page, count($links));
			if(count($links) > 0)
				$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);
			$page ++;
		}while ($page < 500 && $page < $total);
		return $arr_return;
	}

	private function getProgramObj()
	{
		if (!empty($this->objProgram))
			return $this->objProgram;
		$this->objProgram = new ProgramDb();
		return $this->objProgram;
	}
	
	function GetAllLinksFromAffByMerID($merinfo)
	{
		$aff_id = $this->info["AffId"];
		$arr_return = array("AffectedCount" => 0, "UpdatedCount" => 0, );
		$option = array('program' => $merinfo['AffMerchantId'], 'items' => 50, 'page' => 0);
		$page = 0;
		$count = 0;
		$items = 50;
		do
		{
			$data = $this->soapCall_15('GetAdmedia', $merinfo['AffMerchantId'], null, null, null, null, null, null, null, $page, $items);
			if (empty($data) || empty($data->total))
				break;
			if (!empty($data->admediumItems) && !empty($data->admediumItems->admediumItem))
				$admediumItems = $data->admediumItems->admediumItem;
			else if (!empty($data->admediumItem))
				$admediumItems = $data->admediumItem;
			else
				break;
			$links = array();
			foreach ($admediumItems as $v)
			{
				$link = array(
						"AffId" => $this->info["AffId"],
						"AffMerchantId" => $merinfo['AffMerchantId'],
						"AffLinkId" => $v->id,
						"LinkName" =>  $v->name,
						"LinkDesc" =>  '',
						"LinkStartDate" => '0000-00-00',
						"LinkEndDate" => '0000-00-00',
						"LinkPromoType" => 'N/A',
						"LinkHtmlCode" => '',
						"LinkCode" => '',
						"LinkOriginalUrl" => '',
						"LinkImageUrl" => '',
						"LinkAffUrl" => '',
						"DataSource" => 29,
				);
				if (!empty($v->description))
					$link['LinkDesc'] = $v->description;
				if (!empty($v->trackingLinks->trackingLink))
					$trackingLink = $v->trackingLinks->trackingLink;
				else if (!empty($v->trackingLink))
					$trackingLink = $v->trackingLink;
				if (empty($trackingLink))
					continue;
				if (is_array($trackingLink) && !empty($trackingLink[0]->ppc))
					$trackingLink = $trackingLink[0];
				$link['LinkAffUrl'] = $trackingLink->ppc;
				if (preg_match('@(^.*?ppc/\?\w+)\&zpar9=@', $link['LinkAffUrl'], $g))
					$link['LinkAffUrl'] = $g[1] . 'T&ULP=[[XXX]]';
				if ($v->admediumType == 'image' || $v->admediumType == 'image_text')
				{
					$link['LinkImageUrl'] = $trackingLink->ppv;
					$link['LinkHtmlCode'] = create_link_htmlcode_image($link);
				}
				else if ($v->admediumType == 'script' && !empty($v->code))
					$link['LinkHtmlCode'] = $v->code;
				else 
					$link['LinkHtmlCode'] = create_link_htmlcode($link);
				$code = get_linkcode_by_text($link['LinkName']);
				if (!empty($code))
				{
					$link['LinkCode'] = $code;
					$link['LinkPromoType'] = 'COUPON';
				}
				else
					$link['LinkPromoType'] = $this->oLinkFeed->getPromoTypeByLinkContent($link['LinkName'] . '|' . $link['LinkDesc']);
				if (empty($link['LinkName']) || empty($link['AffLinkId']))
					continue;
				$links[] = $link;
				$arr_return['AffectedCount'] ++;
			}
			$total = $data->total;
			$page ++;
			$count += $items;
			echo sprintf("merchant: %s, page: %s, %s link(s) found.\n", $merinfo['AffMerchantId'], $page, count($links));
			sleep(2);
			if(count($links) > 0)
				$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);
		}while ($page < 100 && $count < $total);
		return $arr_return;
	}

	function GetProgramByPage()
	{
		//step 1,login
		$this->oLinkFeed->LoginIntoAffService($this->info["AffId"],$this->info,1,false);

		$request = array("AffId" => $this->info["AffId"], "method" => "get", "postdata" => "",);
		$partnership_arr = array("active", "notJoined", "pendingApproval", "merchantSuspended", "merchantRejected", "closed");

		foreach($partnership_arr as $p_ship){
			$nNumPerPage = 40;
			$bHasNextPage = true;
			$nPageNo = 1;
			if($p_ship == "active"){
				$Partnership = "Active";//'NoPartnership','Active','Pending','Declined','Expired','WeDeclined'
				$Status = "Active";
			}elseif($p_ship == "notJoined"){
				$Partnership = "NoPartnership";
				$Status = "Active";
			}elseif($p_ship == "pendingApproval"){
				$Partnership = "Pending";
				$Status = "Active";
			}elseif($p_ship == "merchantSuspended"){
				$Partnership = "NoPartnership";
				$Status = "TempOffline";
			}elseif($p_ship == "merchantRejected"){
				$Partnership = "Declined";
				$Status = "Active";
			}elseif($p_ship == "closed"){
				$Partnership = "NoPartnership";
				$Status = "Offline";
			}else{
				break;
			}

			while($bHasNextPage){
				$strUrl = "https://marketplace.zanox.com/zanox/affiliate/803474/merchant-directory/xhr-directory/pageLength/40/sortColumn/adRank/sortMode/desc/pageNumber/$nPageNo/membershipStatus/$p_ship";
				$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
				$result = $r["content"];

				print "<br>\n Get Merchant List : Page: $nPageNo  <br>\n";
				//parse HTML
				$strLineStart = '<td class="name">';

				$nLineStart = 0;
				while ($nLineStart >= 0){
					$nLineStart = stripos($result, $strLineStart, $nLineStart);
					if ($nLineStart === false) break;
					//name
					$strMerName = $this->oLinkFeed->ParseStringBy2Tag($result, '<div title="', '" class="company">', $nLineStart);
					if ($strMerName === false) break;
					$strMerName = trim($strMerName);
					//id
					$strMerID = trim($this->oLinkFeed->ParseStringBy2Tag($result, 'href="/zanox/affiliate/803474/1398563/merchant-profile/', '"', $nLineStart));
					if ($strMerID === false) break;
					//partnership
					//$Partnership = $this->oLinkFeed->ParseStringBy2Tag($result, '<span class="joined">', '</span>', $nLineStart);
					//	Conversion Rate 	Confirmation Rate (S/L) 	Approval Time 	Payment Time 	EPC 	AdRank 	Product Data 	Launch Date
					//</div></td><td>0.00%</td><td>66.2% / 0%</td><td>25 days</td><td>25 days</td><td >0.54&nbsp;EUR</td><td>1.1</td><td class="productData">No</td><td>17/07/12</td>
					$ConversionRate = $this->oLinkFeed->ParseStringBy2Tag($result, '</div></td><td>', '</td>', $nLineStart);
					$ConfirmationRate = $this->oLinkFeed->ParseStringBy2Tag($result, '<td>', '</td>', $nLineStart);
					$ApprovalTime = $this->oLinkFeed->ParseStringBy2Tag($result, '<td>', '</td>', $nLineStart);
					$PaymentTime = $this->oLinkFeed->ParseStringBy2Tag($result, '<td>', '</td>', $nLineStart);
					$EPCDefault= $this->oLinkFeed->ParseStringBy2Tag($result, '<td>', '</td>', $nLineStart);
					$RankInAff = $this->oLinkFeed->ParseStringBy2Tag($result, '<td>', '</td>', $nLineStart);
					$ProductData = $this->oLinkFeed->ParseStringBy2Tag($result, '<td class="productData">', '</td>', $nLineStart);
					$JoinDate = $this->oLinkFeed->ParseStringBy2Tag($result, '<td>', '</td>', $nLineStart);
					if($JoinDate){
						$JoinDate = date("Y-m-d H:i:s", strtotime($JoinDate));
					}

					$prgm_url = "https://marketplace.zanox.com/zanox/affiliate/803474/1398563/merchant-profile/$strMerID";
					$prgm_arr = $this->oLinkFeed->GetHttpResult($prgm_url, $request);
					$prgm_detail = $prgm_arr["content"];

					$Homepage = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<li id="website">', 'href="'), '"'));
					$desc = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<h3>Description</h3>', '<div id="descriptionLongContent" class="accountDescription inlineTextArea">'), '</div>'));
					$CookieTime = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<span>Cookie Time</span>', '<span class="secondary">PPS (Sale):'), 'd 0h</span>'));
					$Contacts = "Name:".trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<div class="boxContent" id="profileContactContent">', '<p id="name">'), '</p>'));
					$Contacts .= " Tel:".trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<div class="boxContent" id="profileContactContent">', '<li id="tel">'), '</li>'));
					$Contacts .= " Email:".trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<div class="boxContent" id="profileContactContent">', '<div class="tooltipTextContent">'), '<span'));

					$term_url = "https://marketplace.zanox.com/zanox/affiliate/803474/1398563/merchant-profile-terms/$strMerID";
					$term_arr = $this->oLinkFeed->GetHttpResult($term_url, $request);
					$term_detail = $term_arr["content"];
					$TermAndCondition = trim($this->oLinkFeed->ParseStringBy2Tag($term_detail, array('Program Terms', '<div id="termsFreeTextContent" class="inlineTextArea">'), '</div>'));			

					$arr_prgm[$strMerID] = array(
						"Name" => addslashes(html_entity_decode($strMerName)),
						"AffId" => $this->info["AffId"],
						"Contacts" => addslashes($Contacts),
						"RankInAff" => $RankInAff,
						"StatusInAffRemark" => $p_ship,
						"IdInAff" => $strMerID,
						"EPCDefault" => $EPCDefault,
						"StatusInAff" => $Status,						//'Active','TempOffline','Offline'
						"Partnership" => $Partnership,						//'NoPartnership','Active','Pending','Declined','Expired','WeDeclined'
						"Description" => addslashes($desc),
						"Homepage" => $Homepage,
						"TermAndCondition" => addslashes($TermAndCondition),
						"LastUpdateTime" => date("Y-m-d H:i:s"),
						"DetailPage" => $prgm_url,
					);

					if(count($arr_prgm) >= 100){
						$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
						$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
						$arr_prgm = array();
					}
				}
				if(count($arr_prgm)){
					$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
					$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
					$arr_prgm = array();
				}
				$bHasNextPage = $this->oLinkFeed->ParseStringBy2Tag($result, 'id="nextPage"', '&raquo;', $nLineStart);
				if ($bHasNextPage === false) break;
				else $nPageNo++;
			}
		}
		$objProgram->setCountryInt($this->info["AffId"]);
		$this->checkProgramOffline($this->info["AffId"]);
	}

	function GetProgramByApi()
	{
		echo "\tGet Program by api start\r\n";

		require_once INCLUDE_ROOT."wsdl/zanox-api_client/ApiClient.php";
		$objProgram = $this->getProgramObj();
		$arr_prgm = array();
		$program_num = 0;

		/*$client = ApiClient::factory(PROTOCOL_SOAP);
		$client->setConnectId("80A516E42488A9CD9505");
		$client->setSecretKey("baec48B6992947+DACa2c73a7f0645/24e2E6647");*/

		
		$program_num = $this->getProgramDetails();
		//$program_num += $this->getProgramPartnership($client,$objProgram);
		
		//$this->getProgramDeepLink($client,$objProgram);

		echo "\tGet Program by api end\r\n";

		if($program_num < 10){
			mydie("die: program count < 10, please check program.\n");
		}

		echo "\tUpdate ({$program_num}) program.\r\n";
		echo "\tSet program country int.\r\n";
		$objProgram->setCountryInt($this->info["AffId"]);
	}

	function GetProgramFromAff()
	{
		$check_date = date("Y-m-d H:i:s");
		echo "Craw Program start @ {$check_date}\r\n";
		$this->GetProgramByApi();
		$this->checkProgramOffline($this->info["AffId"], $check_date);
		echo "Craw Program end @ ".date("Y-m-d H:i:s")."\r\n";
	}

	function checkProgramOffline($AffId, $check_date){
		$objProgram = $this->getProgramObj();
		$prgm = array();
		$prgm = $objProgram->getNotUpdateProgram($this->info["AffId"], $check_date);
		if(count($prgm) > 10){		
			$recheck_ids = array();
			foreach($prgm as $v){
				$recheck_ids[$v['IdInAff']] = $v['IdInAff'];
			}
			if(count($recheck_ids)){				
				$this->getProgramDetails($recheck_ids);
			}
		}

		$prgm = array();
		$prgm = $objProgram->getNotUpdateProgram($this->info["AffId"], $check_date);
		if(count($prgm) > 30){
			mydie("die: too many offline program (".count($prgm).").\n");
		}else{
			$objProgram->setProgramOffline($this->info["AffId"], $prgm);
			echo "\tSet (".count($prgm).") offline program.\r\n";
		}
	}

	private function key_implode($glue, $array, $key)
	{
		$t = array();
		if (key_exists($key, $array) && !is_array($array[$key]))
			return $array[$key];
		foreach ($array as $v)
		{
			if (is_array($v) && key_exists($key, $v))
			{
				if (is_array($v[$key]))
					$t[] = implode(',', $v[$key]);
				else
					$t[] = $v[$key];
			}
		}
		return implode($glue, $t);
	}

	function getProgramDetails($recheck_ids = array())
	{
		$request = array("AffId" => $this->info["AffId"], "method" => "get",);
		$this->oLinkFeed->LoginIntoAffService($this->info["AffId"],$this->info,1,false);
		
		list ($page, $items, $total, $arr_prgm, $cnt) = array(0, 50, 0, array(), 0);
		do
		{
			$url = sprintf("http://api.zanox.com/json/2011-03-01/programs?page=%s&connectid=80A516E42488A9CD9505&items=%s", $page, $items);
			$r = $this->oLinkFeed->GetHttpResult($url, $request);
			$data = @json_decode($r['content'], true);
			if (empty($total))
				$total = (int)$data['total'];
			foreach ((array)$data['programItems']['programItem'] as $prgm)
			{
				$strMerID = (int)$prgm['@id'];
				if (!$strMerID)
					continue;
				
				// for recheck not update program today 
				if(count($recheck_ids) && !isset($recheck_ids[$strMerID])) continue;

				$program = array(
						"Name" => addslashes(html_entity_decode($prgm['name'])),
						"AffId" => $this->info["AffId"],
						//"Contacts" => addslashes($Contacts),
						"RankInAff" => round($prgm['adrank']),
						"StatusInAffRemark" => addslashes($prgm['status']),
						"IdInAff" => $strMerID,
						"CookieTime" => intval($prgm['returnTimeSales']) / 86400,
						//"EPCDefault" => $EPCDefault,
						"StatusInAff" => ucfirst(addslashes($prgm['status'])),						//'Active','TempOffline','Offline'
						"Partnership" => 'NoPartnership',											//'NoPartnership','Active','Pending','Declined','Expired','WeDeclined'
						"Description" => '',
						"Homepage" => addslashes($prgm['url']),
						"TermAndCondition" => '',
						"SEMPolicyExt" => '',
						"CategoryExt" => '',
						"AffDefaultUrl" => '',
						"SupportDeepUrl" => 'UNKNOWN',
						"JoinDate" => isset($prgm['startDate']) ? date("Y-m-d H:i:s", strtotime($prgm['startDate'])) : "",
						"TargetCountryExt" => '',
						"DetailPage" => "https://marketplace.zanox.com/zanox/affiliate/803474/1197710/merchant-profile/$strMerID",
						"LastUpdateTime" => date("Y-m-d H:i:s"),
						"MobileFriendly" => 'UNKNOWN',
				);

				$commissionDetailUrl = $program['DetailPage'].'/commission-groups';
				$CommissionExt = $this->getProgramCommissionExt($commissionDetailUrl);
				$program['CommissionExt'] = addslashes($CommissionExt);
												
				if(isset($prgm['policies']['policy']) && is_array($prgm['policies']['policy']))
					$program['SEMPolicyExt'] = addslashes($this->key_implode(',', $prgm['policies']['policy'], '$'));
				if(isset($prgm['categories'][0]['category']) && is_array($prgm['categories'][0]['category']))
					$program['CategoryExt'] = addslashes($this->key_implode(',', $prgm['categories'][0]['category'], '$'));
				if(isset($prgm['regions']) && is_array($prgm['regions']))
					$program['TargetCountryExt'] =$this->key_implode(',', $prgm['regions'], 'region');
				if(isset($prgm['terms']))
					$program['TermAndCondition'] = addslashes($prgm['terms']);
				$desc = "";
				if(isset($prgm['description']))
					$desc = $prgm['description'];
				if(isset($prgm['descriptionLocal']))
				{
					if(empty($desc))
						$desc = "\r\r\r\r";
					$desc .= $prgm['descriptionLocal'];
				}
				$program['Description'] = addslashes($desc);

				$status = ucfirst($prgm['status']);
				$partnership = "";
				if($status == "Active"){
					$tmp_arr = array();
					$tmp_arr = $this->getProgramPartnershipById($strMerID);				
					//$program['CreateDate'] = @count($tmp_arr['CreateDate']) ? addslashes($tmp_arr['CreateDate']) : '';
					$program['Partnership'] = @count($tmp_arr['Partnership']) ? addslashes($tmp_arr['Partnership']) : 'NoPartnership';
					$partnership = @$tmp_arr['Partnership'];
				}				
								
				if($status == "Active" && $partnership == "Active"){
					$tmp_arr = array();
					$tmp_arr = $this->getProgramDeepLinkById($strMerID);				
					$program['SupportDeepUrl'] = @count($tmp_arr['SupportDeepUrl']) ? addslashes($tmp_arr['SupportDeepUrl']) : 'UNKNOWN';
					$program['AffDefaultUrl'] = @count($tmp_arr['AffDefaultUrl']) ? addslashes($tmp_arr['AffDefaultUrl']) : '';					
									
					$r = $this->oLinkFeed->GetHttpResult($program['DetailPage'], $request);
					$content = $r['content'];
					if (preg_match('@<h4>Optimized for Mobile</h4>\s+<div.*?>\s+(.*?)\s+</div>@', $content, $g))
					{
						if (strtoupper(trim($g[1])) == 'YES')
							$program['MobileFriendly'] = 'YES';
						else
							$program['MobileFriendly'] = 'NO';
					}
				}
				$arr_prgm[$strMerID] = $program;
				
				$cnt++;
			}
			if(count($arr_prgm) > 0)
			{
				$objProgram = $this->getProgramObj();
				$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
				$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
				$arr_prgm = array();
			}
			$page ++;
		}while ($page < 1000 && $page * $items < $total);
		return $cnt;
	}

	function getProgramCommissionExt($url){
		$request = array("AffId" => $this->info["AffId"], "method" => "get",);
		$r = $this->oLinkFeed->GetHttpResult($url, $request);
		$body = $r['content'];

		$objDomTools = new DomTools($body);
		$objDomTools->select('div #merchantKeyFigures');
		$m = $objDomTools->get();

		$CommissionExt = $m[0]['Content'];
		return $CommissionExt;
	}

	function getProgramPartnership($client,$objProgram){
		$cnt = 0;
		//getProgramApplications ($adspaceId = NULL, $programId = NULL, $status = NULL, $page = 0, $items = 10 );
		//"open", "confirmed", "rejected", "deferred", "waiting", "blocked", "terminated", "canceled", "called", "declined", "deleted"
		$adspaceId_arr = array(797864,1398563,1197710,2073904);
		$ignore_prgm_arr = array();
		$inactive_prgm_arr = array();
		foreach($adspaceId_arr as $adspaceId){
			$pagesize = 50;
			$return_obj = $client->getProgramApplications ($adspaceId, '', '', 0, 1);
			$total = $return_obj->total;
			$total_page = $total / $pagesize;
			$arr_prgm = array();
			for ($page = 0; $page < $total_page; $page++) {
				$return_obj = $client->getProgramApplications ($adspaceId, '', '', $page, $pagesize);
				//echo $status.":".$return_obj->total."<br>";
				//print_r($return_obj);
				foreach ($return_obj->programApplicationItems->programApplicationItem as $prgm) {
					if(isset($prgm->program)){
						$strMerID = intval($prgm->program->id);
						$CreateDate = isset($prgm->createDate) ? date("Y-m-d H:i:s", strtotime($prgm->createDate)) : "";
						/*$StatusInAff = "Offline";
						if($prgm->program->active == 1){
							$StatusInAff = "Active";
						}*/
						$Partnership = "";
						if($prgm->status == "confirmed"){
							$Partnership = "Active";
						}elseif($prgm->status == "open"){
							$Partnership = "NoPartnership";
						}elseif($prgm->status == "waiting"){
							$Partnership = "Pending";
						}elseif($prgm->status == "deferred"){
							$Partnership = "Expired";
						}elseif($prgm->status == "rejected"){
							$Partnership = "Declined";
						}elseif(in_array($prgm->status, array("closed", "blocked", "terminated", "canceled", "called", "deleted"))){
							$Partnership = "NoPartnership";
						}else{
							continue;
						}
						//check DE prgm 
						if(isset($ignore_prgm_arr[$strMerID])){
							continue;
						}elseif($Partnership != "Active"){
							//$ignore_prgm_arr[$strMerID] = 1;
							$inactive_prgm_arr[$strMerID] = array(
										"Name" => addslashes(html_entity_decode($prgm->program->_)),
										"AffId" => $this->info["AffId"],
										"IdInAff" => $strMerID,
										"Partnership" => $Partnership,
										//"StatusInAff" => $StatusInAff,
										"CreateDate" => $CreateDate,
										"LastUpdateTime" => date("Y-m-d H:i:s"),
									);
						}else{
							$ignore_prgm_arr[$strMerID] = 1;
							$arr_prgm[$strMerID] = array(
										"Name" => addslashes(html_entity_decode($prgm->program->_)),
										"AffId" => $this->info["AffId"],
										"IdInAff" => $strMerID,
										"Partnership" => $Partnership,
										//"StatusInAff" => $StatusInAff,
										"CreateDate" => $CreateDate,
										"LastUpdateTime" => date("Y-m-d H:i:s"),
									);
						}
						//print_r($arr_prgm);
						if(count($arr_prgm) >= 100){
							$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
							$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
							$arr_prgm = array();
						}
						$cnt++;
					}
				}
			}
			if(count($arr_prgm)){
				$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
				$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
				$arr_prgm = array();
			}
		}
		foreach($ignore_prgm_arr as $id => $val){
			if(isset($inactive_prgm_arr[$id])){
				unset($inactive_prgm_arr[$id]);
			}
		}
		if(count($inactive_prgm_arr)){
			$objProgram->updateProgram($this->info["AffId"], $inactive_prgm_arr);
			$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $inactive_prgm_arr);
			$arr_prgm = array();
		}
		return $cnt;
	}
	
	function getProgramDeepLinkById($idinaff)
	{
		$return_arr = array();
		$request = array("AffId" => $this->info["AffId"], "method" => "get");
		$url = sprintf("https://api.zanox.com/json/2011-03-01/admedia?program=%s&connectid=80A516E42488A9CD9505&admediumtype=text", $idinaff);			
		$r = $this->oLinkFeed->GetHttpResult($url, $request);
		$data = @json_decode($r['content'], true);
		
		
		if((int)$data['total'] > 1){
			foreach ((array)$data['admediumItems']['admediumItem'] as $prgm)
			{
				//print_r($prgm);
				$strMerID = (int)$prgm['program']['@id'];
				if (!$strMerID || $strMerID != $idinaff)
					continue;
				
				if(isset($prgm['trackingLinks']['trackingLink'])){
					foreach($prgm['trackingLinks']['trackingLink'] as $v) {
						if(isset($v['ppc']) && !empty($v['ppc'])){
							$SupportDeepurl = 'YES';
							$TrackingLink = $v['ppc'];
							$TrackingLink = substr($TrackingLink, 0, stripos($TrackingLink, "&zpar9"));
							$return_arr = array("SupportDeepUrl" => $SupportDeepurl,
												"AffDefaultUrl" => addslashes($TrackingLink)
												);
							break 2;
						}
					}
				}					
			}
		}
		return $return_arr;
	}
	
	function getProgramPartnershipById($idinaff)
	{
		$return_arr = array();
		$request = array("AffId" => $this->info["AffId"], "method" => "get");
		
		$client = $this->getSoapClient();
		//getProgramApplications ($adspaceId = NULL, $programId = NULL, $status = NULL, $page = 0, $items = 10 );
		$return_obj = $client->getProgramApplications(null, $idinaff, null, 0, 10);
		//echo $status.":".$return_obj->total."<br>";
		//print_r($return_obj);exit;
		if(isset($return_obj->total) && $return_obj->total > 0){
			foreach ($return_obj->programApplicationItems->programApplicationItem as $prgm) {
				if(isset($prgm->program)){
					$strMerID = intval($prgm->program->id);
					if($strMerID != $idinaff) continue;
					
					$CreateDate = isset($prgm->createDate) ? date("Y-m-d H:i:s", strtotime($prgm->createDate)) : "";
					
					$Partnership = "";
					$StatusInAffRemark = "";
					if($prgm->status == "confirmed"){
						$Partnership = "Active";
					}elseif($prgm->status == "open"){
						$Partnership = "NoPartnership";
					}elseif($prgm->status == "waiting"){
						$Partnership = "Pending";
					}elseif($prgm->status == "deferred"){
						$Partnership = "Expired";
					}elseif($prgm->status == "rejected"){
						$Partnership = "Declined";
					}elseif(in_array($prgm->status, array("closed", "blocked", "terminated", "canceled", "called", "deleted"))){
						$Partnership = "NoPartnership";
					}else{
						$StatusInAffRemark = $prgm->status;
						$Partnership = "NoPartnership";
					}
														
					$return_arr = array("CreateDate" => $CreateDate, "Partnership" => $Partnership);
					
					if($Partnership == "Active"){
						break;
					}
				}
			}
		}		
		return $return_arr;
	}

	function getProgramDeepLink($client,$objProgram)
	{
		$cnt = 0;
		//getAdmedia ($programId = NULL, region = NULL, format = NULL, purpose = startpage, partnership = NULL, admediumtype = NULL, category = 0, adspace = 0, $page = 0, $items = 10);
		//purpose = "startpage", "productdeeplink", "categorydeeplink", "searchdeeplink".
		$prgm_mark = array();
		$adspaceId_arr = array(797864,1398563,1197710,2073904);
		$pagesize = 50;
		$return_obj = $client->GetAdmedia(NULL, NULL, NULL, NULL, NULL, "text", NULL, NULL, 0, 1);
		$total = $return_obj->total;
		$total_page = $total / $pagesize;
		$arr_prgm = array();
		for ($page = 0; $page < $total_page; $page++) 
		{
			$return_obj = $client->GetAdmedia(NULL, NULL, NULL, NULL, NULL, "text", NULL, NULL, $page, $pagesize);
			echo sprintf("call GetAdmedia %s/%s\n", $page, $total_page);

			foreach ($return_obj->admediumItems->admediumItem as $prgm)
			{
				if(isset($prgm->program))
					$strMerID = intval($prgm->program->id);
				if(isset($prgm_mark[$strMerID]))
					continue;
				$SupportDeepurl = false;
				if(isset($prgm->trackingLinks->trackingLink)){
					foreach($prgm->trackingLinks->trackingLink as $v) {
						if(isset($v->ppc) && !empty($v->ppc)){
							$SupportDeepurl = 'YES';
							$TrackingLink = $v->ppc;
							$TrackingLink = substr($TrackingLink, 0, stripos($TrackingLink, "&zpar9"));
							break;
						}
					}
				}
				if($SupportDeepurl == 'YES')
				{
					$prgm_mark[$strMerID] = 1;
					$arr_prgm[$strMerID] = array(
						"AffId" => $this->info["AffId"],
						"IdInAff" => $strMerID,
						//"LastUpdateTime" => date("Y-m-d H:i:s"),
						"SupportDeepUrl" => $SupportDeepurl,
						"AffDefaultUrl" => addslashes($TrackingLink)
					);
					if(count($arr_prgm) >= 100)
					{
						$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
						$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
						$arr_prgm = array();
					}
				}
			}
		}
		if(count($arr_prgm)){
			$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
			$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
			$arr_prgm = array();
		}
	}
}

