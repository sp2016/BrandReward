<?php

require_once 'text_parse_helper.php';

class LinkFeed_177_The_Performance_Factory
{
	private $api_key = 'AFFqDaKJGHlyS9trMSkYhFs4KN37st';

	function __construct($aff_id, $oLinkFeed)
	{
		$this->oLinkFeed = $oLinkFeed;
		$this->info = $oLinkFeed->getAffById($aff_id);
		$this->debug = isset($oLinkFeed->debug) ? $oLinkFeed->debug : false;
	}

	function GetAllLinksFromAffByMerID($merinfo)
	{
		$arr_return = array("AffectedCount" => 0, "UpdatedCount" => 0, "Detail" => array(), );
		$request = array("AffId" => $this->info["AffId"], "method" => "get");
		return $arr_return;
	}

	function getCouponFeed()
	{
		$arr_return = array("AffectedCount" => 0, "UpdatedCount" => 0, "Detail" => array(), );
		$request = array("AffId" => $this->info["AffId"], "method" => "get");
		return $arr_return;
	}

	private function getProgramObj()
	{
		if (!empty($this->objProgram))
			return $this->objProgram;
		$this->objProgram = new ProgramDb();
		return $this->objProgram;
	}

	function GetProgramFromAff()
	{
		$request = array("AffId" => $this->info["AffId"], "method" => "get");
		$url = sprintf('http://partners.offerfactory.com.au/offers/offers.json?api_key=%s', $this->api_key);
		$r = $this->oLinkFeed->GetHttpResult($url, $request);
		$content = $r['content'];
		$data = @json_decode($content, true);
		if (empty($data) || empty($data['data']) || empty($data['data']['offers']))
			mydie('wrong format of api result.');
		$programs = array();
		foreach ($data['data']['offers'] as $v)
		{
			$id = $v['id'];
			if (empty($id))
				continue;
			$ids[] = $id;
			$program = array(
					"Name" => addslashes(trim(html_entity_decode($v['name']))),
					"AffId" => $this->info["AffId"],
					"TargetCountryExt" => addslashes(trim($v['countries'])),
					"TargetCountryInt" => addslashes(str_replace(' ', '', $v['countries_short'])),
					"Contacts" => '',
					"IdInAff" => $id,
					"RankInAff" => 0,
					"JoinDate" => '',
					"StatusInAff" => 'Active',				//'Active','TempOffline','Offline'
					"StatusInAffRemark" => '',
					"Partnership" => 'Active',				//'NoPartnership','Active','Pending','Declined','Expired','Removed'
					"Homepage" => addslashes(trim(html_entity_decode($v['preview_url']))),
					"EPCDefault" => '',
					"EPC90d" => '',
					"Description" => addslashes(trim(html_entity_decode($v['description']))),
					"CommissionExt" => addslashes(sprintf('%s: %s', $v['payout_type'], $v['payout'])),
					"CookieTime" => 0,
					"AffDefaultUrl" => addslashes(trim(html_entity_decode($v['tracking_url']))),
					"LastUpdateTime" => date("Y-m-d H:i:s"),
			);
			$programs[$id] = $program;
		}
		$p = $this->getProgramObj();
		$p->updateProgram($this->info["AffId"], $programs);
		$this->checkProgramOffline($this->info["AffId"], date("Y-m-d"));
	}

	private function checkProgramOffline($AffId, $check_date)
	{
		$p = $this->getProgramObj();
		$prgm = $p->getNotUpdateProgram($this->info["AffId"], $check_date);
		if(count($prgm) > 50)
			mydie("die: too many offline program (".count($prgm).").\n");
		else
		{
			$p->setProgramOffline($this->info["AffId"], $prgm);
			echo "\tSet (".count($prgm).") offline program.\r\n";
		}
	}
}
