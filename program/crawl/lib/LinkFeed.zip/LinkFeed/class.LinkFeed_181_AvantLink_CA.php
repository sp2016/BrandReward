<?php

require_once 'text_parse_helper.php';

class LinkFeed_181_AvantLink_CA
{
	function __construct($aff_id,$oLinkFeed)
	{
		$this->oLinkFeed = $oLinkFeed;
		$this->info = $oLinkFeed->getAffById($aff_id);
		$this->debug = isset($oLinkFeed->debug) ? $oLinkFeed->debug : false;
		
		$this->file = "programlog_{$aff_id}_".date("Ymd_His").".csv";
	}	

	function Login(){
		$islogined = false;
		$this->oLinkFeed->clearHttpInfos($this->info["AffId"]);
		$strUrl = "https://www.avantlink.com/signin";
		$request = array(
			"AffId" => $this->info["AffId"],
			"method" => "get",
			"postdata" => "",
		);
		$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
		$result = $r["content"];
		$_token = urlencode($this->oLinkFeed->ParseStringBy2Tag($result, array('name="_token"', 'value="'), '"'));		

		$this->info["AffLoginPostString"] .= "&_token=".$_token;
		//echo $this->info["AffLoginPostString"];		
		
		$request = array(
			"AffId" => $this->info["AffId"],
			"method" => $this->info["AffLoginMethod"],
			"postdata" => $this->info["AffLoginPostString"]			
		);
		$r = $this->oLinkFeed->GetHttpResult($this->info["AffLoginUrl"], $request);		
		if($r["code"] == 200){
			if(stripos($r["content"], $this->info["AffLoginVerifyString"]) !== false)
			{
				echo "verify succ: " . $this->info["AffLoginVerifyString"] . "\n";
				$islogined = true;
			}else{
				echo "verify login failed(".$this->info["AffLoginVerifyString"].") <br>\n";
			}
		}
		
		if(!$islogined){
			mydie("die: login failed for aff({$this->info["AffId"]}) <br>\n");
		}else{
			$_md5 = urlencode($this->oLinkFeed->ParseStringBy2Tag($r["content"], 'href="/signin/account/3894/', '"'));
			$this->info["AffLoginSuccUrl"] .= $_md5;
			$request = array("AffId" => $this->info["AffId"], "method" => "get");
			$r = $this->oLinkFeed->GetHttpResult($this->info["AffLoginSuccUrl"], $request);			
		}
	}
	
	function getMerchantByStatus($status,&$arrAllExistsMerchants)
	{
		$arr_return = array("AffectedCount" => 0,"UpdatedCount" => 0,);
		$request = array(
			"AffId" => $this->info["AffId"],
			"method" => "post",
			"postdata" => "", 
		);
		
		echo "get $status merchants for " . $this->info["AffName"] . "\n";
		
		$strUrl = "https://www.avantlink.ca/affiliate/merchants.php";
		$request["postdata"] = "strRelationStatus=" . $status . "&lngMerchantCategoryId=0&strProductKeywords=&cmdFilter=Get+Merchants";
		$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
		$result = $r["content"];

		$Cnt = 0;
		$UpdateCnt = 0;

		//parse HTML
		$nLineStart = 0;
		$strLinksArrayData = $this->oLinkFeed->ParseStringBy2Tag($result, 'var g_arrData_rptlist_201=[', '];', $nLineStart);
		$arrTmpLine = explode("\n", $strLinksArrayData);
		foreach($arrTmpLine as $strLine)
		{
			$strLine = trim($strLine);
			if ($strLine == '') continue;
			
			if(preg_match("/^,?\\[(.*)\\]$/",$strLine,$matches)) $strLine = $matches[1];
			else
			{
				echo "line skipped: $strLine\n";
			}

			eval("\$js_mer_info = array($strLine);");
			if($js_mer_info === false) mydie("die: eval failed: $strLine\n");
			
			if($status == "active") list($temp,$temp2,$strMerID,$strMerName,) = $js_mer_info;
			elseif($status == "no-relationship") list($temp,$strMerName) = $js_mer_info;
			elseif($status == "pending") list($temp,$strMerName) = $js_mer_info;
			else list($temp,$reason,$strMerName,,,) = $js_mer_info;
			
			//a href="merchant_details.php?lngMerchantId=10072">800-Ski-Shop.com</a>
			//'Merchant denied your application to their program.','Altrec.com Outdoors','Outdoor/Recreation','sale','percent',' 10.00%','120','1.48%','15.31%','Configure inactive link handling '
			//pending: '<a href="merchant_details.php?lngMerchantId=11109">Brooklyn Battery Works</a>'
			if(preg_match("/lngMerchantId=([0-9]*)\\\">(.*)<\\/a>/",$strMerName,$matches))
			{
				//double check $strMerID
				$strMerID = $matches[1];
				$strMerName = trim($matches[2]);
			}
			else
			{
				mydie("die: parse failed: $strLine\n");
			}
			
			if($status == "active") $strStatus = 'approval';
			elseif($status == "inactive") $strStatus = 'siteclosed';
			elseif($status == "no-relationship") $strStatus = 'approval';
			elseif($status == "pending") $strStatus = 'pending';
			else mydie("die: wrong status($status)");
			
			$arr_return["AffectedCount"] ++;
			$arr_update = array(
				"AffMerchantId" => $strMerID,
				"AffId" => $this->info["AffId"],
				"MerchantName" => $strMerName,
				"MerchantEPC30d" => "-1",
				"MerchantEPC" => "-1",
				"MerchantStatus" => $strStatus,
				"MerchantRemark" => "", //here,we save programmeid to MerchantRemark
			);
			$this->oLinkFeed->fixEnocding($this->info,$arr_update,"merchant");
			if($this->oLinkFeed->UpdateMerchantToDB($arr_update,$arrAllExistsMerchants)) $arr_return["UpdatedCount"] ++;
		}
		echo "get $status merchants for " . $this->info["AffName"] . " finish\n";
		print_r($arr_return);
		return $arr_return;
	}
	
	function GetMerchantListFromAff()
	{
		//step 1,login
		$this->Login();

		//step 2,get all exists merchant
		$arrAllExistsMerchants = $this->oLinkFeed->GetAllExistsAffMerIDForCheckByAffID($this->info["AffId"]);

		$arr_return = array("AffectedCount" => 0,"UpdatedCount" => 0,);

		$arrStatus4List = array("active","inactive","no-relationship","pending");
		foreach($arrStatus4List as $status)
		{
			$one_status_result = $this->getMerchantByStatus($status,$arrAllExistsMerchants);
			$arr_return["AffectedCount"] += $one_status_result["AffectedCount"];
			$arr_return["UpdatedCount"] += $one_status_result["UpdatedCount"];
		}

		$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateAllExistsAffMerIDButCannotFetched($this->info["AffId"], $arrAllExistsMerchants);
		return $arr_return;
	}

	function getCouponFeed()
	{
		$arr_return = array(
			"AffectedCount" => 0,
			"UpdatedCount" => 0,
			"Detail" => array(),
		);
		return $arr_return; //added by liwei 2013 08 15
		$request = array(
			"AffId" => $this->info["AffId"],
			"method" => "post",
			"postdata" => "", 
		);
		
		if($this->debug) print "Getting CouponFeed for LC <br>\n";

		$title = '"Merchant Name","Coupon Type","Coupon Offer","Coupon Code","Coupon Link","Coupon Start","Coupon Expiration","Coupon Last Modified"';
		$cache_file = $this->oLinkFeed->fileCacheGetFilePath($this->info["AffId"],"feed.dat","cache_feed");
		if(!$this->oLinkFeed->fileCacheIsCached($cache_file))
		{
			//login
			$this->Login();
			
			//step 1, download coupon feed directly
			if($this->debug) print "Get CouponFeed Data  <br>\n";
			$strUrl = "http://www.avantlink.ca/coupons/coupon_feed.php?cfi=4257&pw=4724";
			$request["method"] = "get";
			$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
			$result = $r["content"];
			
			if(stripos($result,$title) === false)
			{
				print_r($r);
				mydie("die: get feed failed, title not found \n");
			}
			
			$this->oLinkFeed->fileCachePut($cache_file,$result);
		}
		if(!file_exists($cache_file)) return $arr_return;
		
		$all_merchant = $this->oLinkFeed->getAllAffMerchant($this->info["AffId"]);
		
		//Open CSV File
		$arr_title = explode(",",$title);
		foreach($arr_title as $i => $v) $arr_title[$i] = trim($v,'"');
		$col_count = sizeof($arr_title);
		
		$fhandle = fopen($cache_file, 'r');
		$arrToUpdate = array();
		while($line = fgetcsv($fhandle, 50000))
		{
			//$title = '"Merchant Name","Coupon Type","Coupon Offer","Coupon Code","Coupon Link","Coupon Start","Coupon Expiration","Coupon Last Modified"';
			if($line[0] == '' || $line[0] == 'Merchant Name') continue;
			if(sizeof($line) != $col_count)
			{
				echo "warning: invalid line found: " . implode(",",$line) . "\n";
				continue;
			}
			
			$row = array();
			foreach($arr_title as $i => $title) $row[$title] = $line[$i];
			
			$url_parsed = parse_url($row["Coupon Link"]);
			if($url_parsed === false)
			{
				echo "warning: Coupon Link is wrong: " . implode(",",$line) . "\n";
				continue;
			}
			$query_string = $url_parsed["query"];
			$para_pair = explode("&",$query_string);
			$arr_para = array();
			foreach($para_pair as $one_para)
			{
				$arr_temp = explode("=",$one_para,2);
				if(sizeof($arr_temp) != 2) continue;
				$arr_para[$arr_temp[0]] = urldecode($arr_temp[1]);
			}
			
			if(!isset($arr_para["mli"]) || !isset($arr_para["mi"]))
			{
				echo "warning: Coupon Link is wrong: " . implode(",",$line) . "\n";
				continue;
			}
			
			$link_id = 'c_' . $arr_para["mli"];
			$aff_mer_id = $arr_para["mi"];
			
			if(!isset($all_merchant[$aff_mer_id]))
			{
				echo "warning: Merchant Id not found \n";
				continue;
			}
			
			$link_desc = $row["Coupon Offer"];
			if (trim($row["Coupon Code"]) != '') $link_desc .= '. Coupon Code: '.$row["Coupon Code"];
			
			if ($row["Coupon Type"] == 'image'){
				$html_code = '<a href="'.$row["Coupon Link"].'"><img src="'.$row["Coupon Offer"].'" /></a>';
			}
			else{
				$html_code = '<a href="'.$row["Coupon Link"].'">'.$row["Coupon Offer"].'</a>';
			}
			
			$promo_type = 'coupon';
			
			$arr_one_link = array(
				"AffId" => $this->info["AffId"],
				"AffMerchantId" => $aff_mer_id,
				"AffLinkId" => $link_id,
				"LinkName" => $link_desc,
				"LinkDesc" => $link_desc,
				"LinkStartDate" => $row["Coupon Start"],
				"LinkEndDate" => $row["Coupon Expiration"],
				"LinkPromoType" => $promo_type,
				"LinkHtmlCode" => $html_code,
				"LinkOriginalUrl" => "",
				"LinkImageUrl" => "",
				"LinkAffUrl" => "",
				"DataSource" => "11",
			);
			
			$this->oLinkFeed->fixEnocding($this->info,$arr_one_link,"feed");
			$arrToUpdate[] = $arr_one_link;
			$arr_return["AffectedCount"] ++;
			if(!isset($arr_return["Detail"][$aff_mer_id]["AffectedCount"])) $arr_return["Detail"][$aff_mer_id]["AffectedCount"] = 0;
			$arr_return["Detail"][$aff_mer_id]["AffectedCount"] ++;

			if(sizeof($arrToUpdate) > 100)
			{
				$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($arrToUpdate);
				$arrToUpdate = array();
			}
		}
		fclose($fhandle);
		
		if(sizeof($arrToUpdate) > 0)
		{
			$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($arrToUpdate);
			$arrToUpdate = array();
		}
		return $arr_return;
	}

	function GetAllLinksFromAffByMerID($merinfo)
	{
		$aff_id = $this->info["AffId"];
		$AffMerchantId = $merinfo["AffMerchantId"];

		$arr_return = array("AffectedCount" => 0, "UpdatedCount" => 0,);
		$request = array("AffId" => $this->info["AffId"], "method" => "get", "postdata" => "",);
		$url = sprintf("http://www.avantlink.ca/api.php?affiliate_id=66185&module=AdSearch&output=tab&website_id=84981&merchant_id=%s&ad_type=text", $merinfo['IdInAff']);

		$r = $this->oLinkFeed->GetHttpResult($url, $request);
		if (empty($r) || empty($r['content']))
			return $arr_return;
		$data = csv_string_to_array($r['content'], "\t","\r\n");
		if (empty($data) || !is_array($data))
			return $arr_return;
		$links = array();
		foreach ($data as $v)
		{
			$link = array(
				"AffId" => $merinfo["AffId"],
				"AffMerchantId" => $merinfo["AffMerchantId"],
				"AffLinkId" => $v['Ad Id'],
				"LinkName" => $v['Ad Title'],
				"LinkDesc" => $v['Ad Content'],
				"LinkOriginalUrl" => "",
				"LinkImageUrl" => "",
				"LinkAffUrl" => $v['Ad Url'],
				"DataSource" => "12",
			);
			if (empty($link['AffLinkId']) || empty($link['LinkName']))
				continue;
			if (!empty($v['Coupon Code']))
			{
				$link['LinkCode'] = $v['Coupon Code'];
				$link['LinkPromoType'] = 'COUPON';
			}
			else
			{
				$link['LinkPromoType'] = $this->oLinkFeed->getPromoTypeByLinkContent($link['LinkName'].' '.$link['LinkDesc']);
			}
			if (!empty($v['Ad Start Date']))
				$link['LinkStartDate'] = date('Y-m-d H:i:s', strtotime($v['Ad Start Date']));
			if (!empty($v['Ad Expiration Date']))
				$link['LinkEndDate'] = date('Y-m-d H:i:s', strtotime($v['Ad Expiration Date'].' 23:59:59'));
			$link['LinkHtmlCode'] = create_link_htmlcode($link);
			$links[] = $link;
			$arr_return["AffectedCount"] ++;
		}
		if(sizeof($links) > 0)
		{
			$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);
			$arrToUpdate = array();
		}
		return $arr_return;
	}
	
	function getProgramByStatus($status, $country)	
	{		
		$request = array(
			"AffId" => $this->info["AffId"],
			"method" => "post",
			"postdata" => "", 
		);
		
		$objProgram = new ProgramDb();
		$arr_prgm = array();
		
		echo "get $status merchants for " . $this->info["AffName"] . "\n";
		
		if($country == "ca"){
			$domain = "https://classic.avantlink.ca";
			$TargetCountryExt = 'CA';
		}else{			
			$domain = "https://classic.avantlink.com";
			$TargetCountryExt = 'US';
		}
		$strUrl = "{$domain}/affiliate/merchants.php";
		$request["postdata"] = "strRelationStatus=" . $status . "&lngMerchantCategoryId=0&strProductKeywords=&cmdFilter=Get+Merchants";
		$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
		$result = $r["content"];

		$Cnt = 0;
		$UpdateCnt = 0;

		//parse HTML
		$nLineStart = 0;
		$strLinksArrayData = $this->oLinkFeed->ParseStringBy2Tag($result, 'var g_arrData_rptlist_201=[', '];', $nLineStart);
		$arrTmpLine = explode("\n", $strLinksArrayData);
		foreach($arrTmpLine as $strLine)
		{
			$strLine = trim($strLine);
			if ($strLine == '') continue;
			
			if(preg_match("/^,?\\[(.*)\\]$/",$strLine,$matches)) $strLine = $matches[1];
			else
			{
				echo "line skipped: $strLine\n";
			}
			
			eval("\$js_mer_info = array($strLine);");
			if($js_mer_info === false) mydie("die: eval failed: $strLine\n");
			
			$StatusInAff = "Active";
			$StatusInAffRemark = "";
			if($status == "active"){
				list($temp,$temp2,$strMerID,$strMerName,$CategoryExt,$Commission_Action,$Commission_Type,$Commission_Rate,$ReturnDays,$Sales_Volume,$Conversion_Rate,$Reversal_Rate,$Average_Sale_Amount,$Date_Joined) = $js_mer_info;
				$JoinDate = date("Y-m-d H:i:s", strtotime($Date_Joined));			
				$CommissionExt = $Commission_Rate;
				$Partnership = "Active";	
			}
			elseif($status == "no-relationship"){
				list($temp,$strMerName,$CategoryExt,$Commission_Action,$Commission_Type,$Commission_Rate,$ReturnDays,$Sales_Volume,$Conversion_Rate,$Reversal_Rate,$Average_Sale_Amount) = $js_mer_info;
				
				$JoinDate = "";
				$CommissionExt = $Commission_Rate;
				$Partnership = "NoPartnership";
			}
			elseif($status == "pending"){
				list($temp,$strMerName,$CategoryExt,$Commission_Action,$Commission_Type,$Commission_Rate,$ReturnDays,$Sales_Volume,$Conversion_Rate,$Reversal_Rate,$Average_Sale_Amount) = $js_mer_info;
				
				$JoinDate = "";
				$CommissionExt = $Commission_Rate;
				$Partnership = "Pending";				
			}
			else{
				list($temp,$reason,$strMerName,$CategoryExt,$Commission_Action,$Commission_Type,$Commission_Rate,$ReturnDays,$Sales_Volume,$Conversion_Rate,$Reversal_Rate,$Average_Sale_Amount) = $js_mer_info;
				
				$JoinDate = "";
				$CommissionExt = $Commission_Rate;
				//'NoPartnership','Active','Pending','Declined','Expired','WeDeclined'
				if($reason == "No longer active in the AvantLink network."){
					$StatusInAff = "Offline";
					$Partnership = "Expired";
				}elseif($reason == "Merchant denied your application to their program."){
					$Partnership = "Declined";
				}elseif($reason == "Merchant terminated their association with you."){
					$Partnership = "Expired";
				}else{
					$Partnership = "Expired";					
				}
				$StatusInAffRemark = $reason;
			}
			
			//a href="merchant_details.php?lngMerchantId=10072">800-Ski-Shop.com</a>
			//'Merchant denied your application to their program.','Altrec.com Outdoors','Outdoor/Recreation','sale','percent',' 10.00%','120','1.48%','15.31%','Configure inactive link handling '
			//pending: '<a href="merchant_details.php?lngMerchantId=11109">Brooklyn Battery Works</a>'
			if(preg_match("/lngMerchantId=([0-9]*)\\\">(.*)<\\/a>/",$strMerName,$matches))
			{
				//double check $strMerID
				$strMerID = $matches[1];
				$strMerName = trim($matches[2]);
			}
			else
			{
				mydie("die: parse failed: $strLine\n");
			}
			
			/*if($status == "active"){
				$StatusInAff = "Active";
			}
			elseif($status == "inactive"){				
				$StatusInAff = "Active";
			}
			elseif($status == "no-relationship"){			
				$StatusInAff = "Active";
			}
			elseif($status == "pending"){
				$StatusInAff = "Active";
			}
			else{
				mydie("die: wrong status($status)");
			}*/
			
			$RankInAff = trim($this->oLinkFeed->ParseStringBy2Tag($Sales_Volume, array('volume_'), '.'));
									
			//program
			//program_detail
			$prgm_url = "{$domain}/affiliate/merchant_details.php?lngMerchantId=$strMerID";
			$prgm_arr = $this->oLinkFeed->GetHttpResult($prgm_url, $request);
			$prgm_detail = $prgm_arr["content"];
			
			$prgm_line = 0;
			
			//$StatusInAff = $strStatus;//'Active','TempOffline','Expired'
			//statusinfaffremark
			//$StatusInAffRemark = $strStatus;
			
			$Homepage = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<strong>Merchant:</strong>', '<td><a href="'), '"', $prgm_line));
			$Contact = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<strong>Contact:</strong>', '<td>'), '</td>', $prgm_line));
			$Contact_email = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<strong>Contact Email:</strong>', 'mailto:'), '">', $prgm_line));
			$Contacts = $Contact.", Emial: ".$Contact_email;			
			
			$desc = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<strong>Program Description:</strong>', '<td>'), '</td>', $prgm_line));
			$NumberOfOccurrences = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<strong>Referral Ocurrences:</strong>', '<td>'), '</td>', $prgm_line));
			/*if($NumberOfOccurrences == "Unlimited"){
				$NumberOfOccurrences = -1;
			}*/
			
			$SubAffPolicyExt = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<strong>Reversal Policy:</strong>', '<td>'), '</td>', $prgm_line));
			
			$BonusExt = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<strong>Performance Incentives:</strong>', '<td>'), '</table>', $prgm_line));
			if($BonusExt){
				 $BonusExt .= "</table>";
			}
			
			$TermAndCondition = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<strong>Terms and Conditions:</strong>', '<td valign="top">'), '</td>', $prgm_line));
			if(empty($TermAndCondition))
				$TermAndCondition = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<strong>Terms and Conditions:</strong>', '<td>'), '</td>', $prgm_line));
			
			$arr_prgm[$strMerID] = array(
				"Name" => addslashes(html_entity_decode(trim($strMerName))),
				"AffId" => $this->info["AffId"],
				"CategoryExt" => addslashes($CategoryExt),
				"TargetCountryExt" => $TargetCountryExt,
				"Contacts" => addslashes($Contacts),				
				"IdInAff" => $strMerID,
				"RankInAff" => intval($RankInAff),
				"CreateDate" => $JoinDate,
				"StatusInAff" => $StatusInAff,						//'Active','TempOffline','Offline'
				"StatusInAffRemark" => $StatusInAffRemark,
				"Partnership" => $Partnership,						//'NoPartnership','Active','Pending','Declined','Expired','WeDeclined'				
				"Description" => addslashes($desc),
				"Homepage" => $Homepage,
				"CommissionExt" => addslashes($CommissionExt),
				"BonusExt" => addslashes($BonusExt),
				"CookieTime" => $ReturnDays,
				"NumberOfOccurrences" => addslashes($NumberOfOccurrences),
				"TermAndCondition" => addslashes($TermAndCondition),
				"SubAffPolicyExt" => addslashes($SubAffPolicyExt),
				"LastUpdateTime" => date("Y-m-d H:i:s"),
				"DetailPage" => $prgm_url,
				"SupportDeepUrl" => "YES"
			);
			
			$Cnt++;
	
			if(count($arr_prgm) >= 100){
				$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
				$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
				$arr_prgm = array();
			}
		}
		
		if(count($arr_prgm)){
			$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
			$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
			$arr_prgm = array();
		}
		
		//$objProgram->setProgramOffline($this->info["AffId"]);
		$objProgram->setCountryInt($this->info["AffId"]);
		
		return $Cnt;
	}
	
	function GetProgramByPage()
	{
		echo "\tGet Program by page start\r\n";		
		$program_num = 0;
		//step 1,login
		$this->Login();

		//step 2,get all exists merchant
		//$arrAllExistsMerchants = $this->oLinkFeed->GetAllExistsAffMerIDForCheckByAffID($this->info["AffId"]);

		$arrStatus4List = array("active","inactive","no-relationship","pending");
		foreach($arrStatus4List as $status)
		{
			$program_num += $this->getProgramByStatus($status, "ca");
		}
		
		echo "\tGet Program by page end\r\n";
		
		if($program_num < 10){
			mydie("die: program count {$program_num} < 10, please check program.\n");
		}
		
		echo "\tUpdate ({$program_num}) program.\r\n";
		
	}
	
	function GetProgramFromAff()
	{	
		$check_date = date("Y-m-d H:i:s");
		echo "Craw Program start @ {$check_date}\r\n";
		
		$this->GetProgramByPage();		
		$this->checkProgramOffline($this->info["AffId"], $check_date);

		echo "Craw Program end @ ".date("Y-m-d H:i:s")."\r\n";
	}
	
	function checkProgramOffline($AffId, $check_date){		
		$objProgram = new ProgramDb();
		$prgm = array();
		$prgm = $objProgram->getNotUpdateProgram($this->info["AffId"], $check_date);
		
		if(count($prgm) > 30){
			mydie("die: too many offline program (".count($prgm).").\n");
		}else{			
			$objProgram->setProgramOffline($this->info["AffId"], $prgm);
			echo "\tSet (".count($prgm).") offline program.\r\n";
		}
	}

}
?>
