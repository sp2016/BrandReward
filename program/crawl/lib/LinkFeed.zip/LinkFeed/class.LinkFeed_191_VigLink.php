<?php

require_once 'xml2array.php';

define('LINKFEED_VIGLINK_APIKEY', 'cad6cf4a614403969204fb78b3f0b467');

class LinkFeed_191_VigLink
{

	function __construct($aff_id,$oLinkFeed)
	{
		$this->oLinkFeed = $oLinkFeed;
		$this->info = $oLinkFeed->getAffById($aff_id);
		$this->debug = isset($oLinkFeed->debug) ? $oLinkFeed->debug : false;
		
		$this->file = "programlog_{$aff_id}_".date("Ymd_His").".csv";
	}		
	
	function GetProgramFromAff()
	{	
		$check_date = date("Y-m-d H:i:s");
		echo "Craw Program start @ {$check_date}\r\n";		
		
		
		$this->checkProgramThroughMainAff();
		//$this->GetProgramFromByPage();		
		//$this->checkProgramOffline($this->info["AffId"], $check_date);

		echo "Craw Program end @ ".date("Y-m-d H:i:s")."\r\n";
	}
	
	function checkProgramThroughMainAff()
	{
		echo "\tCheck Program through main aff start\r\n";
		$program_num = 0;

		$objProgram = new ProgramDb();
		$arr_prgm = array();
		
		$aff_url_keyword = array();
		$aff_url_keyword = $objProgram->getAffiliateUrlKeywords();
				
		// for check if through main aff		
		$commint_zero_prgm = array();
		$commint_zero_prgm = $objProgram->getCommIntProgramByAffId($this->info["AffId"]);
		echo "\t get commission int = 0 succeed\r\n";
		
		$check_prgm = array();
		$check_prgm = array_keys($commint_zero_prgm);
		
		// Internal EPC=0 
		$internal_prgm = array();
		$fp = fopen("http://couponsn:IOPkjmN1@reporting.megainformationtech.com/dataapi/offline_program.php?affid=".$this->info["AffId"], "r");
		if($fp){
			echo "\t get Internal EPC=0 program succeed.\n";
			$i = 0;
			while(!feof($fp))
			{
				$line = trim(fgets($fp));
				if(!$line) continue;
				$tmp_arr = explode("\t", $line);//Id in Aff, Program Name, Sales, Commission, CR(Commission Rate)
				
				$affid = intval($tmp_arr[0]);				
				$IdInAff = trim($tmp_arr[1]);
				
			
				if($affid == $this->info["AffId"]){
					//ignore 
					if(!in_array($IdInAff, array("68#spreadshirt.com","494#cengagebrain.com","3296#taxact.com","548#aldoshoes.com","828#ebags.com", "3976#lexmark.com", "1256#qvcuk.com", "10580#dietchef.co.u" , "2393#rugsale.com"))){
						$internal_prgm[$IdInAff] = 1;
						$i++;
					}
				}
			}
			fclose($fp);
			$check_prgm = count($check_prgm) ? array_merge($check_prgm, array_keys($internal_prgm)) : array_keys($internal_prgm);
			echo "\t get ($i) Internal EPC=0 program\n";
		}else{
			echo "\t Internal EPC=0 program failed.\n";
		}
		
		$check_prgm = array_unique($check_prgm);
		echo "\t get (".count($check_prgm).") programs\n";
		
		foreach($check_prgm as $IdInAff){
			$tmp_arr = $objProgram->getProgramByAffIdAndIdInAff($this->info["AffId"], $IdInAff);
			
			$Homepage = trim($tmp_arr["Homepage"]);				
			
			$StatusInAffRemark = "";
			$through_main_aff = false;
				
			// check $aff_url_keyword
			$test_url = "http://redirect.viglink.com?key=cad6cf4a614403969204fb78b3f0b467&u=".urlencode($Homepage);
			$r = $this->oLinkFeed->GetHttpResult($test_url, array("header" => 1, "nobody" => false));
			$header = $r["content"];						
			//preg_match_all("/domain=.([A-Za-z0-9.]+)/i", $header, $matches);						
			preg_match_all("/Location:(.*)\r\n/i", $header, $matches);
			//print_r($matches);
			if(count($matches[1])){							
				foreach($aff_url_keyword as $url_k){
					foreach($matches[1] as $loc){
						if(stripos($loc, $url_k) !== false){
							$through_main_aff = true;
							break 2;
						}
					}		
				}							
			}
			
			if($tmp_arr["Partnership"] == "Active" && $through_main_aff == false){
				if(isset($internal_prgm[$IdInAff])){
					$StatusInAffRemark = "Internal EPC=0";
				}else{
					$StatusInAffRemark = "Not Through Main Aff";
				}
				$Partnership = "NoPartnership";
				
				$arr_prgm[$IdInAff] = array(						
					"AffId" => $this->info["AffId"],						
					"IdInAff" => $IdInAff,						
					"StatusInAffRemark" => addslashes($StatusInAffRemark),
					//"StatusInAff" => 'Active',						//'Active','TempOffline','Offline'					
					"Partnership" => $Partnership,						//'NoPartnership','Active','Pending','Declined','Expired','Removed'						
					"LastUpdateTime" => date("Y-m-d H:i:s")
				);
				$program_num++;
				
			}elseif($tmp_arr["Partnership"] != "Active" && $through_main_aff == true){
				$Partnership = "Active";
				
				$arr_prgm[$IdInAff] = array(						
					"AffId" => $this->info["AffId"],						
					"IdInAff" => $IdInAff,						
					"StatusInAffRemark" => addslashes($StatusInAffRemark),
					//"StatusInAff" => 'Active',						//'Active','TempOffline','Offline'					
					"Partnership" => $Partnership,						//'NoPartnership','Active','Pending','Declined','Expired','Removed'						
					"LastUpdateTime" => date("Y-m-d H:i:s")
				);
				$program_num++;
			}
						
			if(count($arr_prgm) >= 100){
				$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
				$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
				$arr_prgm = array();
			}
			
			sleep(1);
		}
		if(count($arr_prgm)){
			$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
			$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
			$arr_prgm = array();
		}
		echo "\tCheck Program through main aff end\r\n";
		
		
		echo "\tCheck ({$program_num}) program.\r\n";
	}
	
	function GetProgramFromByPage()
	{
		echo "\tGet Program by page start\r\n";
		$program_num = 0;
		
		//step 1,login
		//$this->oLinkFeed->LoginIntoAffService($this->info["AffId"],$this->info);
		//$this->Login();

		$objProgram = new ProgramDb();
		$arr_prgm = array();
		
		$aff_url_keyword = array();
		$aff_url_keyword = $objProgram->getAffiliateUrlKeywords();
		
		//print_r($aff_url_keyword);
		// for check if through main aff
		$commint_zero_prgm = array();
		$commint_zero_prgm = $objProgram->getCommIntProgramByAffId($this->info["AffId"]);
		
		// Internal EPC=0 
		$internal_prgm = array();
		$fp = fopen("http://couponsn:IOPkjmN1@reporting.megainformationtech.com/dataapi/offline_program.php?affid=".$this->info["AffId"], "r");
		if($fp){
			echo "\t get Internal EPC=0 program succeed.\n";
			$i = 0;
			while(!feof($fp))
			{
				$line = trim(fgets($fp));
				if(!$line) continue;
				$tmp_arr = explode("\t", $line);//Id in Aff, Program Name, Sales, Commission, CR(Commission Rate)
				
				$affid = intval($tmp_arr[0]);				
				$idinaff = trim($tmp_arr[1]);
				
			
				if($affid == $this->info["AffId"]){
					//ignore 
					if(!in_array($idinaff, array("68#spreadshirt.com","494#cengagebrain.com","3296#taxact.com","548#aldoshoes.com","828#ebags.com", "3976#lexmark.com", "1256#qvcuk.com", "10580#dietchef.co.u" , "2393#rugsale.com"))){
						$internal_prgm[$idinaff] = 1;
						$i++;
					}
				}
			}
			fclose($fp);
			echo "\t get ($i) Internal EPC=0 program\n";
		}else{
			echo "\t Internal EPC=0 program failed.\n";
		}
		
		$nNumPerPage = 10;
		$bHasNextPage = true;
		$nPageNo = 1;		
		while($bHasNextPage){
			$time = time();
			if($nPageNo > 4000){
				mydie("check program times > 4000 \n.");
			}
			$start = ($nPageNo - 1)*$nNumPerPage;
			$nPageNo++;
			$strUrl = "http://www.viglink.com/rest/merchantgroups?_=$time&size=10&start=$start&keyword=&industryIds=&sortByName=1&starsOnly=0";
			$request = array(
				"AffId" => $this->info["AffId"],
				"method" => "get",
				"postdata" => "",
			);
			$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
			$result = $r["content"];
			
			//temp
			$http_code = $r["code"];
			if($http_code != 200){				
				$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
				$result = $r["content"];								
			}			
			if($http_code != 200){				
				$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
				$result = $r["content"];								
			}			
			if($http_code != 200) {
				continue;
			}
			
			$result = json_decode($result);			
			//print_r($result);
			//exit;
			$total = intval($result->total);
				
			if(($start+$nNumPerPage) > $total){
				$bHasNextPage = false;
			}
			
			
			$program_list = $result->merchants;
			
			
			foreach($program_list as $v){
				$strMerID = intval($v->id);
				if(!$strMerID) continue;
				
				$strMerName = $v->name;
				$desc = $v->description;
				$commision = "";
				$domain = "";
				
				foreach($v->rates as $vv){
					if($vv->min == $vv->max){
						$commision .= $vv->max . $vv->type ." ". $vv->description . "\r\n";
					}else{
						$commision .= $vv->min ."-". $vv->max . $vv->type ." ". $vv->description . "\r\n";
					}				
				}
				
				foreach($v->domains as $vv){
					$domain = $vv->name;
					$IdInAff = addslashes($strMerID."#".$domain);
					$Homepage = "http://www.".$domain;
					
					$Partnership = 'NoPartnership';
					if(($v->closedPolicy != 1) && !empty($commision)){
						$Partnership = 'Active';
					}
					
					$through_main_aff = true;
					$StatusInAffRemark = "";
					if($Partnership == "Active" && (isset($internal_prgm[$IdInAff]) || isset($commint_zero_prgm[$IdInAff]))){
						$through_main_aff = false;
						// check $aff_url_keyword
						$test_url = "http://redirect.viglink.com?key=cad6cf4a614403969204fb78b3f0b467&u=".urlencode($Homepage);
						$r = $this->oLinkFeed->GetHttpResult($test_url, array("header" => 1, "nobody" => false));
						$header = $r["content"];						
						//preg_match_all("/domain=.([A-Za-z0-9.]+)/i", $header, $matches);						
						preg_match_all("/Location:(.*)\r\n/i", $header, $matches);
						//print_r($matches);
						if(count($matches[1])){							
							foreach($aff_url_keyword as $url_k){
								foreach($matches[1] as $loc){
									if(stripos($loc, $url_k) !== false){
										$through_main_aff = true;
										break 2;
									}
								}		
							}							
						}
					}
					
					if($through_main_aff == false){
						if(isset($internal_prgm[$IdInAff])){
							$StatusInAffRemark = "Internal EPC=0";
						}else{
							$StatusInAffRemark = "Not Through Main Aff";
						}
						$Partnership = "NoPartnership";
					}
										
					$arr_prgm[$IdInAff] = array(
						"Name" => addslashes(trim($strMerName)),
						"AffId" => $this->info["AffId"],						
						"IdInAff" => $IdInAff,
						"Homepage" => addslashes($Homepage),
						"StatusInAffRemark" => addslashes($StatusInAffRemark),
						"StatusInAff" => 'Active',						//'Active','TempOffline','Offline'					
						"Partnership" => $Partnership,						//'NoPartnership','Active','Pending','Declined','Expired','Removed'					
						"Description" => addslashes($desc),
						"CommissionExt" => addslashes($commision),
						"LastUpdateTime" => date("Y-m-d H:i:s"),
						"SecondIdInAff" => $strMerID,
						"SupportDeepUrl" => 'YES'
					);
					//print_r($arr_prgm);
					//exit;
					$program_num++;
				}				
				//exit;
				if(count($arr_prgm) >= 100){
					$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
					$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
					$arr_prgm = array();
				}				
			}				
		}		
		
		if(count($arr_prgm)){
			$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
			$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
			unset($arr_prgm);
		}		
		
		echo "\tGet Program by page end\r\n";
		
		if($program_num < 10){
			mydie("die: program count < 10, please check program.\n");
		}
		
		echo "\tUpdate ({$program_num}) program.\r\n";
		echo "\tSet program country int.\r\n";
		
		$objProgram->setCountryInt($this->info["AffId"]);		
	}

	function GetCountryByVigCountryID($id)
	{
		$id = (int)$id;
		switch ($id)
		{
			case 1:
				return 'US';
			case 36:
				return 'CA';
			case 227:
				return 'EU';
			case 195:
				return 'SE';
			case 214:
				return 'GB';
		}
	}
	function GetLinkPromoTypeByVigDealType($types)
	{
		if (empty($types))
			return 'N/A';
		$type = 'N/A';
		$ids = explode(',', $types);
		foreach ($ids as $id)
		{
			switch($id)
			{
				case 2:  //Coupon Code
				case 14: //Exclusive
					$type = 'coupon';
					break;
				case 18: //1-2-3 Day Only
				case 8:  //Deal of Day
				case 6:  //Dollars Off Coupon
				case 3:  //Free Gift
				case 16: //Hot Product
				case 12: //New Customer
				case 17: //No Minimum
				case 5:  //Percent Off Coupon
				case 9:  //Rebate
				case 4:  //Sale/Clearance
				case 11: //Seasonal Deal
				case 19: //Virtual coupon
					break;
				case 1:  //Free Shipping
				case 15: //Shipping Promo
					$type = 'free shipping';
					return $type;
			}
		}
		return $type;
	}
	function GetLinkHTMLCode($deal)
	{
		if (empty($deal['url']))
			return;
		$url = $deal['url'];
		if (empty($deal['name']))
			$name = $url;
		else
			$name = $deal['name'];
		return sprintf('<a href="%s">%s</a>', $url, $name);
	}
	function GetLinkDescription($deal)
	{
		$type_name = '';
		if (!empty($deal['deal_type']))
		{
			$type_str = array();
			$ids = explode(',', $deal['deal_type']);
			foreach ($ids as $id)
			{
				switch($id)
				{
					case 2:  //Coupon Code
						$type_str[] = 'Coupon Code';
						break;
					case 14: //Exclusive
						$type_str[] = 'Exclusive';
						break;
					case 18: //1-2-3 Day Only
						$type_str[] = '1-2-3 Day Only';
						break;
					case 8:  //Deal of Day
						$type_str[] = 'Deal of Day';
						break;
					case 6:  //Dollars Off Coupon
						$type_str[] = 'Dollars Off Coupon';
						break;
					case 3:  //Free Gift
						$type_str[] = 'Free Gift';
						break;
					case 16: //Hot Product
						$type_str[] = 'Hot Product';
						break;
					case 12: //New Customer
						$type_str[] = 'New Customer';
						break;
					case 17: //No Minimum
						$type_str[] = 'No Minimum';
						break;
					case 5:  //Percent Off Coupon
						$type_str[] = 'Percent Off Coupon';
						break;
					case 9:  //Rebate
						$type_str[] = 'Rebate';
						break;
					case 4:  //Sale/Clearance
						$type_str[] = 'Sale/Clearance';
						break;
					case 11: //Seasonal Deal
						$type_str[] = 'Seasonal Deal';
						break;
					case 19: //Virtual coupon
						$type_str[] = 'Virtual coupon';
						break;
					case 1:  //Free Shipping
						$type_str[] = 'Free Shipping';
						break;
					case 15: //Shipping Promo
						$type_str[] = 'Shipping Promo';
						break;
				}
			}
			$type_name = implode(',', $type_str);
		}
		$r = sprintf("deal_type: %s \r\n site_wide: %s \r\n %s", $type_name, @$deal['site_wide'], @$deal['description']);
		return $r;
	}
	
	function getCouponFeed()
	{
		$db = new ProgramDb();
		$merchants = $db->getAllProgramByAffId($this->info["AffId"]);
		$arr_return = array("AffectedCount" => 0, "UpdatedCount" => 0, "Detail" => array(),);
		$request = array("AffId" => $this->info["AffId"], "method" => "get", "postdata" => "",);
		$url_base = 'http://catalog.viglink.com/vigcatalog/deals.xml?key=%s&results_per_page=100&page=%s';
		$page = 1;
		$count = 0;
		do
		{
			$url = sprintf($url_base, LINKFEED_VIGLINK_APIKEY, $page);
			$content = $this->oLinkFeed->GetHttpResult($url, $request);
			$content = $content['content'];
			$dom = new DomDocument();
			@$dom->loadXML($content);
			$r = @XML2Array::createArray($dom);
			$links = array();
			if (!is_array($r) || empty($r))
			{
				if ($page == 1)
					break;
				else
				{
					$page ++;
					$count -= 100;
					continue;
				}
			}
			if ($page == 1)
			{
				$count = @$r['response']['results']['deals']['@attributes']['count'];
				$count = (int)$count;
				if (!$count)
					break;
			}
			$deals = $r['response']['results']['deals']['deal'];
			if (isset($deals['@attributes']) && $deals['@attributes']['id'])
			{
				$array = $deals;
				$deals = array();
				$deals[] = $array;
			}
			foreach ($deals as $deal)
			{
				if (!isset($deal['@attributes']))
					continue;
				$deal = $deal['@attributes'];
				if (!is_array($deal))
					continue;
				if (empty($deal['code']))
					continue;
				$mer_id = $deal['merchant'];
				foreach ($merchants as $merchant)
				{
					$IdInAff = $merchant['IdInAff'];
					if ((int)$IdInAff != $mer_id)
						continue;
					$link = array(
						"AffId" => $this->info["AffId"],
						"AffMerchantId" => $IdInAff,
						"AffLinkId" => $deal['id'],
						"LinkName" =>  $deal['name'],
						"LinkDesc" => $this->GetLinkDescription($deal),
						"LinkStartDate" => empty($deal['start_on']) ? '0000-00-00' : date('Y-m-d', strtotime($deal['start_on'])),
						"LinkEndDate" =>  empty($deal['end_on']) ? '0000-00-00' : date('Y-m-d', strtotime($deal['end_on'])),
						"LinkPromoType" => $this->GetLinkPromoTypeByVigDealType(@$deal['deal_type']),
						"LinkHtmlCode" => $this->GetLinkHTMLCode($deal),
						"LinkCode" => @$deal['code'],
						"LinkOriginalUrl" => '',
						"LinkImageUrl" => @$deal['image_url'],
						"LinkAffUrl" => $deal['url'],
						"DataSource" => 60,
					);
					$this->oLinkFeed->fixEnocding($this->info, $link, "feed");
					$links[] = $link;
					$arr_return["AffectedCount"] ++;
					if (empty($arr_return["Detail"][$IdInAff]["AffectedCount"]))
						$arr_return["Detail"][$IdInAff]["AffectedCount"] = 1;
					else
						$arr_return["Detail"][$IdInAff]["AffectedCount"] ++;
				}
			}
			if (count($links) > 0)
				$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);
			$links = array();
			$page ++;
			$count -= 100;
		}while($count > 0 && $page <= 100);
		return $arr_return;
	}
	
	function checkProgramOffline($AffId, $check_date){
		$this->GetMerchantListFromAff();
		
		$objProgram = new ProgramDb();
		$prgm = array();
		$prgm = $objProgram->getNotUpdateProgram($this->info["AffId"], $check_date);
	
		if(count($prgm) > 500){
			mydie("die: too many offline program (".count($prgm).").\n");
		}else{
			$objProgram->setProgramOffline($this->info["AffId"], $prgm);
			echo "\tSet (".count($prgm).") offline program.\r\n";
		}
	}


	function GetMerchantListFromAff()
	{
		//$arrAllExistsMerchants = $this->oLinkFeed->GetAllExistsAffMerIDForCheckByAffID($this->info["AffId"]);
		$nMerCnt = 0;
		$nMerUpdateCnt = 0;
		$request = array(
			"AffId" => $this->info["AffId"],
			"method" => "get",
			"postdata" => "", 
		);
		$url_base = 'http://catalog.viglink.com/vigcatalog/merchants.xml?key=%s&results_per_page=100&page=%s';
		$page = 1;
		$result = array();
		do 
		{
			$url = sprintf($url_base, LINKFEED_VIGLINK_APIKEY, $page);
			$content = $this->oLinkFeed->GetHttpResult($url, $request);
			$content = $content['content'];
			$dom = new DomDocument();
			@$dom->loadXML($content);
			$r = @XML2Array::createArray($dom);
			if (!is_array($r) || empty($r))
			{
				if ($page == 1)
					break;
				else
				{
					$page ++;
					$count -= 100;
					continue;
				}
			}
			if ($page == 1)
			{
				$count = @$r['response']['results']['merchants']['@attributes']['count'];
				$count = (int)$count;
				if (!$count)
					break;
			}
			$merchants = $r['response']['results']['merchants']['merchant'];
			if (isset($merchants['@attributes']) && !empty($merchants['@attributes']['id']))
			{
				$array = $merchants;
				$merchants = array();
				$merchants[] = $array;
			}
			foreach ($merchants as $key=> $merchant)
			{
				if (!is_array($merchant['@attributes']))
					continue;
				if (empty($merchant['@attributes']['id']))
					continue;
				$result[] = $merchant['@attributes'];
			}
			$page ++;
			$count -= 100;
		}while($count > 0 && $page <= 100);
		
		//check program offline
		$idinaff_arr = array();
		foreach ($result as $r)
		{
			$idinaff_arr[] = intval($r['id']);
			if(count($idinaff_arr) >= 100){
				$this->checkVigLinkProgram($idinaff_arr);
				$idinaff_arr = array();
			}
		}
		if(count($idinaff_arr)){
			$this->checkVigLinkProgram($idinaff_arr);
			unset($idinaff_arr);
		}	
		
		
		/*foreach ($result as $r)
		{
			$arr_update = array(
				"AffMerchantId" => $r['id'],
				"AffId" => $this->info["AffId"],
				"MerchantName" => $r['name'],
				"MerchantEPC30d" => -1,
				"MerchantEPC" => -1,
				"MerchantStatus" => 'approval',
				"MerchantRemark" => "",
				"MerchantCountry" => $this->GetCountryByVigCountryID($r['country']),
			);
			$nMerCnt ++;
			$this->oLinkFeed->fixEnocding($this->info, $arr_update, "merchant");
			if ($this->oLinkFeed->UpdateMerchantToDB($arr_update, $arrAllExistsMerchants)) 
				$nMerUpdateCnt ++;
		}
		return array("AffectedCount" => $nMerCnt,"UpdatedCount" => $nMerUpdateCnt,);*/
	}
/*
	function GetAllLinksFromAffByMerID($merinfo)
	{
		$arr_return = array('AffectedCount' => 0, 'UpdatedCount' => 0,);
		$id = (int)$merinfo['AffMerchantId'];
		$request = array("AffId" => $this->info["AffId"], "method" => "get", "postdata" => "",);
		$url_base = 'http://catalog.viglink.com/vigcatalog/deals.xml?key=%s&results_per_page=100&page=%s&merchant=%s';
		$page = 1;
		$count = 0;
		do
		{
			$url = sprintf($url_base, LINKFEED_VIGLINK_APIKEY, $page, $id);
			$content = $this->oLinkFeed->GetHttpResult($url, $request);
			$content = $content['content'];
			$dom = new DomDocument();
			@$dom->loadXML($content);
			$r = @XML2Array::createArray($dom);
			$links = array();
			if (!is_array($r) || empty($r))
			{
				if ($page == 1)
					break;
				else
				{
					$page ++;
					$count -= 100;
					continue;
				}
			}
			if ($page == 1)
			{
				$count = @$r['response']['results']['deals']['@attributes']['count'];
				$count = (int)$count;
				if (!$count)
					break;
			}
			$deals = $r['response']['results']['deals']['deal'];
			if (isset($deals['@attributes']) && $deals['@attributes']['id'])
			{
				$array = $deals;
				$deals = array();
				$deals[] = $array;
			}
			foreach ($deals as $deal)
			{
				if (!isset($deal['@attributes']))
					continue;
				$deal = $deal['@attributes'];
				if (!is_array($deal))
					continue;
				if (empty($deal['url']))
					continue;
				$deal['name'] = @htmlspecialchars_decode($deal['name']);
				$deal['description'] = @htmlspecialchars_decode($deal['description']);
				$mer_id = $deal['merchant'];
				$link = array(
					"AffId" => $this->info["AffId"],
					"AffMerchantId" => $mer_id,
					"AffLinkId" => $deal['id'],
					"LinkName" =>  $deal['name'],
					"LinkDesc" => $this->GetLinkDescription($deal),
					"LinkStartDate" => empty($deal['start_on']) ? '0000-00-00' : date('Y-m-d', strtotime($deal['start_on'])), 
					"LinkEndDate" =>  empty($deal['end_on']) ? '0000-00-00' : date('Y-m-d', strtotime($deal['end_on'])),
					"LinkPromoType" => $this->GetLinkPromoTypeByVigDealType(@$deal['deal_type']),
					"LinkHtmlCode" => $this->GetLinkHTMLCode($deal),
					"LinkCode" => @$deal['code'],
					"LinkOriginalUrl" => '',
					"LinkImageUrl" => @$deal['image_url'],
					"LinkAffUrl" => $deal['url'],
					"DataSource" => 60,
				);
				$links[] = $link;
				$this->oLinkFeed->fixEnocding($this->info, $link, "feed");
				$arr_return["AffectedCount"] ++;
				if (empty($arr_return["Detail"][$mer_id]["AffectedCount"]))
					$arr_return["Detail"][$mer_id]["AffectedCount"] = 1;
				else
					$arr_return["Detail"][$mer_id]["AffectedCount"] ++;
			}
			if (count($links) > 0)
				$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);
			$links = array();
			$page ++;
			$count -= 100;
		}while($count > 0 && $page <= 100);
		return $arr_return;
	}
*/
	
	function checkVigLinkProgram($idinaff_arr){
		$objProgram = new ProgramDb();
		if(count($idinaff_arr)){			
			$objProgram->updateVigLinkManually($idinaff_arr);	
		}
	}

}
?>
