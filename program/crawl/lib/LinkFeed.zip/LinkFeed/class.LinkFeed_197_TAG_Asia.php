<?php

require_once 'text_parse_helper.php';

class LinkFeed_197_TAG_Asia
{
	var $info = array(
		"ID" => "197",
		"Name" => "TAG Asia",
		"IsActive" => "YES",
		"ClassName" => "LinkFeed_197_TAG_Asia",
		"LastCheckDate" => "1970-01-01",
	);
	
	function __construct($aff_id,$oLinkFeed)
	{
		$this->oLinkFeed = $oLinkFeed;
		$this->info = $oLinkFeed->getAffById($aff_id);
		$this->debug = isset($oLinkFeed->debug) ? $oLinkFeed->debug : false;
		
		$this->file = "programlog_{$aff_id}_".date("Ymd_His").".csv";
	}	
	
	function GetProgramFromAff()
	{		
		$check_date = date("Y-m-d H:i:s");
		echo "Craw Program start @ {$check_date}\r\n";
		
		$this->GetProgramByPage();
		$this->checkProgramOffline($this->info["AffId"], $check_date);
		
		echo "Craw Program end @ ".date("Y-m-d H:i:s")."\r\n";
	}
	
	function GetProgramByPage()
	{
		echo "\tGet Program by page start\r\n";
		$objProgram = new ProgramDb();
		$arr_prgm = array();
		$program_num = 0;		
		
		//step 1,login
		$this->oLinkFeed->LoginIntoAffService($this->info["AffId"],$this->info);
		
		$request = array(
			"AffId" => $this->info["AffId"],
			"method" => "post",
			"postdata" => "categoryId=-1&programName=&merchantName=&records=-1&p=&time=1&changePage=&oldColumn=programmeId&sortField=programmeId&order=down",
			//"postdata" => "p=1&time=1&changePage=&oldColumn=programmeId&sortField=programmeId&order=down&records=-1",
		);
		$r = $this->oLinkFeed->GetHttpResult("https://www.tagadmin.asia/affiliate_directory.html",$request);
		$result = $r["content"];
		
		//parse HTML	
		$strLineStart = '<th>Cookie Duration</th>';
		
		$nLineStart = 0;
		while ($nLineStart >= 0){
			$nLineStart = stripos($result, $strLineStart, $nLineStart);
			if ($nLineStart === false) break;
			
			$strLineStart = "<tr";
			
			//id
			$strMerID = trim($this->oLinkFeed->ParseStringBy2Tag($result, "<td>", "</td>", $nLineStart));
			if ($strMerID === false) break;
			
			//name
			$strMerName = trim(strip_tags($this->oLinkFeed->ParseStringBy2Tag($result, '<td>' , "</td>", $nLineStart)));
			if ($strMerName === false) break;
			
			//name
			$tmpName = trim($this->oLinkFeed->ParseStringBy2Tag($result, '<td>' , "</td>", $nLineStart));
			if ($tmpName === false) break;
			
			$program_name = $strMerName." - ".$tmpName;
			
			$CategoryExt = trim($this->oLinkFeed->ParseStringBy2Tag($result, '<td>' , "</td>", $nLineStart));
			$CommissionExt  = trim($this->oLinkFeed->ParseStringBy2Tag($result, '<td>' , "</td>", $nLineStart));
			$CookieTime  = trim($this->oLinkFeed->ParseStringBy2Tag($result, '<td>' , "</td>", $nLineStart));
			$CookieTime2  = trim($this->oLinkFeed->ParseStringBy2Tag($result, '<td>' , "</td>", $nLineStart));
			
			$StatusInAffRemark = trim($this->oLinkFeed->ParseStringBy2Tag($result, '<td>' , "</td>", $nLineStart));
			if($StatusInAffRemark == "Approved"){
				$Partnership = "Active";
			}elseif($StatusInAffRemark == "Pending"){
				$Partnership = "Pending";
			}elseif($StatusInAffRemark == "Declined"){
				$Partnership = "Declined";
			}else{
				$Partnership = "NoPartnership";
			}
			//activeDate
			/*$tmp_CreateDate = trim($this->oLinkFeed->ParseStringBy2Tag($result, '<td rowspan=5 valign=top>', '</td>', $nLineStart));
			if($tmp_CreateDate == "Application - Declined"){
				$Partnership = "NoPartnership";
				$CreateDate = "";
			}else{
				$Partnership = "Active";
				$CreateDate = str_ireplace("Member Since :", "", $tmp_CreateDate);
				$CreateDate = date("Y-m-d H:i:s", strtotime($CreateDate));
			}*/
			
			$request = array(
				"AffId" => $this->info["AffId"],
				"method" => "get",
			);
			
			$prgm_url = "https://www.tagadmin.asia/affiliate_program_detail.html?pId=$strMerID";
			$prgm_arr = $this->oLinkFeed->GetHttpResult($prgm_url, $request);
			$prgm_detail = $prgm_arr["content"];
			
			$desc = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('Program Description','<div class="value">'), "</div>"));
			$Homepage = trim(strip_tags($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('Program Landing URL','<div class="value">'), "</div>")));			
			$TermAndCondition = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('Policy / Terms','<div class="value">'), "</div>"));
			
			$Homepage = str_ireplace("?sourcecode=TAG", "", $Homepage);
			
			$AffDefaultUrl = trim(htmlspecialchars_decode($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('id="trackingString"','>'), "</")));
			
			$arr_prgm[$strMerID] = array(
				"AffId" => $this->info["AffId"],
				"IdInAff" => $strMerID,
				"Name" => addslashes($program_name),
				"Homepage" => addslashes($Homepage),
				"Description" => addslashes($desc),
				"TermAndCondition" => addslashes($TermAndCondition),
				"CategoryExt" => addslashes($CategoryExt),
				"CommissionExt" => addslashes($CommissionExt),
				"CookieTime" => addslashes($CookieTime),
				"StatusInAffRemark" => addslashes($StatusInAffRemark),
				"StatusInAff" => 'Active',						//'Active','TempOffline','Offline'
				"Partnership" => $Partnership,						//'NoPartnership','Active','Pending','Declined','Expired','WeDeclined'
				"LastUpdateTime" => date("Y-m-d H:i:s"),
				"DetailPage" => $prgm_url,
				"AffDefaultUrl" => $AffDefaultUrl
			);
			//print_r($arr_prgm);exit;
			$program_num++;
			
			if(count($arr_prgm) >= 100){
				$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
				$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
				$arr_prgm = array();
			}
		}
		
		if(count($arr_prgm)){
			$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
			$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
			unset($arr_prgm);
		}
		
		echo "\tGet Program by page end\r\n";
		
		if($program_num < 10){
			mydie("die: program count < 10, please check program.\n");
		}
		
		echo "\tUpdate ({$program_num}) program.\r\n";
		echo "\tSet program country int.\r\n";
		
		$objProgram->setCountryInt($this->info["AffId"]);
	}
	
	function checkProgramOffline($AffId, $check_date){
		$objProgram = new ProgramDb();
		$prgm = array();
		$prgm = $objProgram->getNotUpdateProgram($this->info["AffId"], $check_date);

		if(count($prgm) > 30){
			mydie("die: too many offline program (".count($prgm).").\n");
		}else{
			$objProgram->setProgramOffline($this->info["AffId"], $prgm);
			echo "\tSet (".count($prgm).") offline program.\r\n";
		}
	}
}
?>
