<?php

require_once 'text_parse_helper.php';

class LinkFeed_1_CJ
{
	var $CJ_API_KEY = '00a500b5f1504ecdcc4a08e129e1f088c507a50fe5924fde3893a72563515da1fca5bcd3d97f1f8a5cace140561e57c4c1215e919e671f6147e210cd28d648e987/2b4fe37283a51bea5b28b78a19efdcc6f379c5917a75929c814da7c7c94cedbf0b086f208e58e8d161818cf21cf1323714baea9f605e15c5352a45a1bf1096a9';
	var $CJ_API_PID = '2567387';
	var $CJ_API_CID = '2149839';

	function __construct($aff_id, $oLinkFeed)
	{
		$this->oLinkFeed = $oLinkFeed;
		$this->info = $oLinkFeed->getAffById($aff_id);
		$this->debug = isset($oLinkFeed->debug) ? $oLinkFeed->debug : false;

		$this->file = "programlog_{$aff_id}_".date("Ymd_His").".csv";
		$this->soapClient = null;
	}

	function GetAllLinksFromAffByMerID($merinfo)
	{
		$arr_return = array("AffectedCount" => 0, "UpdatedCount" => 0, "Detail" => array(), );
		$request = array("AffId" => $this->info["AffId"], "method" => "get", "addheader" => array(sprintf('authorization:%s', $this->CJ_API_KEY)), );
		$page = 0;
		$perpage = 100;
		$items = 0;
		do
		{
			$page ++;
			$links = array();
			$url = sprintf("https://linksearch.api.cj.com/v2/link-search?website-id=%s&advertiser-ids=%s&page-number=%s&records-per-page=%s", $this->CJ_API_PID, $merinfo['IdInAff'], $page, $perpage);
			$r = $this->oLinkFeed->GetHttpResult($url, $request);
			$content = $r['content'];
			if (empty($items))
			{
				if (preg_match('@total-matched="(\d+)"@', $content, $g))
					$items = (int)$g[1];
				else
					break;
			}
			preg_match_all('@<link>(.*?)</link>@ms', $content, $chapters);
			foreach ((array)$chapters[1] as $chapter)
			{
				$link = array(
						"AffId" => $this->info["AffId"],
						"AffMerchantId" => $merinfo['IdInAff'],
						"AffLinkId" => '',
						"LinkName" =>  '',
						"LinkDesc" =>  '',
						"LinkStartDate" => '0000-00-00 00:00:00',
						"LinkEndDate" => '0000-00-00 00:00:00',
						"LinkPromoType" => 'DEAL',
						"LinkHtmlCode" => '',
						"LinkCode" => '',
						"LinkOriginalUrl" => '',
						"LinkImageUrl" => '',
						"LinkAffUrl" => '',
						"DataSource" => 4,
				);
				if (preg_match('@<link-code-html>(.*?)</link-code-html>@ms', $chapter, $g))
					$link['LinkHtmlCode'] = trim(html_entity_decode($g[1]));
				if (preg_match('@a href="(.*?)"@', $link['LinkHtmlCode'], $g))
					$link['LinkAffUrl'] = $g[1];
				if (preg_match('@img src="(.*?)"@', $link['LinkHtmlCode'], $g))
					$link['LinkImageUrl'] = $g[1];
				if (preg_match('@<description>(.*?)</description>@ms', $chapter, $g))
					$link['LinkDesc'] = trim(html_entity_decode($g[1]));
				if (preg_match('@<link-name>(.*?)</link-name>@ms', $chapter, $g))
					$link['LinkName'] = trim(html_entity_decode($g[1]));
				if (preg_match('@<link-id>(.*?)</link-id>@ms', $chapter, $g))
					$link['AffLinkId'] = trim(html_entity_decode($g[1]));
				if (preg_match('@<promotion-type>(.*?)</promotion-type>@ms', $chapter, $g))
				{
					switch (trim($g[1]))
					{
						case 'coupon':
							$link['LinkPromoType'] = 'coupon';
							break;
						case 'free shipping':
							$link['LinkPromoType'] = 'free shipping';
							break;
					}
				}
				if (preg_match('@<promotion-start-date>(.*?)</promotion-start-date>@ms', $chapter, $g))
					$link['LinkStartDate'] = parse_time_str(trim($g[1]), 'Y-m-d H:i:s', false);
				if (preg_match('@<promotion-end-date>(.*?)</promotion-end-date>@ms', $chapter, $g))
					$link['LinkEndDate'] = parse_time_str(trim($g[1]), 'Y-m-d H:i:s', false);
				$code = get_linkcode_by_text($link['LinkName'] . '|' . $link['LinkDesc'] . '|' . $link['LinkHtmlCode']);
				if (!empty($code))
				{
					$link['LinkCode'] = $code;
					$link['LinkPromoType'] = 'coupon';
				}
				if (empty($link['AffLinkId']) || empty($link['LinkName']))
					continue;
				$this->oLinkFeed->fixEnocding($this->info, $link, "feed");
				$links[] = $link;
				$arr_return["AffectedCount"] ++;
			}
			echo sprintf("program:%s, page:%s, %s links(s) found. \n", $merinfo['IdInAff'], $page, count($links));
			if(count($links) > 0)
				$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);
			// the api can call 25 times a minute
			// sleep 2 second maybe ok
			// sleep(2);
		}while ($page < 100 && $page * $perpage < $items);
		return $arr_return;
	}

	function getCouponFeed()
	{
		$arr_return = array("AffectedCount" => 0, "UpdatedCount" => 0, "Detail" => array(), );
		$this->oLinkFeed->LoginIntoAffService($this->info["AffId"],$this->info);
		$nNumPerPage = 100;
		$bHasNextPage = true;
		$nPageNo = 0;
		do
		{
			$links = array();
			$request = array("AffId" => $this->info["AffId"], "method" => "get", "postdata" => "", );
			$url = "https://members.cj.com/member/publisher/2149839/ads.json?page={$nPageNo}&promotionTypes=1%2C2%2C3%2C4%2C5%2C7&isEmpty=false&pageSize={$nNumPerPage}&sortColumn=dateLastModified&sortDescending=true";
			$r = $this->oLinkFeed->GetHttpResult($url, $request);
			$data = @json_decode($r["content"], true);
			if (empty($data) || !is_array($data) || empty($data['totalRecords']) || empty($data['records']) || !is_array($data['records']))
				break;
			$count = $data['totalRecords'];
			foreach ($data['records'] as $v)
			{
				$link = array(
					"AffId" => $this->info["AffId"],
					"AffMerchantId" => $v['cid'],
					"AffLinkId" => $v['id'],
					"LinkName" =>  $v['name'],
					"LinkDesc" =>  $v['description'],
					"LinkStartDate" => '0000-00-00 00:00:00',
					"LinkEndDate" => '0000-00-00 00:00:00',
					"LinkPromoType" => 'DEAL',
					"LinkHtmlCode" => '',
					"LinkCode" => '',
					"LinkOriginalUrl" => '',
					"LinkImageUrl" => '',
					"LinkAffUrl" => '',
					"DataSource" => 4,
				);
				if (!empty($v['promotionalStartDate']) && !empty($v['promotionalStartDate']['millisecDate']))
				{
					$date = (int)($v['promotionalStartDate']['millisecDate'] / 1000);
					if ($date > 946713600)
						$link['LinkStartDate'] = date('Y-m-d h:i:s', $date);
				}
				if (!empty($v['endDate']) && !empty($v['endDate']['millisecDate']))
				{
					$date = (int)($v['endDate']['millisecDate'] / 1000);
					if ($date > 946713600)
						$link['LinkEndDate'] = date('Y-m-d h:i:s', $date);
				}
				if ($v['promotionalTypeId'] == 5)
					$link['LinkPromoType'] = 'free shipping';
				else if ($v['promotionalTypeId'] == 1)
				{
					$link['LinkPromoType'] = 'coupon';
					if (!empty($v['couponCode']))
						$link['LinkCode'] = $v['couponCode'];
				}
				else
				{
					$link['LinkPromoType'] = $this->oLinkFeed->getPromoTypeByLinkContent($link['LinkName']);
					$code = get_linkcode_by_text($link['LinkName'] . '|' . $link['LinkDesc'] . '|' . $link['LinkHtmlCode']);
					if (!empty($code))
					{
						$link['LinkCode'] = $code;
						$link['LinkPromoType'] = 'coupon';
					}
				}
				if (empty($link['AffLinkId']) || empty($link['AffMerchantId']) || empty($link['LinkName']))
					continue;
				$links[] = $link;
				$arr_return["AffectedCount"] ++;
			}
			$ids = array();
			foreach ($links as $link)
				$ids[] = $link['AffLinkId'];

			$url = "https://members.cj.com/member/publisher/2149839/export/links.xml";
			$request = array("AffId" => $this->info["AffId"], "method" => "get", "postdata" => "", );
			$url .= "?ids=".implode(",", $ids)."&CONTID=2040083&jsContactId=2040083&jsCompanyId=2149839&jsCu=USD&jsDt=d-MMM-yyyy&jsLa=en&cjuMember=0";
			$r = $this->oLinkFeed->GetHttpResult($url, $request);
			$content = $r['content'];
			$data = @fgetcsv_str($content);
			foreach ($links as $key => $link)
			{
				foreach ($data as $v)
				{
					if ($v['LINK ID'] == $link['AffLinkId'])
					{
						if (!empty($v['CLICK URL']))
							$links[$key]['LinkAffUrl'] = $v['CLICK URL'];
						if (!empty($v['HTML LINKS']))
						{
							$links[$key]['LinkHtmlCode'] = $v['HTML LINKS'];
							break;
						}
					}
				}
				if (empty($link['LinkCode']))
				{
					$code = get_linkcode_by_text($link['LinkName'] . '|' . $link['LinkDesc'] . '|' . $link['LinkHtmlCode']);
					if (!empty($code))
					{
						$link['LinkCode'] = $code;
						$link['LinkPromoType'] = 'coupon';
					}
				}
			}
			echo sprintf("page:%s, %s links(s) found. \n", $nPageNo, count($links));
			if(count($links) > 0)
				$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);
			$nPageNo++;
			sleep(1);
		}while($nNumPerPage * ($nPageNo + 1) < $count && $nPageNo < 1000);
		return $arr_return;
	}

	function getInvalidLinks()
	{
		$request = array("AffId" => $this->info["AffId"], "method" => "get", "postdata" => "", );
		$url = 'https://members.cj.com/member/publisher/2149839/performanceReport/invalidLinks.csvx';
		$this->oLinkFeed->LoginIntoAffService($this->info["AffId"], $this->info);
		$r = $this->oLinkFeed->GetHttpResult($url, $request);
		$content = $r['content'];
		$data = @fgetcsv_str($content);
		if (empty($data) || !is_array($data))
			return;
		$links = array();
		$ids = array();
		foreach ($data as $v)
		{
			if (empty($v['LINK ID']))
				continue;
			if (!empty($ids[$v['LINK ID']]))
			{
//				echo sprintf("duplicate id: %s.\n", $v['LINK ID']);
				continue;
			}
			$ids[$v['LINK ID']] = 1;
			$link = array(
					'affiliate' => $this->info["AffId"],
					'LinkID' => $v['LINK ID'],
					'ReferralUrl' => $v['REFERRING URL'],
					'ProgramName' => $v['ADVERTISER NAME'],
					'AffiliationStatus' => $v['AFFILIATION STATUS'],
					'Clicks' => $v['CLICKS'],
					);
			// http://mantis.megainformationtech.com/view.php?id=432 
			// 过滤CJ联盟状态为Declined Application/Advertiser Expired/Pending Application/No Relationship的Tasks，仅将联盟状态为Active的生成Tasks
			if (trim(strtolower($link['AffiliationStatus'])) != 'active')
				continue;
			$links[] = $link;
		}
		return $links;
	}

	function getMessage()
	{
		$messages = array();
		$request = array("AffId" => $this->info["AffId"], "method" => "get", "postdata" => "", );
		$this->oLinkFeed->LoginIntoAffService($this->info["AffId"], $this->info);
		$url = 'https://members.cj.com/member/2040083/accounts/publisher/mail/affil_mail_home.jsp?ar_inbox=1&ar_FID=10728952';
		$r = $this->oLinkFeed->GetHttpResult($url, $request);
		$content = $r['content'];
		preg_match_all('@<tr bgcolor="#eeeeee">(.*?)</tr>@mis', $content, $chapters);
		if (empty($chapters) || !is_array($chapters) || empty($chapters[1]) || !is_array($chapters[1]))
			return 'no message found.';
		foreach ($chapters[1] as $chapter)
		{
			$data = array(
					'affid' => $this->info["AffId"],
					'messageid' => '',
					'sender' => '',
					'title' => '',
					'content' => '',
					'created' => '0000-00-00',
					);
			if (preg_match('@<a href="#".*?>(.*?)<@', $chapter, $g))
				$data['sender'] = $g[1];
			if (preg_match('@ar_MSGID=(\d+)@', $chapter, $g))
				$data['messageid'] = $g[1];
			if (preg_match('@href="(.*?)".*?OpenWithCrumbTrail\(.*?return false">(.*?)<@', $chapter, $g))
			{
				$data['content_url'] = 'https://members.cj.com' . $g[1];
				$data['title'] = $g[2];
			}
			if (preg_match('@"rightCellText">(.*?)<@', $chapter, $g))
				$data['created'] = parse_time_str($g[1], null, false);
			if (empty($data['messageid']) || empty($data['title']))
				continue;
			$messages[] = $data;
		}
		return $messages;
	}

	function getMessageDetail($data)
	{
		$request = array("AffId" => $this->info["AffId"], "method" => "get", "postdata" => "", );
		$this->oLinkFeed->LoginIntoAffService($this->info["AffId"], $this->info);
		$url = $data['content_url'];
		$r = $this->oLinkFeed->GetHttpResult($url, $request);
		$content = $r['content'];
		if (preg_match('@class="displayIndentCol">(.*?)</td>@ms', $content, $g))
			$data['content'] = str_force_utf8(trim(html_entity_decode($g[1])));
		return $data;
	}

	function GetProgramFromAff()
	{
		$check_date = date("Y-m-d H:i:s");
		echo "Craw Program start @ {$check_date}\r\n";

		$this->GetProgramByApi();
		$this->checkProgramOffline($this->info["AffId"], $check_date);

		echo "Craw Program end @ ".date("Y-m-d H:i:s")."\r\n";
	}

	function GetProgramByApi()
	{
		echo "\tGet Program by api start\r\n";
		$objProgram = new ProgramDb();
		$arr_prgm = array();
		$program_num = 0;
		$request = array("AffId" => $this->info["AffId"], "method" => "post", "postdata" => "",);

		//step 1,login
		$this->oLinkFeed->LoginIntoAffService($this->info["AffId"],$this->info);
		$link = "https://advertiser-lookup.api.cj.com/v3/advertiser-lookup?";
		$order_arr = array("joined", "notjoined");
		
		echo "\t get Support Deep Url\r\n";
		$arr_deepdomain = $this->getSupportDeepUrl();

		foreach($order_arr as $v)
		{
			list($nPageNo, $nNumPerPage, $bHasNextPage, $nPageTotal) = array(1, 100, true, 1);
			while($bHasNextPage)
			{
				$param = array(
						"advertiser-ids={$v}",	//CIDs,joined,notjoined
						"advertiser-name=",
						"keywords=",
						"page-number={$nPageNo}",
						"records-per-page={$nNumPerPage}",
						//"mobile-tracking-certified=false",
				);
				$postdata = implode("&",$param);
				$strUrl = $link.$postdata;
				$request = array("method" => "get", "addheader" => array("authorization: {$this->CJ_API_KEY}"),);
				$cache_file = $this->oLinkFeed->fileCacheGetFilePath($this->info["AffId"],"advertiser_xml_".date("YmdH")."_{$v}{$nPageNo}.dat","cache_feed");
				if(!$this->oLinkFeed->fileCacheIsCached($cache_file))
				{
					$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
					$result = $r["content"];
					$this->oLinkFeed->fileCachePut($cache_file,$result);
				}

				$xml = new DOMDocument();
				$xml->load($cache_file);
				$return_info = $xml->getElementsByTagName("advertisers");
				foreach($return_info as $info)
				{
		  			$total_matched = $info->getAttribute("total-matched");
		  			$records_returned = $info->getAttribute("records-returned");
		  			$page_number = $info->getAttribute("page-number");
				}
				unset($return_info);

				//Check if have next page;
				$nPageTotal = ceil($total_matched/$nNumPerPage);
				$bHasNextPage = $page_number;
				if ($nPageNo >= $nPageTotal || $records_returned < 1)
				{
					$bHasNextPage = false;
					if($this->debug) print " NO NEXT PAGE  <br>\n";
				}
				else
				{
					$nPageNo++;
					if($this->debug) print " Have NEXT PAGE  <br>\n";
				}

				$advertiser_list = $xml->getElementsByTagName("advertiser");
				foreach($advertiser_list as $advertiser)
				{
					$advertiser_info = array();
					$childnodes = $advertiser->getElementsByTagName("*");
					foreach($childnodes as $node){
						$advertiser_info[$node->nodeName] = trim($node->nodeValue);
					}

					$IdInAff = trim($advertiser_info["advertiser-id"]);
					$Name = $advertiser_info["advertiser-name"];
					if(empty($IdInAff) || empty($Name))continue;

					$StatusInAff = $advertiser_info["account-status"];
					$EPCDefault = $advertiser_info["seven-day-epc"];
					$EPC90d = $advertiser_info["three-month-epc"];
					$Homepage = $advertiser_info["program-url"];
					$Partnership = $advertiser_info["relationship-status"];
					$RankInAff = intval($advertiser_info["network-rank"]);
					if($RankInAff == 6){//means this program is new, do not have rank yet.
						$RankInAff = 0;
					}
					if($Partnership == "joined"){
						$Partnership = "Active";
					}else{
						$Partnership = "NoPartnership";
					}
					if(!in_array($StatusInAff, array('Active','TempOffline','Offline'))){
						$StatusInAff = 'Offline';
					}
					
					$arr_prgm[$IdInAff] = array("Name" => addslashes(trim($Name)),
							"IdInAff" => $IdInAff,
							"AffId" => $this->info["AffId"],
							"Homepage" => addslashes($Homepage),
							"RankInAff" => $RankInAff,
							"StatusInAffRemark" => addslashes($advertiser_info["account-status"]),
							"StatusInAff" => $StatusInAff,						//'Active','TempOffline','Offline'
							"Partnership" => $Partnership,						//'NoPartnership','Active','Pending','Declined','Expired','Removed'
							"EPCDefault" => trim(preg_replace("/[^0-9.-]/", "", $EPCDefault)),
							"EPC90d" => trim(preg_replace("/[^0-9.-]/", "", $EPC90d)),
							"LastUpdateTime" => date("Y-m-d H:i:s"),
							"MobileFriendly" => 'UNKNOWN'							
							);
					if ($advertiser_info['mobile-tracking-certified'] == 'true')
						$arr_prgm[$IdInAff]['MobileFriendly'] = 'YES';
					else if ($advertiser_info['mobile-tracking-certified'] == 'false')
						$arr_prgm[$IdInAff]['MobileFriendly'] = 'NO';
						
					if(count($arr_deepdomain)){
						$Homepage = preg_replace("/^https?:\/\//i", "", $Homepage);
						$arr_prgm[$IdInAff]['SupportDeepUrl'] = isset($arr_deepdomain[$Homepage]) ? "YES" : "NO";
					}
						
					/************************************************************************************************************************************************/						
					//program_detail
					$request = array("AffId" => $this->info["AffId"], "method" => "get",);
					$prgm_url = "https://members.cj.com/member/accounts/publisher/getadvertiserdetail.do?advertiserId=$IdInAff";
					$prgm_arr = $this->oLinkFeed->GetHttpResult($prgm_url, $request);
					$prgm_detail = $prgm_arr["content"];
					if($prgm_arr["code"] == 200)
					{
						$contact = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, '<strong>Contact:</strong>', '<br />'));
						$contact .= trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, '<strong>Email:</strong>', '<br />'));
						$TargetCountryExt = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, '<strong>Country:</strong>', '<br />'));
						$JoinDate = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, '<strong>Joined Network:</strong>', '<br />'));
						$JoinDate = date("Y-m-d H:i:s", strtotime($JoinDate));
						$CategoryExt = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, '<strong>Category:</strong>', '<a'));
						$desc = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, '<strong>Description:</strong>', 'Relationship History</a>'))."Relationship History</a>";
						$desc = preg_replace("/[\\r|\\n|\\r\\n]/is", '', $desc);
						$desc = preg_replace('/<([a-z]+?)\s+?.*?>/i','<$1>', $desc);
						$CommissionExt = "<table>".$this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('Program Term','<table width="100%" border="0" cellpadding="0" cellspacing="0">'), '<input name="advertiserId" type="hidden"')."</table>";
						$CommissionExt = preg_replace("/[\\r|\\n|\\r\\n]/is", '', $CommissionExt);
						$CommissionExt = preg_replace('/<([a-z]+?)\s+?.*?>/i','<$1>', $CommissionExt);
						$CommissionExt = preg_replace("/[\\t]/is", '', $CommissionExt);
						$CommissionExt = str_replace("€", "&euro;", $CommissionExt);
						$TermAndCondition = $this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('Policies','<table class="report">'), '</table>');
						$TermAndCondition = preg_replace("/[\\r|\\n|\\r\\n]/is", '', $TermAndCondition);
						$TermAndCondition = preg_replace('/<([a-z]+?)\s+?.*?>/i','<$1>', $TermAndCondition);
						$TermAndCondition = preg_replace("/[\\t]/is", '', $TermAndCondition);						

						$arr_prgm[$IdInAff] += array(
								"Name" => addslashes(trim($Name)),
								"AffId" => $this->info["AffId"],
								"TargetCountryExt" => addslashes($TargetCountryExt),
								"JoinDate" => $JoinDate,
								"CategoryExt" => addslashes($CategoryExt),
								"Contacts" => addslashes($contact),
								"Description" => addslashes($desc),
								"IdInAff" => $IdInAff,
								"TermAndCondition" => "",
								"CommissionExt" => addslashes($CommissionExt),
								"SEMPolicyExt" => "",
								"ProtectedSEMBiddingKeywords" => "",
								"NonCompeteSEMBiddingKeywords" => "",
								"RecommendedSEMBiddingKeywords" => "",
								"ProhibitedSEMDisplayURLContent" => "",
								"LimitedUseSEMDisplayURLContent" => "",
								"ProhibitedSEMAdCopyContent" => "",
								"LimitedUseSEMAdCopyContent" => "",
								"AuthorizedSearchEngines" => "",
								"SpecialInstructionsForSEM" => "",
								"ProhibitedWebSiteURLAndContent" => "",
								"UnacceptableWebSitesExt" => "",
								"CouponCodesPolicyExt" => "",
								"SubAffPolicyExt" => "",
								"AllowedDirectLink" => "",
								"DetailPage" => $prgm_url,
								"LastUpdateTime" => date("Y-m-d H:i:s"),
						);
						$term_arr = array(	"SEMPolicyExt" => "Protected SEM Bidding Keywords",
								"ProtectedSEMBiddingKeywords" => "Protected SEM Bidding Keywords",
								"NonCompeteSEMBiddingKeywords" => "Non-compete SEM Bidding Keywords",
								"RecommendedSEMBiddingKeywords" => "Recommended SEM Bidding Keywords",
								"ProhibitedSEMDisplayURLContent" => "Prohibited SEM Display URL Content",
								"LimitedUseSEMDisplayURLContent" => "Limited Use SEM Display URL Content",
								"ProhibitedSEMAdCopyContent" => "Prohibited SEM Ad Copy Content",
								"LimitedUseSEMAdCopyContent" => "Limited Use SEM Ad Copy Content",
								"AllowedDirectLink" => "Direct Linking",
								"AuthorizedSearchEngines" => "Authorized Search Engines",
								"website_keywords" => "Prohibited Web Site Domain Keywords",
								"website_content" => "Prohibited Web Site Content",
								"website_url" => "Prohibited Web Site URL Keywords",
								"SpecialInstructionsForSEM" => "Special Instructions for Search Marketing Publishers",
								"UnacceptableWebSitesExt" => "Unacceptable Web Sites",
								"CouponCodesPolicyExt" => "Coupons and Promotional Codes",
								"SubAffPolicyExt" => "Sub-Affiliates",
							);
						$ProhibitedWebSiteURLAndContent = "";

						$TermAndCondition = str_replace(array("\r","\t","\n"),"", $TermAndCondition);
						$temp_term_table = explode("</tr><tr>", $TermAndCondition);
						foreach($temp_term_table as $kk => $vv)
						{
							foreach($term_arr as $key => $val)
							{
								if(strpos($vv, $val) !== false)
								{
									if($key == "website_keywords"){
										$ProhibitedWebSiteURLAndContent = "Prohibited Web Site Domain Keywords: " . $this->oLinkFeed->ParseStringBy2Tag($vv, array($val, '<td>'), '</td>') . "<br />";
									}elseif($key == "website_url"){
										$ProhibitedWebSiteURLAndContent .= "Prohibited Web Site URL Keywords: " . $this->oLinkFeed->ParseStringBy2Tag($vv, array($val, '<td>'), '</td>') . "<br />";
									}elseif($key == "website_content"){
										$ProhibitedWebSiteURLAndContent .= "PProhibited Web Site Content: " . $this->oLinkFeed->ParseStringBy2Tag($vv, array($val, '<td>'), '</td>');
									}else{
										$arr_prgm[$IdInAff][$key] = addslashes($this->oLinkFeed->ParseStringBy2Tag($vv, array($val, '<td>'), '</td>'));
									}
									unset($temp_term_table[$kk]);
									break;
								}
							}
						}
						if(count($temp_term_table) > 1){
							$TermAndCondition = "<table>".implode("</tr><tr>", $temp_term_table)."</table>";
						}else{
							$TermAndCondition = "";
						}
						$arr_prgm[$IdInAff]["ProhibitedWebSiteURLAndContent"] = addslashes($ProhibitedWebSiteURLAndContent);
						$arr_prgm[$IdInAff]["TermAndCondition"] = addslashes($TermAndCondition);
					}
					/************************************************************************************************************************************************/

					$program_num++;
					
					if(count($arr_prgm) >= 100){
						$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
						//$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
						//$objProgram->setCountryInt($this->info["AffId"]);
						$arr_prgm = array();
					}
				}
			}
			if(count($arr_prgm)){
				$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
				//$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);				
				unset($arr_prgm);
			}
		}

		echo "\tGet Program by api end\r\n";
		if($program_num < 10){
			mydie("die: program count < 10, please check program.\n");
		}
		echo "\tUpdate ({$program_num}) program.\r\n";
		echo "\tSet program country int.\r\n";
		$objProgram->setCountryInt($this->info["AffId"]);
	}

	function checkProgramOffline($AffId, $check_date){
		$objProgram = new ProgramDb();
		$prgm = array();
		$prgm = $objProgram->getNotUpdateProgram($this->info["AffId"], $check_date);
		$this->recheckProgram($prgm);
		$prgm = $objProgram->getNotUpdateProgram($this->info["AffId"], $check_date);
		if(count($prgm) > 30){			
			mydie("die: too many offline program (".count($prgm).").\n");
			echo print_r($prgm, 1);
		}else{
			$objProgram->setProgramOffline($this->info["AffId"], $prgm);
			echo "\tSet (".count($prgm).") offline program.\r\n";
		}
	}
	
	
	function recheckProgram($prgm){
		$arr_prgm = array();
		$this->oLinkFeed->LoginIntoAffService($this->info["AffId"],$this->info);
		$request = array("AffId" => $this->info["AffId"], "method" => "get",);
		foreach($prgm as $v){
			$prgm_url = "https://members.cj.com/member/publisher/2149839/ads.json?page=0&advertiserIds={$v['IdInAff']}&isEmpty=false&pageSize=50&sortColumn=advertiserName&sortDescending=false";
			$prgm_arr = $this->oLinkFeed->GetHttpResult($prgm_url, $request);
			//$prgm_detail = $prgm_arr["content"];
			if($prgm_arr["code"] == 200)
			{
				$tmp_arr = array();
				$tmp_arr = json_decode($prgm_arr["content"]);
				if($tmp_arr->totalRecords > 0){				
					$arr_prgm[$v['IdInAff']] = array(
								"AffId" => $this->info["AffId"],								
								"IdInAff" => $v['IdInAff'],								
								"LastUpdateTime" => date("Y-m-d H:i:s")
							);
				}
			}
		}
		if(count($arr_prgm)){
			$objProgram = new ProgramDb();
			$objProgram->updateProgram($this->info["AffId"], $arr_prgm);			
		}
	}
	
	function getSupportDeepUrl(){
		//http://[CJDOMAINS]/links/[SITEIDINAFF]/type/dlg/sid/[SUBTRACKING]/[PURE_DEEPURL]
		$domains_arr = array();
		$url = "http://www.yceml.net/am_gen/2567387/include/allCj/am.js";
		$tmp_arr = $this->oLinkFeed->GetHttpResult($url, array("method" => "get"));
		if($tmp_arr["code"] == 200){
			$domains = trim($this->oLinkFeed->ParseStringBy2Tag($tmp_arr["content"], 'domains=[', ']'));
			$domains_arr = array_flip(explode("','", trim($domains,"'")));
		}
		return $domains_arr;
	}
						
}
