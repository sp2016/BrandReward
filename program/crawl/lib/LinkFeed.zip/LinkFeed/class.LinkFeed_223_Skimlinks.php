<?php
class LinkFeed_223_Skimlinks
{
	function __construct($aff_id,$oLinkFeed)
	{
		$this->oLinkFeed = $oLinkFeed;
		$this->info = $oLinkFeed->getAffById($aff_id);
		$this->debug = isset($oLinkFeed->debug) ? $oLinkFeed->debug : false;
		
		$this->file = "programlog_{$aff_id}_".date("Ymd_His").".csv";
	}
	
	
	
	function GetProgramByApi()
	{
		echo "\tGet Program by api start\r\n";
		$objProgram = new ProgramDb();
		$arr_prgm = array();
		$program_num = 0;
		
		$request = array("AffId" => $this->info["AffId"],"method" => "get","postdata" => "");
		
		//step 1,login	
		//$this->oLinkFeed->LoginIntoAffService($this->info["AffId"],$this->info);
		
		$api_key = "1dbf8ab3e0df1a1710239e9b8ceaf472";
		
		//get cateory
		/*$category_arr = array();
		
		$cache_file = $this->oLinkFeed->fileCacheGetFilePath($this->info["AffId"],"category.dat","cache_merchant");
		if(!$this->oLinkFeed->fileCacheIsCached($cache_file))
		{
			//step 1,login
			$this->oLinkFeed->LoginIntoAffService($this->info["AffId"],$this->info);
			
			$strUrl = "http://api-merchants.skimlinks.com/merchants/xml/{$api_key}/categories";
			$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
			$result = $r["content"];
			
			if(stripos($result,"</skimlinksCategories>") === false)
			{
				print_r($r);
				mydie("die: get feed failed, wrong xml format\n");
			}
			
			$this->oLinkFeed->fileCachePut($cache_file,$result);
		}
		if(!file_exists($cache_file)) mydie("die: get file failed.\n");
		
		$xml = new DOMDocument();
		$xml->load($cache_file);
		$category_list = $xml->getElementsByTagName("category");
		foreach($category_list as $category)
		{
			$category_info = array();
			$childnodes = $category->getElementsByTagName("*");
			foreach($childnodes as $node) {
				if ($node->nodeName == "children") break;
				$category_info[$node->nodeName] = trim($node->nodeValue);
				
				//echo $node->nodeName ."->". trim($node->nodeValue)."<br>";
			}
			
			$category_arr[] = $category_info;
		}	
		//print_r($category_arr);
		$ignored_domain = array();
		$ignored_domain = $this->getIgnoredMerDomain();
			
		
		foreach($category_arr as $category){
			$cat_id = intval($category["id"]);
			$CategoryExt = trim($category["name"]);
			
			if($cat_id){
				$hasNextPage = true;			
				$perPage = 200;				
				$page = 0;
				
				while($hasNextPage){
					$start = $page*$perPage;
					$strUrl = "http://api-merchants.skimlinks.com/merchants/json/{$api_key}/category/{$cat_id}/limit/{$perPage}/start/{$start}";
					$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
					$result = $r["content"];		
						
					$result = json_decode($result);
					//print_r($result);exit;					
					
					$numFound = intval($result->numReturned);
					if(!$numFound) break;					
					if($perPage < $numFound){
						$hasNextPage = false;
					}
					
					$merchant_list = $result->merchants;
					foreach($merchant_list as $v)
					{
						$IdInAff = intval($v->merchantID);
						if(!$IdInAff) continue;
						
						$strMerName = $v->merchantName;
						$CommissionExt = $v->averageCommission;
						
						$StatusInAffRemark = "";
						$Partnership = "Active";						
						
						$Homepage = "";
						if(isset($v->domains)){
							$domains = $v->domains;
							foreach($domains as $domain){
								if(isset($ignored_domain[$domain])){
									$StatusInAffRemark = "merchant don't cooperate with skimlinks";
									$Partnership = "NoPartnership";
									$Homepage = $domain;
									break;
								}else{								
									$Homepage = $domain;									
								}
							}
						}
						
						$TargetCountryExt = "";
						if(isset($v->countries)){
							$countries = $v->countries;
							foreach($countries as $country){
								if($country){
									$TargetCountryExt = $country;
									break;
								}
							}
						}
						
						$arr_prgm[$IdInAff] = array(
							"Name" => addslashes((trim($strMerName))),
							"AffId" => $this->info["AffId"],				
							"CategoryExt" => addslashes($CategoryExt),							
							"TargetCountryExt" => addslashes($TargetCountryExt),
							"IdInAff" => $IdInAff,
							"StatusInAffRemark" => addslashes($StatusInAffRemark),					
							"StatusInAff" => "Active",						//'Active','TempOffline','Offline'							
							"Partnership" => addslashes($Partnership),						//'NoPartnership','Active','Pending','Declined','Expired','WeDeclined'							
							"Homepage" => addslashes($Homepage),							
							"CommissionExt" => addslashes($CommissionExt),
							"LastUpdateTime" => date("Y-m-d H:i:s"),						
							//"DetailPage" => $prgm_url,
						);
						
						$program_num++;
						//print_r($arr_prgm);
						if(count($arr_prgm) >= 100){
							$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
							$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
							$arr_prgm = array();
						}
					}

					$page++;
				}
			}
			
		}
		
		if(count($arr_prgm)){
			$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
			$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
			$arr_prgm = array();
		}*/
		
		//get domains		
		$hasNextPage = true;			
		$perPage = 200;				
		$page = 0;
		
		$ignored_domain = array();
		$ignored_domain = $this->getIgnoredMerDomain();
		//print_r($ignored_domain);
		
		$aff_url_keyword = array();
		$aff_url_keyword = $objProgram->getAffiliateUrlKeywords();
		
		// for check if through main aff
		$commint_zero_prgm = array();
		$commint_zero_prgm = $objProgram->getCommIntProgramByAffId($this->info["AffId"]);
		
		// Internal EPC=0 
		$internal_prgm = array();
		/*$fp = fopen("http://couponsn:IOPkjmN1@reporting.megainformationtech.com/dataapi/offline_program.php?affid=".$this->info["AffId"], "r");
		if($fp){
			echo "\t get Internal EPC=0 program succeed.\n";
			$i = 0;
			while(!feof($fp))
			{
				$line = trim(fgets($fp));
				if(!$line) continue;
				$tmp_arr = explode("\t", $line);//Id in Aff, Program Name, Sales, Commission, CR(Commission Rate)
				
				$affid = intval($tmp_arr[0]);				
				$idinaff = trim($tmp_arr[1]);
				
			
				if($affid == $this->info["AffId"]){					
					$internal_prgm[$idinaff] = 1;
					$i++;
				}
			}
			fclose($fp);
			echo "\t get ($i) Internal EPC=0 program\n";
		}else{
			echo "\t Internal EPC=0 program failed.\n";
		}*/
		
		while($hasNextPage){
			$start = $page*$perPage;
			$strUrl = "http://api-merchants.skimlinks.com/merchants/json/{$api_key}/domains/limit/{$perPage}/start/{$start}";
			$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
			
			if($r["code"] != 200) continue;
			
			$result = $r["content"];
		
			$result = json_decode($result);
			//print_r($result);exit;
			
			$numFound = intval($result->numReturned);
			if(!$numFound) break;					
			if($perPage < $numFound){
				$hasNextPage = false;
			}
			
			$domain_list = $result->domains;
			foreach($domain_list as $domain)
			{
				$strUrl = "http://api-merchants.skimlinks.com/merchants/json/{$api_key}/search/{$domain}";
				$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
				$result = $r["content"];
				
				if($r["code"] != 200) continue;
			
				$result = json_decode($result);
				//print_r($result);exit;
				
				$merchant_list = $result->merchants;
				foreach($merchant_list as $val)
				{
					$IdInAff = intval($val->merchantID);
					if(!$IdInAff) continue;
					
					//if(!isset($internal_prgm[$IdInAff])) continue;
					
					$strMerName = $val->merchantName;					
					
					
					
					$strUrl = "http://api-merchants.skimlinks.com/merchants/json/{$api_key}/search/".urlencode($strMerName);
					$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
					$result = $r["content"];
					if($r["code"] != 200) continue;
				
					$result = json_decode($result);
					//print_r($result);exit;
					$merchants = $result->merchants;

					$v = array();
					foreach($merchants as $merchant){
						if($IdInAff == $merchant->merchantID){
							$v = $merchant;
						}
					}
					
					//$v = $merchants[0];
					
					if(!intval($v->merchantID)) continue;
					
					$CommissionExt = $v->averageCommission;
					
					$StatusInAffRemark = "";
					$Partnership = "Active";					
					
					$Homepage = "";
					$desc = array();
					if(isset($v->domains)){
						$domains = $v->domains;
						//print_r($domains);
						foreach($domains as $domain){
							$desc[] = $domain;
							if(isset($ignored_domain[$domain])){
								$StatusInAffRemark = "merchant don't cooperate with skimlinks";
								$Partnership = "NoPartnership";
								$Homepage = $domain;
								//break;
							}else{
								$Homepage = $domain;
							}
						}
					}
					$desc = implode(", \r\n", $desc);
					
					/*$through_main_aff = true;
					if($Partnership == "Active" && (isset($internal_prgm[$IdInAff]) || isset($commint_zero_prgm[$IdInAff]))){
						$through_main_aff = false;
						// check $aff_url_keyword
						foreach($domains as $test_domain){
							if(!preg_match("/^(https?|ftp):\\/\\//i", $test_domain)){
								$test_domain = "http://".$test_domain;
							}
							$test_url = "http://go.redirectingat.com?id=7438X662619&xcust=&xs=1&url=".urlencode($test_domain);
							//$r = $this->oLinkFeed->GetHttpResult($test_url, array("header" => 1, "nobody" => 1, "verbose" => 1, "stderr_temp" => 1));
							$r = $this->oLinkFeed->GetHttpResult($test_url, array("header" => 1, "verbose" => 1, "stderr_temp" => 1));
							$header = $r["content"];
							//if($r["code"] != 200) continue;
							
							//preg_match_all("/domain.=([A-Za-z0-9.]+)/i", $header, $matches);
							preg_match_all("/Location:(.*)\r\n/i", $header, $matches);							
							if(count($matches[1])){
								//$domain_arr = array_unique($matches[1]);
								//$tmp_arr = array_intersect($aff_url_keyword, $domain_arr);					
								foreach($aff_url_keyword as $url_k){
									foreach($matches[1] as $loc){
										if(stripos($loc, $url_k) !== false){
											$through_main_aff = true;
											break 3;
										}
									}
								}								
							}
							
							if($r["code"] == 200){
								preg_match_all("/<iframe.*src=['|\\\"](.*)['|\\\"].*<\\/iframe>/i", $header, $matches);							
								if(count($matches[1] && isset($matches[1][0]) && strlen($matches[1][0]) > 0) ){
									foreach($aff_url_keyword as $url_k){
										if(stripos($matches[1][0], $url_k) !== false){								
											$through_main_aff = true;
											break 2;
										}
									}
								}
							}
							
							if(!empty($r["verbose"])){
								preg_match_all("/Host:(.*)\r\n/i", $r["verbose"], $matches);								
								if(count($matches[1])){									
									foreach($aff_url_keyword as $url_k){
										foreach($matches[1] as $loc){
											if(stripos($loc, $url_k) !== false){
												$through_main_aff = true;
												break 3;
											}
										}
									}									
								}
							}
						}
					}
					
					if($through_main_aff == false){
						if(isset($internal_prgm[$IdInAff])){
							$StatusInAffRemark = "Internal EPC=0";
						}else{
							$StatusInAffRemark = "Not Through Main Aff";
						}
						$Partnership = "NoPartnership";
					}*/
					
					$TargetCountryExt = "";
					if(isset($v->countries)){
						$countries = $v->countries;
						foreach($countries as $country){
							if($country){
								$TargetCountryExt = $country;
								break;
							}
						}
					}
					
					$CategoryExt = "";
					if(isset($v->categories)){
						$categories = $v->categories;
						foreach($categories as $category){
							if($category){
								$CategoryExt = $category;
								break;
							}
						}
					}
					
					//$AffDefaultUrl = "http://go.redirectingat.com?id=7438X662619&xcust=[SUBTRACKING]&xs=1&url=http%3A%2F%2Fwww.{$Homepage}";
					
					$arr_prgm[$IdInAff] = array(
						"Name" => addslashes((trim($strMerName))),
						"AffId" => $this->info["AffId"],
						"CategoryExt" => addslashes($CategoryExt),							
						"TargetCountryExt" => addslashes($TargetCountryExt),
						"Description" => addslashes($desc),
						"IdInAff" => $IdInAff,
						"StatusInAffRemark" => addslashes($StatusInAffRemark),					
						"StatusInAff" => "Active",						//'Active','TempOffline','Offline'							
						"Partnership" => addslashes($Partnership),						//'NoPartnership','Active','Pending','Declined','Expired','WeDeclined'							
						"Homepage" => addslashes($Homepage),
						"CommissionExt" => addslashes($CommissionExt),
						"LastUpdateTime" => date("Y-m-d H:i:s"),
						"SupportDeepUrl" => 'YES',
						//"AffDefaultUrl" => addslashes($AffDefaultUrl)
						//"DetailPage" => $prgm_url,
					);
					
					$program_num++;
					//print_r($arr_prgm);exit;
					if(count($arr_prgm) >= 100){
						$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
						$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
						$arr_prgm = array();						
					}
				}
			}
			
			//print_r($result);exit;
			$page++;
		}
		
		if(count($arr_prgm)){
			$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
			$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
			$arr_prgm = array();
		}
		
		echo "\tGet Program by api end\r\n";
		
		if($program_num < 10){
			mydie("die: program count < 10, please check program.\n");
		}
		
		echo "\tUpdate ({$program_num}) program.\r\n";
		echo "\tSet program country int.\r\n";
		$objProgram->setCountryInt($this->info["AffId"]);
	}
	
	function GetProgramFromAff()
	{	
		$check_date = date("Y-m-d H:i:s");
		echo "Craw Program start @ {$check_date}\r\n";
		
		$this->GetProgramByApi();		
		$this->checkProgramOffline($this->info["AffId"], $check_date);

		echo "Craw Program end @ ".date("Y-m-d H:i:s")."\r\n";
	}
	
	function checkProgramOffline($AffId, $check_date){
		$objProgram = new ProgramDb();
		$prgm = array();
		$prgm = $objProgram->getNotUpdateProgram($this->info["AffId"], $check_date);
		
		if(count($prgm) > 30){
			mydie("die: too many offline program (".count($prgm).").\n");
		}else{			
			$objProgram->setProgramOffline($this->info["AffId"], $prgm);
			echo "\tSet (".count($prgm).") offline program.\r\n";
		}
	}
	
	function getIgnoredMerDomain(){
		$domain_arr = array();
		$fhandle = fopen(INCLUDE_ROOT."lib/slimlinks_ignored_mer.csv", 'r');
		if($fhandle){
			while($line = fgetcsv ($fhandle, 5000))
			{
				foreach($line as $k => $v) $line[$k] = trim($v);			
				if ($line[0] == '') continue;	
				
				$domain_arr[$line[0]] = 1;				
			}
		}
		return $domain_arr;
	}
}
?>
