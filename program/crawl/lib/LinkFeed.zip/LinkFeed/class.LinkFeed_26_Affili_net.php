<?php
require_once 'text_parse_helper.php';
include_once(dirname(__FILE__) . "/class.LinkFeed_Affili_net.php");
class LinkFeed_26_Affili_net extends LinkFeed_Affili_net
{
	function __construct($aff_id,$oLinkFeed)
	{
		$this->oLinkFeed = $oLinkFeed;
		$this->info = $oLinkFeed->getAffById($aff_id);
		$this->debug = isset($oLinkFeed->debug) ? $oLinkFeed->debug : false;

		$this->file = "programlog_{$aff_id}_".date("Ymd_His").".csv";
		$this->soapToken = null;
		$this->soapClient = null;
		$this->soapInboxClient = null;
		$this->DataSource = 28;
		$this->API_USERNAME = 499752;
		$this->API_PASSWORD = 'VOm9SxFjGSlRkKn8NiAt';
	}

}

