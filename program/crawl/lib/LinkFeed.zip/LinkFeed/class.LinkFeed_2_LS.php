<?php

require_once 'text_parse_helper.php';
require_once 'xml2array.php';
define('API_TOKEN_2', 'fb80d7cf065af3909fdb367a99a0893b2ed058724315c0a9b4b282ca82ad18bb');
define('MOUSE_OVER_OID_2', '240317');

class LinkFeed_2_LS
{
	function __construct($aff_id, $oLinkFeed)
	{
		$this->oLinkFeed = $oLinkFeed;
		$this->info = $oLinkFeed->getAffById($aff_id);
		$this->debug = isset($oLinkFeed->debug) ? $oLinkFeed->debug : false;
		
		$this->file = "programlog_{$aff_id}_".date("Ymd_His").".csv";
	}

	function getStatusByStr($str)
	{
		if(stripos($str,'No Relationship') !== false) return 'not apply';
		elseif(stripos($str,'Pending') !== false) return 'pending';
		elseif(stripos($str,'Approved') !== false) return 'approval';
		elseif(stripos($str,'Discontinued') !== false) return 'siteclosed';
		elseif(stripos($str,'Declined') !== false) return 'declined';
		elseif(stripos($str,'Removed') !== false) return 'expired';
		elseif(stripos($str,'Extended') !== false) return 'approval';
		return false;
	}

	function GetAllLinksFromAffByMerID($merinfo, $newonly=true)
	{
		$arr_return = array("AffectedCount" => 0, "UpdatedCount" => 0, );
		$request = array("AffId" => $this->info["AffId"], "method" => "post", "postdata" => "", );

		// MerID_NetworkID
		$r = explode('_', $merinfo["IdInAff"]);
		if(sizeof($r) != 2 || !is_numeric($r[1]) || !is_numeric($r[0]))
		{
			echo " Invalid Merchant ID($AffMerchantId). It should be 'MerchantID_NetworkID' .Please check <a href='/editor/coupon.php?action=editmerchant&merchantid=$internal_merid'>merchant setting</a>. <br> \n";
			return $arr_return;
		}
		$mer_id = $r[0];
		$network = $r[1];
		$this->oLinkFeed->LoginIntoAffService($this->info["AffId"],$this->info);
		$types = array('banner', 'text');
		foreach ($types as $type)
		{
			$limit = 100;
			$page = 1;
			do
			{
				$links = array();
				$url = "http://cli.linksynergy.com/cli/publisher/links/link_list.php?mid=$mer_id&nid=$network&type=$type";
				$request["postdata"] = sprintf("currec=%s&pagesize=%s", $limit * ($page - 1) + 1, $limit);
				$r = $this->GetHttpResult_2($url, $request);
				$content = $r["content"];
				preg_match_all('@"creative\[\]"\s+value=\'(.*?)\'@', $content, $g);
				if (empty($g) || empty($g[0]) || !is_array($g[0]))
					break;
				$count = count($g[1]);
				$params = array();
				foreach ($g[1] as $v)
				{
					$params[] = 'creative%5B%5D=' . urlencode($v);
					$params[] = urlencode($v) . '=1';
				}
				$url = 'http://cli.linksynergy.com/cli/publisher/links/output_data.php?download=download&model=linksearch';
	 			$request['postdata'] = sprintf('mouseOverOid=%s&mname=%s_%s&%s', MOUSE_OVER_OID_2, $mer_id, MOUSE_OVER_OID_2, implode('&', $params));
				$r = $this->GetHttpResult_2($url, $request);
				$content = $r['content'];
				$data = @fgetcsv_str($content);
				foreach ((array)$data as $v)
				{
					if (empty($v['LINK CODE']))
						continue;
					$link = array(
							"AffId" => $this->info["AffId"],
							"AffMerchantId" => $merinfo['IdInAff'],
							"LinkName" => $v['LINK NAME'],
							"LinkDesc" => '',
							"LinkStartDate" => parse_time_str($v['START DATE'], null, false),
							"LinkEndDate" => parse_time_str($v['END DATE'], null, true),
							"LinkPromoType" => 'DEAL',
							"LinkHtmlCode" => $v['LINK CODE'],
							"LinkCode" => '',
							"LinkOriginalUrl" => '',
							"LinkImageUrl" => '',
							"LinkAffUrl" => '',
							"DataSource" => 6,
					);
					if (preg_match('@a href="(.*?)"@', $link['LinkHtmlCode'], $g))
						$link['LinkAffUrl'] = $g[1];
					if (preg_match('@border="0" src="(.*?)"@', $link['LinkHtmlCode'], $g))
						$link['LinkImageUrl'] = $g[1];
					if (preg_match('@\&offerid=(\d+\.\d+)\&@', $link['LinkAffUrl'], $g))
						$link['AffLinkId'] = $g[1];
					$code = get_linkcode_by_text($link['LinkName'] . '|' . $link['LinkHtmlCode']);
					if (!empty($code))
					{
						$link['LinkCode'] = $code;
						$link['LinkPromoType'] = 'coupon';
					}
					else
						$link['LinkPromoType'] = $this->oLinkFeed->getPromoTypeByLinkContent($link['LinkName']);
					if (empty($link['AffLinkId']) || empty($link['LinkHtmlCode']) || empty($link['LinkName']))
						continue;
					$this->oLinkFeed->fixEnocding($this->info, $link, "feed");
					$arr_return["AffectedCount"] ++;
					$links[] = $link;
				}
				echo sprintf("program:%s, page:%s, %s links(s) found. \n", $merinfo['IdInAff'], $page, count($links));
				if(count($links) > 0)
					$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);
				$page ++;
			}while ($count >= $limit && $page < 100);
		}
		return $arr_return;
	}

	// LS webservice sometimes return 503. 
	// when api server service unavailable, try another 5 times
	private function GetHttpResult_2($url, $request)
	{
		$r = $this->oLinkFeed->GetHttpResult($url, $request);
		if ($r['code'] == 503 || $r['code'] == 0)
		{
			for ($i = 0; $i < 5; $i ++)
			{
				$r = $this->oLinkFeed->GetHttpResult($url, $request);
				if ($r['code'] != 503 && $r['code'] != 0)
						break;
			}
		}
		return $r;
	}

	function getCouponFeed()
	{
		$arr_return = array("AffectedCount" => 0, "UpdatedCount" => 0, "Detail" => array(), );
		$request = array("AffId" => $this->info["AffId"], "method" => "get", "postdata" => "", );

		//bento service
		$networks = array(1, 3, 5, 41); // us uk ca au
		$categories = array(5, //Automotive
				32,	// Babies & Kids
				6,	// Beauty & Fragrance
				7,	// Books & Magazines
				8,	// Cameras & Photography
				9,	// Car Rental
				10,	// Computers
				11, // Dating
				12, // Department Store
				13, // Electronic Equipment
				2,	// Fashion - Babies & Children
				3,	// Fashion - Men's
				4,	// Fashion - Women's
				1,	// Fashion
				14,	// Flowers
				15,	// Garden & Outdoors
				16, // Gifts
				17, // Gourmet Food & Drink
				18, // Green Products
				19, // Health & Wellness
				20, // Housewares
				21, // Jewelry & Accessories
				22, // Music & Movies
				31, // Office & Small Business
				23, // Office Supplies
				24, // Pet Care
				25, // Services
				26, // Shoes
				27, // Software & Downloads
				28, // Sports & Fitness
				28, // Toys and Games
				30, // Travel & Vacations
		);
		$promotiontypes = array(1,	// General Promotion
				2,	// Buy One, Get One
				3,	// Clearance
				4,	// Combination Savings
				14,	// Deal of the Day / Week
				6,	// Free Gift with Purchase
				9,	// Free Gift with Purchase
				7,	// Free Shipping / Free Delivery
				13, // Free Shipping / Free Delivery
				8,	// Friends and Family
				5,	// Money Off
				12,	// Money Off
				11,	// Percentage Off
				10,	// Other
				30,	// Black Friday
				31,	// Cyber Monday
				);
		$links = array();
		foreach ($networks as $network)
		{
			foreach ($categories as $category)
			{
				foreach ($promotiontypes as $promotiontype)
				{
					$count = 0;
					$url = "http://bento.linksynergy.com/bento_services/coupons/coupon_proxyXML.php?yws_path=";
					$url .= urlencode(sprintf("coupon?token=fb80d7cf065af3909fdb367a99a0893b2ed058724315c0a9b4b282ca82ad18bb&network=%s&category=%s&promotiontype=%s", $network, $category, $promotiontype));
					$r = $this->GetHttpResult_2($url, $request);
					$content = $r['content'];
					preg_match_all('@<link type=".*?">(.*?)</link>@ms', $content, $rows);
					foreach ((array)$rows[1] as $row)
					{
						$count ++;
						$link = array(
								"AffId" => $this->info["AffId"],
								"AffMerchantId" => '',
								"LinkName" => '',
								"LinkDesc" => '',
								"LinkStartDate" => '0000-00-00',
								"LinkEndDate" => '0000-00-00',
								"LinkPromoType" => 'DEAL',
								"LinkHtmlCode" => '',
								"LinkCode" => '',
								"LinkOriginalUrl" => '',
								"LinkImageUrl" => '',
								"LinkAffUrl" => '',
								"DataSource" => 2,
						);
						if (preg_match('@<clickurl>(.*?offerid=(\d+\.\d+).*?)</clickurl>@', $row, $g))
						{
							$link['LinkAffUrl'] = html_entity_decode($g[1]);
							$link['AffLinkId'] = $g[2];
						}
						if (preg_match('@<advertiserid>(\d+)</advertiserid>@', $row, $g))
							$link['AffMerchantId'] = sprintf('%s_%s', $g[1], $network);
						if (preg_match('@<offerdescription>(.*?)</offerdescription>@s', $row, $g))
							$link['LinkName'] = html_entity_decode($g[1]);
						if (preg_match('@<offerstartdate>(.*?)</offerstartdate>@s', $row, $g))
							$link['LinkStartDate'] = parse_time_str($g[1], null, false);
						if (preg_match('@<offerenddate>(.*?)</offerenddate>@s', $row, $g))
							$link['LinkEndDate'] = parse_time_str($g[1], null, true);
						if (preg_match('@<couponcode>(.+)</couponcode>@s', $row, $g))
							$link['LinkCode'] = trim($g[1]);
						if (preg_match('@<couponrestriction>(.+)</couponrestriction>@s', $row, $g))
							$link['LinkDesc'] = html_entity_decode($g[1]);
						switch ($promotiontype)
						{
							case 7:
							case 13:
								$link['LinkPromoType'] = 'free shipping';
								break;
							default:
								if (!empty($link['LinkCode']))
								{
									$link['LinkPromoType'] = 'COUPON';
									break;
								}
								$code = get_linkcode_by_text($link['LinkName'] . '|' . $link['LinkDesc']);
								if (!empty($code))
								{
									$link['LinkPromoType'] = 'COUPON';
									$link['LinkCode'] = $code;
									break;
								}
								$link['LinkPromoType'] = $this->oLinkFeed->getPromoTypeByLinkContent($link['LinkName']);
								break;
						}
						$link['LinkHtmlCode'] = create_link_htmlcode($link);
						if (empty($link['AffLinkId']) || empty($link['LinkAffUrl']) || empty($link['LinkName']))
							continue;
						$this->oLinkFeed->fixEnocding($this->info, $link, "feed");
						$arr_return["AffectedCount"] ++;
						$links[] = $link;
						if(count($links) % 100 == 0)
						{
							$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);
							$links = array();
						}
					}
					echo sprintf("network: %s, category: %s, promotiontype:%s. %s link(s) found.\n", $network, $category, $promotiontype, $count);
				}
			}
		}
		if(count($links) > 0)
		{
			$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);
			$links = array();
		}

		//get links from feed.
		$limit = 100;
		$page = 1;
		do 
		{
			$links = array();
			$url = sprintf("http://couponfeed.linksynergy.com/coupon?token=%s&resultsperpage=%s&pagenumber=%s", API_TOKEN_2, $limit, $page);
			$r = $this->GetHttpResult_2($url, $request);
			$content = $r['content'];
			$dom = new DomDocument();
			@$dom->loadXML($content);
			$r = @XML2Array::createArray($dom);
			if (empty($r) || empty($r['couponfeed']) || empty($r['couponfeed']['TotalPages']) || empty($r['couponfeed']['link']) || !is_array($r['couponfeed']['link']))
				break;
			$total = $r['couponfeed']['TotalPages'];
			if (!empty($r['couponfeed']['link']['advertiserid'])) // only 1 result.
				$data = array($r['couponfeed']['link']);
			else
				$data = $r['couponfeed']['link'];
			foreach ($data as $v)
			{
				$link = array(
						"AffId" => $this->info["AffId"],
						"AffMerchantId" => $v['advertiserid'] . '_' . $v['network']['@attributes']['id'],
						"LinkName" => html_entity_decode($v['offerdescription']),
						"LinkDesc" => '',
						"LinkStartDate" => parse_time_str($v['offerstartdate'], null, false),
						"LinkEndDate" => parse_time_str($v['offerenddate'], null, true),
						"LinkPromoType" => 'COUPON',
						"LinkHtmlCode" => '',
						"LinkCode" => '',
						"LinkOriginalUrl" => '',
						"LinkImageUrl" => '',
						"LinkAffUrl" => html_entity_decode($v['clickurl']),
						"DataSource" => 2,
				);
				if (!empty($v['couponrestriction']))
					$link['LinkDesc'] .= $v['couponrestriction'];
				if (!empty($v['promotiontypes']) && !empty($v['promotiontypes']['promotiontype']) && is_array($v['promotiontypes']['promotiontype']))
				{
					if (!empty($v['promotiontypes']['promotiontype']['@attributes']))
						$types = array($v['promotiontypes']['promotiontype']);
					else
						$types = $v['promotiontypes']['promotiontype'];
					foreach ($types as $type)
					{
						if ($type['@attributes']['id'] == 7)
							$link['LinkPromoType'] = 'free shipping';
					}
				}
				if (!empty($v['couponcode']))
					$link['LinkCode'] = $v['couponcode'];
				if (empty($link['LinkCode']))
				{
					$code = get_linkcode_by_text($link['LinkName'] . '|' . $link['LinkHtmlCode']);
					if (!empty($code))
						$link['LinkCode'] = $code;
				}
				if (!empty($v['imageurl']))
					$link['LinkImageUrl'] = $v['imageurl'];
				if (preg_match('@\&offerid=(\d+\.\d+)\&@', $link['LinkAffUrl'], $g))
					$link['AffLinkId'] = $g[1];
				$link['LinkHtmlCode'] = create_link_htmlcode_image($link);
				if (empty($link['AffLinkId']) || empty($link['LinkHtmlCode']) || empty($link['LinkName']))
					continue;
				$this->oLinkFeed->fixEnocding($this->info, $link, "feed");
				$arr_return["AffectedCount"] ++;
				$links[] = $link;
			}
			echo sprintf("page:%s, %s links(s) found. \n", $page, count($links));
			if(count($links) > 0)
				$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);
			$page ++;
		} while ($page <= $total);

		// get holiday links
		$objProgram = new ProgramDb();
		$programs = $objProgram->getAllProgramByAffId($this->info['AffId']);
		$IdInAffs = array();
		foreach ($programs as $program)
		{
			$IdInAff = $program['IdInAff'];
			$t = explode('_', $IdInAff);
			if (count($t) != 2)
				continue;
			$IdInAffs[$t[0]] = $IdInAff;
		}
		$special_urls = array(
				'http://helpcenter.linkshare.com/publisher/questions.php?questionid=1363',
				'http://helpcenter.linkshare.com/publisher/questions.php?questionid=1364',
				'http://helpcenter.linkshare.com/publisher/questions.php?questionid=1362',
				);
		foreach ($special_urls as $special_url)
		{
			$links = array();
			$count = 0;
			$this->oLinkFeed->LoginIntoAffService($this->info["AffId"],$this->info);
			$url = $special_url;
			$r = $this->GetHttpResult_2($url, $request);
			$content = $r['content'];
			preg_match_all('@href="http://cli\.linksynergy\.com/cli/publisher/links/link_detail.php\?creative\[\]=(.*?)"@ms', $content, $data);
			$combination = array();
			$params = array();
			foreach ((array)$data[1] as $v)
			{
				if (empty($v))
					continue;
				$params[] = 'creative[]=' . trim($v);
				if (count($params) % 50 == 0)
				{
					$combination[] = $params;
					$params = array();
				}
			}
			if (count($params) > 0)
				$combination[] = $params;
			foreach ($combination as $p)
			{
				$url = 'http://cli.linksynergy.com/cli/publisher/links/link_detail.php?' . implode('&', $p);
				$r = $this->GetHttpResult_2($url, $request);
				$content = $r['content'];
				preg_match_all('@<textarea(.*?)\&nbsp;Open link in a new window@ms', $content, $chapters);
				if (empty($chapters[0]) || !is_array($chapters[0]))
					continue;
				foreach ((array)$chapters[0] as $v)
				{
					$link = array(
							"AffId" => $this->info["AffId"],
							"AffMerchantId" => '',
							"LinkName" => '',
							"LinkDesc" => '',
							"LinkStartDate" => '0000-00-00',
							"LinkEndDate" => '0000-00-00',
							"LinkPromoType" => 'COUPON',
							"LinkHtmlCode" => '',
							"LinkCode" => '',
							"LinkOriginalUrl" => '',
							"LinkImageUrl" => '',
							"LinkAffUrl" => '',
							"DataSource" => 4,
					);
					if (preg_match('@Example of link</td>\s+<td style=".*?" >(.*?)</td>@ms', $v, $g))
						$link['LinkHtmlCode'] = $g[1];
					if (preg_match('@href="(.*?)"@ms', $link['LinkHtmlCode'], $g))
						$link['LinkAffUrl'] = $g[1];
					if (preg_match('@Link Name</td>\s+<td style=".*?" >(.*?)</td>@ms', $v, $g))
						$link['LinkName'] = trim(html_entity_decode(strip_tags($g[1])));
					$link['LinkDesc'] = trim(html_entity_decode(strip_tags($link['LinkHtmlCode'])));
					if (preg_match('@offerid=(.*?\.\d+)@', $link['LinkAffUrl'], $g))
						$link['AffLinkId'] = $g[1];
					if (preg_match('@<input id="newwindow~.*?~.*?~(\d+)"@', $v, $g))
						$link['AffMerchantId'] = @$IdInAffs[$g[1]];
					if (preg_match('@Start Date</td>\s+<td style=".*?" >(.*?)</td>@ms', $v, $g))
						$link['LinkStartDate'] = parse_time_str($g[1], 'm-d-Y', false);
					if (preg_match('@End Date</td>\s+<td style=".*?" >(.*?)</td>@ms', $v, $g))
						$link['LinkEndDate'] = parse_time_str($g[1], 'm-d-Y', true);
					$link['LinkCode'] = get_linkcode_by_text($link['LinkName'] . '|' . $link['LinkDesc']);
					if (empty($link['AffMerchantId']) || empty($link['AffLinkId']) || empty($link['LinkHtmlCode']) || empty($link['LinkName']))
						continue;
					$this->oLinkFeed->fixEnocding($this->info, $link, "feed");
					$arr_return["AffectedCount"] ++;
					$links[] = $link;
				}
				$count += count($links);
				if(count($links) > 0)
					$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);
			}
			echo sprintf("special url:%s parsed, %s links(s) found. \n", $special_url, count($links));
		}
		return $arr_return;
	}

	function getMessage()
	{
		$messages = array();
		$request = array("AffId" => $this->info["AffId"], "method" => "get", "postdata" => "", );
		$this->oLinkFeed->LoginIntoAffService($this->info["AffId"], $this->info);
		$url = 'http://cli.linksynergy.com/cli/publisher/messages/generalMessages.php?folderID=1';
		$r = $this->oLinkFeed->GetHttpResult($url, $request);
		$content = $r['content'];
		if (preg_match('@<tbody>(.*?)</tbody>@ms', $content, $g))
			$content = $g[1];
		else 
			return 'parse html error.';
		preg_match_all('@<tr.*?>(.*?)</tr>@ms', $content, $chapters);
		if (empty($chapters) || !is_array($chapters) || empty($chapters[1]) || !is_array($chapters[1]))
			return 'no message found.';
		foreach ($chapters[1] as $chapter)
		{
			$data = array(
					'affid' => $this->info["AffId"],
					'messageid' => '',
					'sender' => '',
					'title' => '',
					'content' => '',
					'created' => '0000-00-00',
			);
			if (preg_match('@td_180_left">(.*?)</td>@', $chapter, $g))
				$data['sender'] = trim(html_entity_decode(strip_tags($g[1])));
			if (preg_match('@select_emailid\[\]" value="(\d+)"@', $chapter, $g))
				$data['messageid'] = $g[1];
			if (preg_match('@td_auto_left"><a href="(.*?)">(.*?)</a>@', $chapter, $g))
			{
				$data['content_url'] = $g[1];
				$data['title'] = trim(html_entity_decode(strip_tags($g[2])));;
			}
			if (preg_match('@"td_80">(.*?)<@', $chapter, $g))
				$data['created'] = parse_time_str($g[1], 'm-d-Y', false);
			if (empty($data['messageid']) || empty($data['title']))
				continue;
			$messages[] = $data;
		}
		return $messages;
	}

	function getMessageDetail($data)
	{
		$request = array("AffId" => $this->info["AffId"], "method" => "get", "postdata" => "", );
		$this->oLinkFeed->LoginIntoAffService($this->info["AffId"], $this->info);
		$url = $data['content_url'];
		$r = $this->oLinkFeed->GetHttpResult($url, $request);
		$content = $r['content'];
		if (preg_match('@<b>Subject:.*?<div class="divider"></div>(.*?)</div>\s+</div>\s+<div class="commonBoxFooter">@ms', $content, $g))
			$data['content'] = str_force_utf8(trim(html_entity_decode($g[1])));
		if (preg_match('@iframe src="(.*?)"@ms', $data['content'], $g))
		{
			$url = $g[1];
			$r = $this->oLinkFeed->GetHttpResult($url, $request);
			if (!empty($r['content']))
				$data['content'] = $r['content'];
		}
		return $data;
	}

	function GetProgramFromAff()
	{	
		$check_date = date("Y-m-d H:i:s");
		echo "Craw Program start @ {$check_date}\r\n";
		$this->GetProgramFromByPage();
		$this->checkProgramOffline($this->info["AffId"], $check_date);
		echo "Craw Program end @ ".date("Y-m-d H:i:s")."\r\n";
	}

	function GetProgramFromByPage()
	{
		echo "\tGet Program by page start\r\n";
		$objProgram = new ProgramDb();
		$arr_prgm = array();
		$program_num = 0;
		$working_dir = $this->oLinkFeed->getWorkingDirByAffID($this->info["AffId"]);
		$request = array("AffId" => $this->info["AffId"], "method" => "get", "postdata" => "",);

		//step 1, login
		$this->oLinkFeed->LoginIntoAffService($this->info["AffId"],$this->info);

		//step 2, get program from csv.
		$exist_prgm = array();
		$str_header = '"Advertiser Name","Advertiser URL","MID","Advertiser Description","Link to T&C","Link to Program History","Link to Home Page","Status","Contact Name","Contact Title","State","City","Address","Zip","Country","Phone","Email Address","Commission Terms","Offer","Offer Type","Year Joined","Expiration Date","Return Days","Transaction Update Window","TrueLock","Premium Status","Baseline Commission Terms","Baseline Offer","Baseline Offer Type","Baseline Expiration Date","Baseline Return Days","Baseline Transaction Update Window","Baseline TrueLock"';
		$cache_file = $this->oLinkFeed->fileCacheGetFilePath($this->info["AffId"],"caReport.csv","cache_merchant");
		if(!$this->oLinkFeed->fileCacheIsCached($cache_file))
		{
			$strUrl = "http://cli.linksynergy.com/cli/publisher/programs/consolidatedAdvertiserReport.php";
			$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
			$result = $r["content"];
			$file_id = intval($this->oLinkFeed->ParseStringBy2Tag($result, "http://cli.linksynergy.com/cli/publisher/programs/carDownload.php?id=", "'"));

			$strUrl = "http://cli.linksynergy.com/cli/publisher/programs/carDownload.php?id=$file_id";
			$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
			$result = $r["content"];
			print "Get files <br>\n";
			if(stripos($result,$str_header) === false) mydie("die: wrong csv file: $cache_file");
			$this->oLinkFeed->fileCachePut($cache_file,$result);
		}

		$handle = fopen($cache_file, 'r');
		while($line = fgetcsv ($handle, 5000))
		{
			foreach($line as $k => $v) $line[$k] = trim($v);

			if ($line[0] == '' || $line[0] == 'Advertiser Name') continue;
			if(!isset($line[2])) continue;
			if(!isset($line[5])) continue;

			$strMerName = $line[0];
			$Homepage = $line[1];
			$strTmpMerID = $line[2];
			$desc = $line[3];
			//$Term_url = $line[4];
			$Offer_url = $line[5];
			$AffDefaultUrl = $line[6];
			$StatusInAffRemark = $line[7];
			$Contact_Name = $line[8];
			$Contact_Title = $line[9];
			$Contact_State = $line[10];
			$Contact_City = $line[11];
			$Contact_Address = $line[12];
			$Contact_Zip = $line[13];
			$Contact_Country = $line[14];
			$Contact_Phone = $line[15];
			$Contact_Email = $line[16];
			$CommissionExt = $line[17];
			$Offer = $line[18];
			$Offer_Type = $line[19];
			$JoinDate = $line[20];
			//$Expiration = $line[21];
			$ReturnDays = $line[22];
			$Contact_Zip = $line[23];
			$Contact_Country = $line[24];
			$Premium_Status = $line[25];

			preg_match("/nid=(\d+)/i", $Offer_url, $matches);
			$nid = $matches[1];
			preg_match("/offerid=(\d+)/i", $AffDefaultUrl, $matches);
			$strTmpOfferID = $matches[1];

			$prgm_url = "http://cli.linksynergy.com/cli/publisher/programs/advertiser_detail.php?oid=$strTmpOfferID&mid=$strTmpMerID&offerNid=$nid&controls=1:1:1:1:1:0";
			$strMerID = $strTmpMerID."_".$nid;

			if($StatusInAffRemark == "Active"){
				$StatusInAff = "Active";
				$Partnership = "Active";
			}elseif($StatusInAffRemark == "Declined"){
				$StatusInAff = "Active";
				$Partnership = "Declined";
			}elseif($StatusInAffRemark == "Hold"){
				$StatusInAff = "Offline";
				$Partnership = "Active";
			}else{
				$StatusInAff = "Offline";
				$Partnership = "NoPartnership";
			}

			$Contacts = "$Contact_Name($Contact_Title), Email: $Contact_Email, Phone: $Contact_Phone, Zip: $Contact_Zip, Address: $Contact_State $Contact_City $Contact_Address  $Contact_Country.";
			$JoinDate = $JoinDate. "-01-01 00:00:00";
			$RankInAff = 3;
			if($Premium_Status == "Premium"){
				$RankInAff = 5;
			}

			$detail_url = "http://cli.linksynergy.com/cli/publisher/programs/advertiserInformationFrame.php?oid=$strTmpOfferID&mid=$strTmpMerID&offerNid=$nid&controls=1:1:3";
			$prgm_arr = $this->oLinkFeed->GetHttpResult($detail_url, $request);
			$prgm_detail = $prgm_arr["content"];
			$strMerFlag = strtoupper($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<!-- Flags -->', 'images/common/flag_'), "."));
			$TargetCountryExt = $strMerFlag;
			$strMerName = trim($strMerName) . ' ('.$strMerFlag.') ';

			$more_info = $this->getSupportDUT($strTmpMerID, $strTmpOfferID, $request, true);
			$SupportDeepurl = $more_info['SupportDeepurl'];
			$CategoryExt = $more_info['CategoryExt'];
			$TermAndCondition = $more_info['TermAndCondition'];

			//program
			$arr_prgm[$strMerID] = array(
				"Name" => addslashes(trim($strMerName)),
				"AffId" => $this->info["AffId"],
				"Homepage" => addslashes($Homepage),
				"Contacts" => addslashes($Contacts),
				"TargetCountryExt" => $TargetCountryExt,
				"RankInAff" => $RankInAff,
				"IdInAff" => $strMerID,
				"JoinDate" => $JoinDate,
				"TermAndCondition" => addslashes($TermAndCondition),
				"StatusInAff" => $StatusInAff,						//'Active','TempOffline','Offline'
				"StatusInAffRemark" => addslashes($StatusInAffRemark),
				"Partnership" => $Partnership,						//'NoPartnership','Active','Pending','Declined','Expired','Removed'
				"Description" => addslashes($desc),
				"CommissionExt" => addslashes($CommissionExt),
				"CookieTime" => $ReturnDays,
				"LastUpdateTime" => date("Y-m-d H:i:s"),
				"SecondIdInAff" => $strTmpOfferID,
				"DetailPage" => $prgm_url,
				"AffDefaultUrl" => $AffDefaultUrl
			);
			$arr_prgm[$strMerID] = array_merge($this->getMobileFriendly($strTmpMerID), $arr_prgm[$strMerID]);

			$exist_prgm[$strMerID] = 1;
			$program_num++;
			if(count($arr_prgm) >= 100){
				$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
				$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
				$arr_prgm = array();
			}
		}
		if(count($arr_prgm)){
			$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
			$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
			unset($arr_prgm);
		}
		fclose($handle);

		//step 3, Get all new merchants
		$request["method"] = "post";
		$nNumPerPage = 100;
		$bHasNextPage = true;
		$nPageNo = 1;
		$arr_prgm = array();
		$Cnt = 0;
		$UpdateCnt = 0;
		while($bHasNextPage){
			$strUrl = "http://cli.linksynergy.com/cli/publisher/programs/advertisers.php";
			$request["postdata"] = "analyticchannel=Programs&analyticpage=New+Advertisers&singleApply=&update=&remove_mid=&remove_oid=&remove_nid=&filter_open=&cat=&advertiserSerachBox_old=&advertiserSerachBox=&category=-1&filter_status=all&filter_networks=all&filter_promotions=-1&filter_type=all&filter_banner_size=+--+All+Sizes+--&orderby=&direction=&currec=".($nNumPerPage * ($nPageNo - 1) + 1)."&pagesize=".$nNumPerPage;			
			$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
			$result = $r["content"];

			print "Get Merchant List new : Page - $nPageNo <br>\n";
			//parse HTML
			$strLineStart = '<td class="td_left_edge">';
			$nLineStart = 0;
			while ($nLineStart >= 0){
				if($this->debug) print "Process $Cnt  ";

				$nLineStart = stripos($result, $strLineStart, $nLineStart);
				if ($nLineStart === false) break;

				// ID 	Name 	EPC 	Status
				$strMerID = $this->oLinkFeed->ParseStringBy2Tag($result, array('select_mid[]', 'value="'), '"', $nLineStart);
				//$strMerID = str_replace('~', '_', $strMerID);
				list($strTmpMerID, $strTmpOfferID, $strTmpNetworkID) = explode('~', $strMerID);
				$strMerID = $strTmpMerID.'_'.$strTmpNetworkID;
				if(isset($exist_prgm[$strMerID])) continue;
				$strMerName = $this->oLinkFeed->ParseStringBy2Tag($result, 'helpMessage(this);">', '</a>', $nLineStart);
				//us or uk
				$strMerFlag = strtoupper($this->oLinkFeed->ParseStringBy2Tag($result, 'images/common/flag_', ".", $nLineStart)); 
				$TargetCountryExt = $strMerFlag;
				//$strMerName = html_entity_decode($strMerName);
				$strMerName = trim($strMerName) . ' ('.$strMerFlag.') ';
				//desc
				$desc = strip_tags($this->oLinkFeed->ParseStringBy2Tag($result, "</span>", '<img src', $nLineStart));
				$aff_mer_url = $this->oLinkFeed->ParseStringBy2Tag($result, array('images/arrows/caret.gif" alt="Arrow">', '<a href="'), '">View Links</a>', $nLineStart);
				//join date
				$JoinDate = $this->oLinkFeed->ParseStringBy2Tag($result, array('<td class="td_date_joined">'), '</td>', $nLineStart);
				$JoinDate = $JoinDate. "-01-01 00:00:00";
				//CommissionExt
				$CommissionExt = $this->oLinkFeed->ParseStringBy2Tag($result, array('<td class="td_commission">'), '</td>', $nLineStart);
				//ReturnDays
				$ReturnDays = $this->oLinkFeed->ParseStringBy2Tag($result, array('<td class="td_return">'), '</td>', $nLineStart);
				//class="td_status" or class="td_status_temp"
				$strStatusShow = trim($this->oLinkFeed->ParseStringBy2Tag($result, '<td class="td_status', "<br>", $nLineStart));
				$strStatus = $this->getStatusByStr($strStatusShow);
				if($strStatus === false)
				{
					print_r($result);
					mydie("Unknown Status : $strStatusShow <br>\n");
				}
				$StatusInAffRemark = strip_tags(str_ireplace(array('">','_temp">'),"",$strStatusShow));
				//$StatusInAff = $strStatus;//'Active','TempOffline','Expired'
				if(stripos($strStatusShow,'Approved') !== false){
					$Partnership = "Active";
					$StatusInAff = "Active";
				}
				elseif(stripos($strStatusShow,'Pending') !== false){
					$Partnership = "Pending";
					$StatusInAff = "Active";
				}
				elseif(stripos($strStatusShow,'No Relationship') !== false){
					$Partnership = "NoPartnership";
					$StatusInAff = "Active";
				}
				elseif(stripos($strStatusShow, "Declined") !== false){
					$Partnership = "Declined";
					$StatusInAff = "Active";
				}
				elseif(stripos($strStatusShow, "Removed") !== false){
					$Partnership = "Removed";
					$StatusInAff = "Active";
				}
				elseif(stripos($strStatusShow, "Discontinued") !== false){
					$Partnership = "NoPartnership";
					$StatusInAff = "TempOffline";
				}
				elseif(stripos($strStatusShow, "Extended") !== false){
					$Partnership = "Active";
					$StatusInAff = "Active";
				}
				else{
					$Partnership = "NoPartnership";
					$StatusInAff = "Active";
				}

				//program_detail
				$prgm_url = "http://cli.linksynergy.com/cli/publisher/programs/advertiser_detail.php?oid=$strTmpOfferID&mid=$strTmpMerID&offerNid=$strTmpNetworkID&controls=1:1:1:1:1:0";
				$more_info = $this->getSupportDUT($strTmpMerID, $strTmpOfferID, $request, true);
				$SupportDeepurl = $more_info['SupportDeepurl'];
				$CategoryExt = $more_info['CategoryExt'];
				$TermAndCondition = $more_info['TermAndCondition'];
				//$Homepage = $more_info['Homepage'];
				//program
				$arr_prgm[$strMerID] = array(
					"Name" => addslashes(trim($strMerName)),
					"AffId" => $this->info["AffId"],
					"Homepage" => addslashes($Homepage),
					"CategoryExt" => addslashes($CategoryExt),
					"Contacts" => addslashes($Contacts),
					"TargetCountryExt" => $TargetCountryExt,
					"RankInAff" => 3,
					"IdInAff" => $strMerID,
					"JoinDate" => $JoinDate,
					//"CreateDate" => "0000-00-00 00:00:00",
					//"DropDate" => "0000-00-00 00:00:00",
					"TermAndCondition" => addslashes($TermAndCondition),
					"StatusInAff" => $StatusInAff,						//'Active','TempOffline','Offline'
					"StatusInAffRemark" => addslashes($StatusInAffRemark),
					"Partnership" => $Partnership,						//'NoPartnership','Active','Pending','Declined','Expired','Removed'					
					"Description" => $desc,
					"CommissionExt" => addslashes($CommissionExt),
					"CookieTime" => $ReturnDays,
					"LastUpdateTime" => date("Y-m-d H:i:s"),
					"SecondIdInAff" => $strTmpOfferID,
					"DetailPage" => $prgm_url,
					"SupportDeepurl" => $SupportDeepurl
				);
				$arr_prgm[$strMerID] = array_merge($this->getMobileFriendly($strTmpMerID), $arr_prgm[$strMerID]);
				$program_num++;
				if(count($arr_prgm) >= 100){
					$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
					$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
					$arr_prgm = array();
				}
			}
			if(count($arr_prgm)){
				$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
				$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
				unset($arr_prgm);
			}
			//Check if have next page;
			if (false === $this->oLinkFeed->ParseStringBy2Tag($result, "document.myform.submit();return false;'>Next", '</a></div></div>', $nLineStart))
			{
				$bHasNextPage = false;
				if($this->debug) print " NO NEXT PAGE  <br>\n";
			}
			else{
				if($this->debug) print " Have NEXT PAGE  <br>\n";
			}
			if ($bHasNextPage){
				$nPageNo++;
			}
		}//per page

		//step 4, Get all my merchants
		$nNumPerPage = 100;
		$bHasNextPage = true;
		$nPageNo = 1;
		$arr_prgm = array();

		$Cnt = 0;
		$UpdateCnt = 0;
		while($bHasNextPage){
			$strUrl = "http://cli.linksynergy.com/cli/publisher/programs/advertisers.php?my_programs=1";

			$request["postdata"] = "analyticchannel=Programs&analyticpage=My+Advertisers&singleApply=&update=&remove_mid=&remove_oid=&remove_nid=&filter_open=&cat=&advertiserSerachBox_old=&advertiserSerachBox=&category=-1&filter_networks=all&filter_promotions=-1&filter_type=all&filter_banner_size=+--+All+Sizes+--&my_programs=1&filter_status_program=all&orderby=&direction=&currec=".($nNumPerPage * ($nPageNo - 1) + 1)."&pagesize=".$nNumPerPage;
			$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
			$result = $r["content"];
			print "Get All My Merchant List - Apporved : Page - $nPageNo <br>\n";

			//parse HTML
			$strLineStart = '<td class="td_left_edge">';
			$nLineStart = 0;
			while ($nLineStart >= 0){
				if($this->debug) print "Process $Cnt  ";
				$nLineStart = stripos($result, $strLineStart, $nLineStart);
				if ($nLineStart === false) break;
				// ID 	Name 	EPC 	Status
				$strMerID = $this->oLinkFeed->ParseStringBy2Tag($result, array('select_mid[]', 'value="'), '"', $nLineStart);

				//$strMerID = str_replace('~', '_', $strMerID);
				list($strTmpMerID, $strTmpOfferID, $strTmpNetworkID) = explode('~', $strMerID);
				$strMerID = $strTmpMerID.'_'.$strTmpNetworkID;
				if(isset($exist_prgm[$strMerID])) continue;
				$strMerName = $this->oLinkFeed->ParseStringBy2Tag($result, 'helpMessage(this);">', '</a>', $nLineStart);
				//us or uk
				$strMerFlag = strtoupper($this->oLinkFeed->ParseStringBy2Tag($result, 'images/common/flag_', ".", $nLineStart));
				$TargetCountryExt = $strMerFlag;

				//$strMerName = html_entity_decode($strMerName);
				$strMerName = trim($strMerName) . ' ('.$strMerFlag.') ';
				//desc
				$desc = strip_tags($this->oLinkFeed->ParseStringBy2Tag($result, "</span>", '<img src', $nLineStart));
				$aff_mer_url = $this->oLinkFeed->ParseStringBy2Tag($result, array('images/arrows/caret.gif" alt="Arrow">', '<a href="'), '">View Links</a>', $nLineStart);
				//join date
				$JoinDate = $this->oLinkFeed->ParseStringBy2Tag($result, array('<td class="td_date_joined">'), '</td>', $nLineStart);
				$JoinDate = $JoinDate. "-01-01 00:00:00";
				//CommissionExt
				$CommissionExt = $this->oLinkFeed->ParseStringBy2Tag($result, array('<td class="td_commission">'), '</td>', $nLineStart);
				//ReturnDays
				$ReturnDays = $this->oLinkFeed->ParseStringBy2Tag($result, array('<td class="td_return">'), '</td>', $nLineStart);

				//class="td_status" or class="td_status_temp"
				$strStatusShow = trim($this->oLinkFeed->ParseStringBy2Tag($result, '<td class="td_status', "<br>", $nLineStart));
				$strStatus = $this->getStatusByStr($strStatusShow);
				if($strStatus === false)
				{
					print_r($result);
					mydie("Unknown Status : $strStatusShow <br>\n");
				}

				$StatusInAffRemark = strip_tags(str_ireplace(array('">','_temp">'),"",$strStatusShow));
				//$StatusInAff = $strStatus;//'Active','TempOffline','Expired'
				if(stripos($strStatusShow,'Approved') !== false){
					$Partnership = "Active";
					$StatusInAff = "Active";
				}
				elseif(stripos($strStatusShow,'Pending') !== false){
					$Partnership = "Pending";
					$StatusInAff = "Active";
				}
				elseif(stripos($strStatusShow,'No Relationship') !== false){
					$Partnership = "NoPartnership";
					$StatusInAff = "Active";
				}
				elseif(stripos($strStatusShow, "Declined") !== false){
					$Partnership = "Declined";
					$StatusInAff = "Active";
				}
				elseif(stripos($strStatusShow, "Removed") !== false){
					$Partnership = "Removed";
					$StatusInAff = "Active";
				}
				elseif(stripos($strStatusShow, "Discontinued") !== false){
					$Partnership = "NoPartnership";
					$StatusInAff = "TempOffline";
				}
				elseif(stripos($strStatusShow, "Extended") !== false){
					$Partnership = "Active";
					$StatusInAff = "Active";
				}
				else{
					$Partnership = "NoPartnership";
					$StatusInAff = "Active";
				}

				//program_detail
				$prgm_url = "http://cli.linksynergy.com/cli/publisher/programs/advertiser_detail.php?oid=$strTmpOfferID&mid=$strTmpMerID&offerNid=$strTmpNetworkID&controls=1:1:1:1:1:0";
				$more_info = $this->getSupportDUT($strTmpMerID, $strTmpOfferID, $request, true);
				$SupportDeepurl = $more_info['SupportDeepurl'];
				$CategoryExt = $more_info['CategoryExt'];
				$TermAndCondition = $more_info['TermAndCondition'];

				//program
				$arr_prgm[$strMerID] = array(
					"Name" => addslashes(trim($strMerName)),
					"AffId" => $this->info["AffId"],
					"Homepage" => addslashes($Homepage),
					"CategoryExt" => addslashes($CategoryExt),
					"Contacts" => addslashes($Contacts),
					"TargetCountryExt" => $TargetCountryExt,
					"RankInAff" => 3,
					"IdInAff" => $strMerID,
					"JoinDate" => $JoinDate,
					//"CreateDate" => "0000-00-00 00:00:00",
					//"DropDate" => "0000-00-00 00:00:00",
					"TermAndCondition" => addslashes($TermAndCondition),
					"StatusInAff" => $StatusInAff,						//'Active','TempOffline','Offline'
					"StatusInAffRemark" => addslashes($StatusInAffRemark),
					"Partnership" => $Partnership,						//'NoPartnership','Active','Pending','Declined','Expired','Removed'					
					"Description" => $desc,
					"CommissionExt" => addslashes($CommissionExt),
					"CookieTime" => $ReturnDays,
					"LastUpdateTime" => date("Y-m-d H:i:s"),
					"SecondIdInAff" => $strTmpOfferID,
					"DetailPage" => $prgm_url,
					"SupportDeepurl" => $SupportDeepurl
				);
				$arr_prgm[$strMerID] = array_merge($this->getMobileFriendly($strTmpMerID), $arr_prgm[$strMerID]);
				$program_num++;
				if(count($arr_prgm) >= 100){
					$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
					$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
					$arr_prgm = array();
				}
			}
			if(count($arr_prgm)){
				$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
				$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
				unset($arr_prgm);
			}

			//Check if have next page;
			if (false === $this->oLinkFeed->ParseStringBy2Tag($result, "document.myform.submit();return false;'>Next", '</a></div></div>', $nLineStart)){
				$bHasNextPage = false;
				if($this->debug) print " NO NEXT PAGE  <br>\n";
			}
			else{
				if($this->debug) print " Have NEXT PAGE  <br>\n";
			}
			if ($bHasNextPage){
				$nPageNo++;
			}
		}//per page

		//step 5, Get all Premium merchants
		$nNumPerPage = 100;
		$bHasNextPage = true;
		$nPageNo = 1;
		$arr_prgm = array();

		$Cnt = 0;
		$UpdateCnt = 0;
		while($bHasNextPage){
			$strUrl = "http://cli.linksynergy.com/cli/publisher/programs/advertisers.php?force_premium=1";

			$request["postdata"] = "analyticchannel=Programs&analyticpage=Premium+Advertisers&singleApply=&update=&remove_mid=&remove_oid=&remove_nid=&filter_open=&cat=&advertiserSerachBox_old=&advertiserSerachBox=&category=-1&filter_status=all&filter_networks=all&filter_promotions=-1&filter_type=all&filter_banner_size=+--+All+Sizes+--&orderby=&direction=&currec=".($nNumPerPage * ($nPageNo - 1) + 1)."&pagesize=".$nNumPerPage;
			$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
			$result = $r["content"];
			print "Get Merchant List - Premium : Page - $nPageNo <br>\n";

			//parse HTML
			$strLineStart = '<td class="td_left_edge">';

			$nLineStart = 0;
			while ($nLineStart >= 0){
				if($this->debug) print "Process $Cnt  ";

				$nLineStart = stripos($result, $strLineStart, $nLineStart);
				if ($nLineStart === false) break;
				// ID 	Name 	EPC 	Status
				$strMerID = $this->oLinkFeed->ParseStringBy2Tag($result, array('select_mid[]', 'value="'), '"', $nLineStart);
				//$strMerID = str_replace('~', '_', $strMerID);
				list($strTmpMerID, $strTmpOfferID, $strTmpNetworkID) = explode('~', $strMerID);
				$strMerID = $strTmpMerID.'_'.$strTmpNetworkID;
				if(isset($exist_prgm[$strMerID])) continue;

				$strMerName = $this->oLinkFeed->ParseStringBy2Tag($result, 'helpMessage(this);">', '</a>', $nLineStart);
				//us or uk
				$strMerFlag = strtoupper($this->oLinkFeed->ParseStringBy2Tag($result, 'images/common/flag_', ".", $nLineStart));
				$TargetCountryExt = $strMerFlag;
				//$strMerName = html_entity_decode($strMerName);
				$strMerName = trim($strMerName) . ' ('.$strMerFlag.') ';
				//desc
				$desc = strip_tags($this->oLinkFeed->ParseStringBy2Tag($result, "</span>", '<img src', $nLineStart));
				$aff_mer_url = $this->oLinkFeed->ParseStringBy2Tag($result, array('images/arrows/caret.gif" alt="Arrow">', '<a href="'), '">View Links</a>', $nLineStart);
				//join date
				$JoinDate = $this->oLinkFeed->ParseStringBy2Tag($result, array('<td class="td_date_joined">'), '</td>', $nLineStart);
				$JoinDate = $JoinDate. "-01-01 00:00:00";
				//CommissionExt
				$CommissionExt = $this->oLinkFeed->ParseStringBy2Tag($result, array('<td class="td_commission">'), '</td>', $nLineStart);
				//ReturnDays
				$ReturnDays = $this->oLinkFeed->ParseStringBy2Tag($result, array('<td class="td_return">'), '</td>', $nLineStart);

				//class="td_status" or class="td_status_temp"
				$strStatusShow = trim($this->oLinkFeed->ParseStringBy2Tag($result, '<td class="td_status', "<br>", $nLineStart));
				$strStatus = $this->getStatusByStr($strStatusShow);
				if($strStatus === false)
				{
					print_r($result);
					mydie("Unknown Status : $strStatusShow <br>\n");
				}

				$StatusInAffRemark = strip_tags(str_ireplace(array('">','_temp">'),"",$strStatusShow));
				//$StatusInAff = $strStatus;//'Active','TempOffline','Expired'
				if(stripos($strStatusShow,'Approved') !== false){
					$Partnership = "Active";
					$StatusInAff = "Active";
				}
				elseif(stripos($strStatusShow,'Pending') !== false){
					$Partnership = "Pending";
					$StatusInAff = "Active";
				}
				elseif(stripos($strStatusShow,'No Relationship') !== false){
					$Partnership = "NoPartnership";
					$StatusInAff = "Active";
				}
				elseif(stripos($strStatusShow, "Declined") !== false){
					$Partnership = "Declined";
					$StatusInAff = "Active";
				}
				elseif(stripos($strStatusShow, "Removed") !== false){
					$Partnership = "Removed";
					$StatusInAff = "Active";
				}
				elseif(stripos($strStatusShow, "Discontinued") !== false){
					$Partnership = "NoPartnership";
					$StatusInAff = "TempOffline";
				}
				elseif(stripos($strStatusShow, "Extended") !== false){
					$Partnership = "Active";
					$StatusInAff = "Active";
				}
				else{
					$Partnership = "NoPartnership";
					$StatusInAff = "Active";
				}

				//program_detail
				$prgm_url = "http://cli.linksynergy.com/cli/publisher/programs/advertiser_detail.php?oid=$strTmpOfferID&mid=$strTmpMerID&offerNid=$strTmpNetworkID&controls=1:1:1:1:1:0";

				$more_info = $this->getSupportDUT($strTmpMerID, $strTmpOfferID, $request, true);
				$SupportDeepurl = $more_info['SupportDeepurl'];
				$CategoryExt = $more_info['CategoryExt'];
				$TermAndCondition = $more_info['TermAndCondition'];

				//program
				$arr_prgm[$strMerID] = array(
					"Name" => addslashes(trim($strMerName)),
					"AffId" => $this->info["AffId"],
					"Homepage" => addslashes($Homepage),
					"CategoryExt" => addslashes($CategoryExt),
					"Contacts" => addslashes($Contacts),
					"TargetCountryExt" => $TargetCountryExt,
					"RankInAff" => 5,
					"IdInAff" => $strMerID,
					"JoinDate" => $JoinDate,
					//"CreateDate" => "0000-00-00 00:00:00",
					//"DropDate" => "0000-00-00 00:00:00",
					"TermAndCondition" => addslashes($TermAndCondition),
					"StatusInAff" => $StatusInAff,						//'Active','TempOffline','Inactive'
					"StatusInAffRemark" => addslashes($StatusInAffRemark),
					"Partnership" => $Partnership,						//'NoPartnership','Active','Pending','Declined','Expired','Removed'
					"Description" => $desc,
					"CommissionExt" => addslashes($CommissionExt),
					"CookieTime" => $ReturnDays,
					"LastUpdateTime" => date("Y-m-d H:i:s"),
					"SecondIdInAff" => $strTmpOfferID,
					"DetailPage" => $prgm_url,
					"SupportDeepurl" => $SupportDeepurl
				);
				$arr_prgm[$strMerID] = array_merge($this->getMobileFriendly($strTmpMerID), $arr_prgm[$strMerID]);
				$program_num++;
				if(count($arr_prgm) >= 100){
					$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
					$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
					$arr_prgm = array();
				}
			}
			if(count($arr_prgm)){
				$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
				$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
				unset($arr_prgm);
			}
			//Check if have next page;
			if (false === $this->oLinkFeed->ParseStringBy2Tag($result, "document.myform.submit();return false;'>Next", '</a></div></div>', $nLineStart)){
				$bHasNextPage = false;
				if($this->debug) print " NO NEXT PAGE  <br>\n";
			}
			else{
				if($this->debug) print " Have NEXT PAGE  <br>\n";
			}

			if ($bHasNextPage){
				$nPageNo++;
			}
		}//per page

		echo "\tGet Program by page end\r\n";
		echo "<hr>\r\n";
		echo count($exist_prgm)."/".$program_num;
		echo "<hr>\r\n";
		if($program_num < 10){
			mydie("die: program count < 10, please check program.\n");
		}
		echo "\tUpdate ({$program_num}) program.\r\n";
		echo "\tSet program country int.\r\n";
		$objProgram->setCountryInt($this->info["AffId"]);
	}

	function checkProgramOffline($AffId, $check_date){
		$objProgram = new ProgramDb();
		$prgm = array();
		$prgm = $objProgram->getNotUpdateProgram($this->info["AffId"], $check_date);
		if(count($prgm) > 30){
			mydie("die: too many offline program (".count($prgm).").\n");
		}else{
			$objProgram->setProgramOffline($this->info["AffId"], $prgm);
			echo "\tSet (".count($prgm).") offline program.\r\n";
		}
	}

	function getSupportDUT($mid, $oid, $request, $needmoreinfo = false)
	{
		$mid = intval($mid);
		$oid = intval($oid);
		$SupportDeepurl = "UNKNOWN";
		$return_arr = array('SupportDeepurl' => $SupportDeepurl);
		if($mid && $oid){
			$prgm_url = "http://cli.linksynergy.com/cli/publisher/programs/adv_info.php?mid=$mid&oid=$oid";
			$prgm_arr = $this->oLinkFeed->GetHttpResult($prgm_url, $request);
			$prgm_detail = $prgm_arr["content"];

			$SupportDeepurl = trim(strip_tags($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('Deep Linking Enabled', '<td>'), '</td>')));
			if(stripos($SupportDeepurl, "yes") !== false){
				$SupportDeepurl = "YES";
			}else{
				$SupportDeepurl = "NO";
			}
			$return_arr = array('SupportDeepurl' => $SupportDeepurl);

			if($needmoreinfo)
			{
				$CategoryExt = $this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('Categories:', '<td>'), "</td>");
				$CategoryExt = trim(strip_tags(str_replace("<br>", ", ", $CategoryExt)), ",");
				$Homepage = trim(strip_tags($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('Website:', '<td>'), "</td>")));
				$Contact_Name = $this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('Contact Name:', '<td>'), "</td>");
				$Contact_Title = $this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('Contact Title:', '<td>'), "</td>");
				$Contact_Phone = $this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('Phone Number:', '<td>'), "</td>");
				$Contact_Email = strip_tags($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('Email Address:', '<td>'), "</td>"));
				$Contact_Address = $this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('Company Address:', '<td>'), "</td>");
				$Contact_Address = trim(strip_tags(str_replace("<br>", ", ", $Contact_Address)));
				$Contacts = "$Contact_Name($Contact_Title), Email: $Contact_Email, Phone: $Contact_Phone, Address: $Contact_Address.";
				$term_url = $this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('Terms & Conditions:', 'href="'), '"');
				$term_arr = $this->oLinkFeed->GetHttpResult($term_url, $request);
				$TermAndCondition = $term_arr["content"];
				$return_arr['CategoryExt'] = $CategoryExt;
				$return_arr['Homepage'] = $Homepage;
				$return_arr['Contacts'] = $Contacts;
				$return_arr['TermAndCondition'] = $TermAndCondition;
			}
		}
		return $return_arr;
	}
	
	function getMobileFriendly($mid)
	{
		$request = array("AffId" => $this->info["AffId"], "method" => "get");
		$url = "http://cli.linksynergy.com/cli/publisher/programs/Tracking/mobile_tracking_detail.php?mid=$mid";
		$r = $this->oLinkFeed->GetHttpResult($url, $request);
		$content = $r['content'];
		if (preg_match('@green_check\.png"@', $content))
		{
			return array('MobileFriendly' => 'YES');
		}
		if (preg_match('@red_x\.png"@', $content))
		{
			return array('MobileFriendly' => 'NO');
		}
		if (!preg_match('@Pending\s+</td>@', $content))
		{
			echo "error page format\n";
			echo "$url\n";
			//exit(1);
		}
		return array('MobileFriendly' => 'UNKNOWN');
	}
}

