<?php

require_once 'text_parse_helper.php';

class LinkFeed_46_ClixGalore
{
	var $info = array(
		"ID" => "46",
		"Name" => "clixGalore",
		"IsActive" => "YES",
		"ClassName" => "LinkFeed_46_ClixGalore",
		"LastCheckDate" => "1970-01-01",
	);
	
	function __construct($aff_id,$oLinkFeed)
	{
		$this->oLinkFeed = $oLinkFeed;
		$this->info = $oLinkFeed->getAffById($aff_id);
		$this->debug = isset($oLinkFeed->debug) ? $oLinkFeed->debug : false;
		
		$this->file = "programlog_{$aff_id}_".date("Ymd_His").".csv";
	}
		
	function Login()
	{
		$strUrl = "https://www.clixgalore.com/memberlogin.aspx";
		$request = array("method" => "get", "postdata" => "", );
		$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
		$result = $r["content"];
		$__EVENTVALIDATION = urlencode($this->oLinkFeed->ParseStringBy2Tag($result, array('name="__EVENTVALIDATION"', 'value="'), '"'));
		$__VIEWSTATE = urlencode($this->oLinkFeed->ParseStringBy2Tag($result, array('name="__VIEWSTATE"', 'value="'), '"'));
		$this->info["AffLoginPostString"] = "__EVENTARGUMENT=&__EVENTTARGET=&__EVENTVALIDATION={$__EVENTVALIDATION}&__VIEWSTATE={$__VIEWSTATE}&txt_UserName=cg%40couponsnapshot.com&txt_Password=PcV%26gF8ID*c8Y&cmd_login.x=53&cmd_login.y=12";
		$this->oLinkFeed->LoginIntoAffService($this->info["AffId"],$this->info);
	}

	private function csv_string_to_array_46($content)
	{
		$r = array();
		$delimiter = ",";
		$line_delimiter = "\n";
		$lines = explode($line_delimiter, $content);
		if (empty($lines) || !is_array($lines))
			return $r;
		for($i = 0; $i < count($lines); $i ++)
		{
			if ($i == 0)
				continue;
			$line = str_force_utf8($lines[$i]);
			$fields = mem_getcsv($line, ',', '"', '"');
			if (empty($fields) || !is_array($fields) || count($fields) < 1)
				continue;
			$r[] = $fields;
		}
		return $r;
	}
	
	function getCouponFeed()
	{
		$arr_return = array("AffectedCount" => 0,"UpdatedCount" => 0,"Detail" => array());
		$request = array("AffId" => $this->info["AffId"],"method" => "get","postdata" => "");

		//coupon
		$url = "http://www.clixgalore.com/AffiliateSearchCoupons_Export.aspx?PT=1,2,3,4&C=&K=&CID=0&R=0&AfID=221993&ID=179533&JO=0&type=csv";
		$r = $this->oLinkFeed->GetHttpResult($url, $request);
		$content = $r['content'];
		$data = $this->csv_string_to_array_46($content);
		$links = array();
		if (is_array($data))
		{
			foreach ($data as $v)
			{
				if (count($v) < 13)
					continue;
				$link = array(
						"AffId" => $this->info["AffId"],
						"LinkName" => $v[4],
						"LinkDesc" => $v[7],
						"LinkStartDate" => parse_time_str($v[5], null, false),
						"LinkEndDate" => parse_time_str($v[6], null, true),
						"LinkPromoType" => 'COUPON',
						"LinkHtmlCode" => $v[11],
						"LinkCode" => $v[3],
						"LinkOriginalUrl" => '',
						"LinkImageUrl" => $v[9],
						"DataSource" => 75,
				);
				if (empty($link['LinkHtmlCode']))
					continue;
				$link['LinkHtmlCode'] = $link['LinkHtmlCode'];
				if (preg_match('@<a href="(.*?)"@', $link['LinkHtmlCode'], $g))
					$link['LinkAffUrl']	= $g[1];
				if (preg_match('@AdID=(\d+)\&@', $link['LinkHtmlCode'], $g))
					$link['AffMerchantId'] = $g['1'];
				if (preg_match('@BID=(\d+)\&@', $link['LinkHtmlCode'], $g))
					$link['AffLinkId'] = $g['1'];
				if (empty($link['AffMerchantId']) || empty($link['AffLinkId']) || empty($link['LinkName']) || empty($link['LinkHtmlCode']))
					continue;
				$links[] = $link;
				$arr_return["AffectedCount"] ++;
			}
		}
		echo sprintf("%s coupon(s) found. \n", count($links));
		if (count($links) > 0)
			$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);

		//text & banner
		$url = "http://www.clixGalore.com/AffiliateViewLinkCode_Export.aspx?AfID=221993&CID=179533&BT=0&MI=2&H=&W=&S=&type=csv";
		$r = $this->oLinkFeed->GetHttpResult($url, $request);
		$content = $r['content'];
		$data = $this->csv_string_to_array_46($content);
		$links = array();
		if (is_array($data))
		{
			$links = array();
			foreach ($data as $v)
			{
				if (count($v) < 11)
					continue;
				$link = array(
						"AffId" => $this->info["AffId"],
						"LinkName" => $v[2],
						"LinkDesc" => '',
						"LinkStartDate" => parse_time_str($v[0], null, false),
						"LinkEndDate" => '0000-00-00',
						"LinkPromoType" => 'DEAL',
						"LinkHtmlCode" => $v[10],
						"LinkOriginalUrl" => '',
						"DataSource" => 75,
				);
				if (empty($link['LinkHtmlCode']))
					continue;
				if (preg_match('@<a href="(.*?)"@i', $link['LinkHtmlCode'], $g))
					$link['LinkAffUrl']	= $g[1];
				if (preg_match('@AdID=(\d+)\&@', $link['LinkHtmlCode'], $g))
					$link['AffMerchantId'] = $g[1];
				if (preg_match('@BID=(\d+)\&@', $link['LinkHtmlCode'], $g))
					$link['AffLinkId'] = $g[1];
				if (empty($link['AffMerchantId']) || empty($link['AffLinkId']) || empty($link['LinkName']) || empty($link['LinkHtmlCode']))
					continue;
				$links[] = $link;
				$arr_return["AffectedCount"] ++;
			}
		}
		echo sprintf("%s links(s) found. \n", count($links));
		if (count($links) > 0)
			$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);

		return $arr_return;
	}

	function GetAllLinksFromAffByMerID($merinfo)
	{
		$aff_id = $this->info["AffId"];
		$arr_return = array("AffectedCount" => 0, "UpdatedCount" => 0, );
		return $arr_return;
	}
	
	function GetProgramFromAff()
	{
		$check_date = date("Y-m-d H:i:s");
		echo "Craw Program start @ {$check_date}\r\n";

		$this->GetProgramFromByPage();
		$this->checkProgramOffline($this->info["AffId"], $check_date);

		echo "Craw Program end @ ".date("Y-m-d H:i:s")."\r\n";
	}

	function GetProgramFromByPage()
	{
		echo "\tGet Program by page start\r\n";
		$objProgram = new ProgramDb();
		$arr_prgm = array();
		$program_num = 0;

		//step 1,login
		$this->Login();

		$request = array("AffId" => $this->info["AffId"], "method" => "post", "postdata" => "",);
		$tmp_request = array("AffId" => $this->info["AffId"], "method" => "get");
		$prgm_records = array();

		//"http://www.clixGalore.com/AffiliateViewJoinRequests_Export.aspx?AfID=221993&CID=179533&RS=10&BT=0&MS=0&EF=csv";//active
		//"http://www.clixGalore.com/AffiliateViewJoinRequests_Export.aspx?AfID=221993&CID=179533&RS=10&BT=0&MS=2&EF=csv";//low 
		//"http://www.clixGalore.com/AffiliateViewJoinRequests_Export.aspx?AfID=221993&CID=179533&RS=10&BT=0&MS=1&EF=csv";//inactive

		//program management adv
		echo "get program \r\n";
		$dd_filter_arr = array(1 => 'Offline', 2 => 'TempOffline', 0 => 'Active');
		foreach($dd_filter_arr as $dd_filter => $StatusInAff){
			$strUrl = "http://www.clixgalore.com/AffiliateViewJoinRequests.aspx";
			$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
			$result = $r["content"];

			$hasNextPage = true;
			$page = 1;
			while($hasNextPage){
				echo "\t page $page.";
				if(!empty($result)){
					if($page == 1){
						$__EVENTVALIDATION = urlencode($this->oLinkFeed->ParseStringBy2Tag($result, array('name="__EVENTVALIDATION"', 'value="'), '"'));
						$__VIEWSTATE = urlencode($this->oLinkFeed->ParseStringBy2Tag($result, array('name="__VIEWSTATE"', 'value="'), '"'));
						$request["postdata"] = '__VIEWSTATE='.$__VIEWSTATE.'&__EVENTVALIDATION='.$__EVENTVALIDATION.'&dd_RequestStatus=10&AffProgramDropDown1%24aff_program_list=221993&dd_BannerType=0&dd_filter='.$dd_filter.'&cmd_report=Retrieve+Details';
					}else{
						$__EVENTVALIDATION = urlencode($this->oLinkFeed->ParseStringBy2Tag($result, array('name="__EVENTVALIDATION"', 'value="'), '"'));
						$__VIEWSTATE = urlencode($this->oLinkFeed->ParseStringBy2Tag($result, array('name="__VIEWSTATE"', 'value="'), '"'));
						$request["postdata"] = '__EVENTTARGET='.$__EVENTTARGET.'&__EVENTARGUMENT=&__VIEWSTATE='.$__VIEWSTATE.'&__EVENTVALIDATION='.$__EVENTVALIDATION.'&dd_RequestStatus=10&AffProgramDropDown1%24aff_program_list=221993&dd_BannerType=0&dd_filter='.$dd_filter.'&txt_advsearch=';
					}
				}else{
					mydie("die: postdata error.\n");
				}

				$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
				$result = $r["content"];

				$tmp_target = trim($this->oLinkFeed->ParseStringBy2Tag($result, array('Pages Found:', "<span>$page</span>", '__doPostBack(\'dg_Merchants$ctl24$ctl'), "'"));
				if($tmp_target == false) $hasNextPage = false;
				$__EVENTTARGET = urlencode('dg_Merchants$ctl24$ctl'.$tmp_target);

				$strLineStart = 'class="StdLink" title="View Merchant Details"';

				$nLineStart = 0;
				while ($nLineStart >= 0){
					$nLineStart = stripos($result, $strLineStart, $nLineStart);
					if ($nLineStart === false) break;
					//class
					/*if($StatusInAff == 'Active'){
						$class = intval($this->oLinkFeed->ParseStringBy2Tag($result, '<tr class="', '"', $nLineStart - 100));
						if($class == 'lowbalanceMediumWarning'){//lowbalanceHighWarning
							$StatusInAff = 'TempOffline';
						}
					}*/

					//id
					$strMerID = intval($this->oLinkFeed->ParseStringBy2Tag($result, "OpenDetails(", ")", $nLineStart));
					if (!$strMerID) break;

					if(isset($prgm_records[$strMerID])) continue;
					//name
					$strMerName = trim(strip_tags($this->oLinkFeed->ParseStringBy2Tag($result, '>' , "</a>", $nLineStart)));
					if ($strMerName === false) break;

					$StatusInAffRemark = trim($this->oLinkFeed->ParseStringBy2Tag($result, array('<td align="center">','<td align="center">','<td align="center">','<td align="center">'), "</td>", $nLineStart));
					if($StatusInAffRemark == 'Approved'){
						$Partnership = 'Active';
					}elseif($StatusInAffRemark == 'Pending'){
						$Partnership = 'Pending';
					}elseif($StatusInAffRemark == 'Declined'){
						$Partnership = 'Declined';
					}else{
						mydie("die: unknown $strMerName partnership: $StatusInAffRemark.\n");
					}
					if($StatusInAff == 'TempOffline'){
						$StatusInAffRemark = 'Low Balance';
					}
					$arr_prgm[$strMerID] = array(
						"Name" => addslashes(html_entity_decode(trim($strMerName))),
						"AffId" => $this->info["AffId"],
						"IdInAff" => $strMerID,	
						"StatusInAff" => $StatusInAff,						//'Active','TempOffline','Offline'
						"StatusInAffRemark" => $StatusInAffRemark,
						"Partnership" => $Partnership,						//'NoPartnership','Active','Pending','Declined','Expired','WeDeclined'					
						"LastUpdateTime" => date("Y-m-d H:i:s"),
						"SupportDeepUrl" => 'YES'
					);
					$prgm_records[$strMerID] = 1;
					$program_num++;
					if(count($arr_prgm) >= 100){
						$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
						$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
						$arr_prgm = array();
					}
				}
				$page++;
				if($page > 300){
					mydie("die: Page overload.\n");
				}
			}
			if(count($arr_prgm)){
				$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
				$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
				unset($arr_prgm);
			}
		}
		//program management adv
		echo "get program from program management adv\r\n";
		$strUrl = "http://www.clixgalore.com/AffiliateNotificationReport.aspx";
		$result = "";
		$request = array("AffId" => $this->info["AffId"], "method" => "get", "postdata" => "",);
		$hasNextPage = true;
		$page = 1;
		while($hasNextPage){
			echo "\t page $page.";
			if(!empty($result)){
				//$__EVENTTARGET = urlencode('dg_Merchants$ctl44$ctl01');
				$__EVENTVALIDATION = urlencode($this->oLinkFeed->ParseStringBy2Tag($result, array('name="__EVENTVALIDATION"', 'value="'), '"'));
				$__VIEWSTATE = urlencode($this->oLinkFeed->ParseStringBy2Tag($result, array('name="__VIEWSTATE"', 'value="'), '"'));
				$request["method"] = "post";
				$request["postdata"] = '__EVENTTARGET='.$__EVENTTARGET.'&__EVENTARGUMENT=&__LASTFOCUS=&__VIEWSTATE='.$__VIEWSTATE.'&__EVENTVALIDATION='.$__EVENTVALIDATION.'&AffProgramDropDown1%24aff_program_list=221993&txt_advsearch=';
			}elseif($page != 1){
				mydie("die: postdata error.\n");
			}
			$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
			$result = $r["content"];

			$tmp_target = trim($this->oLinkFeed->ParseStringBy2Tag($result, array('Pages Found:', "<span>$page</span>", '__doPostBack(\'dg_Merchants$ctl44$ctl'), "'"));
			if($tmp_target == false) $hasNextPage = false;
			$__EVENTTARGET = urlencode('dg_Merchants$ctl44$ctl'.$tmp_target);

			//$strLineStart = '<tr class="ColumnHeading">';
			$strLineStart = 'class="StdLink" title="View Merchant Details"';
			$nLineStart = 0;
			$nLineStart = stripos($result, $strLineStart, $nLineStart);
			//$strLineStart = '<tr';
			while ($nLineStart >= 0){
				$nLineStart = stripos($result, $strLineStart, $nLineStart);
				if ($nLineStart === false) break;
				//class
				/*$StatusInAff = 'Active';
				$class = intval($this->oLinkFeed->ParseStringBy2Tag($result, '<tr class="', '"', $nLineStart));
				if($class == 'lowbalanceMediumWarning'){//lowbalanceHighWarning
					$StatusInAff = 'TempOffline';
				}elseif($class == 'lowbalanceHighWarning'){
					$StatusInAff = 'Offline';
				}elseif($class != 'celldetail' && $class != 'Alternatecelldetail'){
					break;
				}*/
				//id
				$strMerID = intval($this->oLinkFeed->ParseStringBy2Tag($result, "OpenDetails(", ")", $nLineStart));
				if (!$strMerID) break;
				//if(isset($prgm_records[$strMerID])) continue;
				//name
				$strMerName = trim(strip_tags($this->oLinkFeed->ParseStringBy2Tag($result, '>' , "</a>", $nLineStart)));
				if ($strMerName === false) break;

				$tmpStr = trim($this->oLinkFeed->ParseStringBy2Tag($result, 'NAME="Label1">', "</span>", $nLineStart));
				$TargetCountryExt = substr($tmpStr, 0, 2);
				$EPC30d = substr($tmpStr, 2);

				$TermAndCondition = "";
				$tmpStr = trim($this->oLinkFeed->ParseStringBy2Tag($result, array('javascript:TermsCondition', $strMerID, '>'), "</a>", $nLineStart));
				if($tmpStr == 'View T&C'){
					$tc_url = "http://www.clixgalore.com/popup_ViewMerchantTC.aspx?ID=$strMerID";
					$tc_arr = $this->oLinkFeed->GetHttpResult($tc_url, $tmp_request);
					$tc_detail = $prgm_arr["content"];
					$TermAndCondition = trim($this->oLinkFeed->ParseStringBy2Tag($tc_detail, array('<textarea name="txt_tc"', '>'), "</textarea>"));
				}

				$prgm_url = "http://www.clixgalore.com/PopupMerchantDetails.aspx?ID=$strMerID";
				$prgm_arr = $this->oLinkFeed->GetHttpResult($prgm_url, $tmp_request);
				$prgm_detail = $prgm_arr["content"];

				$Homepage = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('Website URL', 'href="'), '"'));
				$CommissionExt = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, 'id="lbl_commission_rate">', '</span>'));
				$desc = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, 'id="lbl_description">', '</span>'));
				$CookieTime = intval($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, 'id="lbl_cookie_expiry">', '</span>'));

				$SubAffPolicyExt = "";
				$lbl_traffic = strip_tags($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, 'id="lbl_traffic">', '</span>'));
				if($lbl_traffic){
					$SubAffPolicyExt = "Not Accepting Traffic From: " . $lbl_traffic;
				}

				$arr_prgm[$strMerID] = array(
					"Name" => addslashes(html_entity_decode(trim($strMerName))),
					"AffId" => $this->info["AffId"],
					"TargetCountryExt" => $TargetCountryExt,
					"IdInAff" => $strMerID,
					//"StatusInAff" => 'Active',						//'Active','TempOffline','Offline'
					//"StatusInAffRemark" => '',
					//"Partnership" => 'Active',						//'NoPartnership','Active','Pending','Declined','Expired','WeDeclined'				
					"Description" => addslashes($desc),
					"Homepage" => $Homepage,
					"CommissionExt" => addslashes($CommissionExt),
					"EPC30d" => $EPC30d,
					"CookieTime" => $CookieTime,
					"TermAndCondition" => addslashes($TermAndCondition),
					"SubAffPolicyExt" => addslashes($SubAffPolicyExt),
					"LastUpdateTime" => date("Y-m-d H:i:s"),
					"DetailPage" => $prgm_url,
					"SupportDeepUrl" => 'YES'
				);
				$prgm_records[$strMerID] = 1;
				$program_num++;
				if(count($arr_prgm) >= 100){
					$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
					$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
					$arr_prgm = array();
				}
			}
			$page++;
			if($page > 100){
				mydie("die: Page overload.\n");
			}
		}
		if(count($arr_prgm)){
			$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
			$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
			unset($arr_prgm);
		}
		echo "\tGet Program by page end\r\n";
		if($program_num < 10){
			mydie("die: program count < 10, please check program.\n");
		}
		echo "\tUpdate ({$program_num}) program.\r\n";
		echo "\tSet program country int.\r\n";

		$objProgram->setCountryInt($this->info["AffId"]);
	}
	
	function checkProgramOffline($AffId, $check_date){
		$objProgram = new ProgramDb();
		$prgm = array();
		$prgm = $objProgram->getNotUpdateProgram($this->info["AffId"], $check_date);
		if(count($prgm) > 30){
			mydie("die: too many offline program (".count($prgm).").\n");
		}else{
			$objProgram->setProgramOffline($this->info["AffId"], $prgm);
			echo "\tSet (".count($prgm).") offline program.\r\n";
		}
	}
}

