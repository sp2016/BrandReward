<?php

define('API_KEY_6', 'd8fb6cd3f139e75abe2ed10468155c05e678464eca2cb13c7fa29e691525847d');
require_once 'text_parse_helper.php';

class LinkFeed_6_PJN
{
	function __construct($aff_id,$oLinkFeed)
	{
		$this->oLinkFeed = $oLinkFeed;
		$this->info = $oLinkFeed->getAffById($aff_id);
		$this->debug = isset($oLinkFeed->debug) ? $oLinkFeed->debug : false;

		$this->file = "programlog_{$aff_id}_".date("Ymd_His").".csv";
	}

	function getInvalidLinks()
	{
		$request = array("AffId" => $this->info["AffId"], "method" => "post", "postdata" => "",);
		$this->oLinkFeed->LoginIntoAffService($this->info["AffId"],$this->info);
		list($page, $pages, $links, $ids) = array(0, 0, array(), array());
		do
		{
			$url = sprintf('http://www.pepperjamnetwork.com/affiliate/report/invalid-link?csv=csv&ajax=ajaxsortColumn=created&sortType=DESC&rowsPerPage=100&offset=%s', $page);
			$affid = $this->info["AffId"];
			$r = $this->oLinkFeed->GetHttpResult($url, $request);
			$content = $r['content'];
			if (empty($pages))
			{
				if(preg_match('@</select> of (\d+)\s+</div>@', $content, $g))
					$pages = $g[1];
			}
			preg_match_all('@<tr class="tableEven reportGenRow">(.*?)</tr>@ms', $content, $chapters);
			foreach ($chapters[1] as $chapter)
			{
				preg_match_all('@<td>(.*?)</td>@ms', $chapter, $columns);
				$id = trim($columns[1][2]);
				if (!empty($ids[$id]))
				{
//					echo "duplicate id: $id.\n";
					continue;
				}
				$ids[$id] = 1;
				foreach ($links as $key => $link)
				{
					if ($link['LinkID'] == $id)
					{
						$links[$key]['Clicks'] += 1;
					}
				}
				$link = array(
					'affiliate' => $this->info["AffId"],
					'LinkID' => $id,
					'ProgramName' => trim($columns[1][1]),
					'AffiliationStatus' => trim($columns[1][4]),
					'ProgramID' => trim($columns[1][0]),
					'CreativeType' => trim($columns[1][3]),
					'Clicks' => 1,
				);
				foreach ($links as $exist)
				{
					if ($exist['LinkID'] == $link['LinkID'])
						continue;
				}
				if (preg_match('@cidtype\'\:\s+\'(.*?)\'@', $chapter, $g))
				{
					$url = sprintf("http://www.pepperjamnetwork.com/affiliate/report/creative-details-information?cid=%s&cidType=%s", $link['LinkID'], $g[1]);
					$r = $this->oLinkFeed->GetHttpResult($url, $request);
					$detail = $r['content'];
					if (preg_match('@<table>(.*?)</table>@ms', $detail, $g))
						$link['Details'] = trim($g[1]);
					$links[] = $link;
				}
			}
			$page ++;
		}while ($page < $pages);
		return $links;
	}

	function getCouponFeed()
	{
		$arr_return = array("AffectedCount" => 0, "UpdatedCount" => 0, "Detail" => array(), );
		$request = array("AffId" => $this->info["AffId"], "method" => "get", "postdata" => "", );

		$methods = array('coupon', 'text', 'banner');
		$links = array();
		foreach ($methods as $method)
		{
			$count = 0;
			$url = sprintf('http://api.pepperjamnetwork.com/20120402/publisher/creative/%s?apiKey=%s&format=csv', $method, API_KEY_6);
			$r = $this->oLinkFeed->GetHttpResult($url, $request);
			$content = $r["content"];
			$data = @fgetcsv_str($content);
			foreach ((array)$data as $v)
			{
				$link = array(
						"AffId" => $this->info["AffId"],
						"AffMerchantId" => $v['program_id'],
						"AffLinkId" => sprintf('c_%s_%s', $v['id'], $v['program_id']),
						"LinkName" => sprintf('%s', $v['name']),
						"LinkDesc" => sprintf('%s', $v['description']),
						"LinkStartDate" => parse_time_str($v['start_date'], 'Y-m-d H:i:s', false),
						"LinkEndDate" => parse_time_str($v['end_date'], 'Y-m-d H:i:s', false),
						"LinkPromoType" => 'N/A',
						"LinkHtmlCode" => '',
						"LinkCode" => '',
						"LinkOriginalUrl" => '',
						"LinkImageUrl" => '',
						"LinkAffUrl" => '',
						"DataSource" => '64',
				);
				switch ($method)
				{
					case 'coupon':
						$link['LinkCode'] = $v['coupon'];
						$link['LinkPromoType'] = 'COUPON';
						$link['LinkAffUrl'] = $v['code'];
						$link['LinkHtmlCode'] = create_link_htmlcode_image($link);
						break;
					case 'text':
						$link['LinkAffUrl'] = $v['tracking_url'];
						$link['LinkHtmlCode'] = $v['code'];
						$link['LinkPromoType'] = $this->oLinkFeed->getPromoTypeByLinkContent($link['LinkName']);
						$code = get_linkcode_by_text($link['LinkName']);
						if (!empty($code))
						{
							$link['LinkCode'] = $code;
							$link['LinkPromoType'] = 'COUPON';
						}
						break;
					case 'banner':
						$link['LinkAffUrl'] = $v['tracking_url'];
						$link['LinkHtmlCode'] = $v['code'];
						$link['LinkPromoType'] = $this->oLinkFeed->getPromoTypeByLinkContent($link['LinkName']);
						$code = get_linkcode_by_text($link['LinkName']);
						if (!empty($code))
						{
							$link['LinkCode'] = $code;
							$link['LinkPromoType'] = 'COUPON';
						}
						if (preg_match('@img src="(.*?)"@', $link['LinkHtmlCode'], $g))
							$link['LinkImageUrl'] = $g[1];
						break;
					default:
						break;
				}
				if (empty($link['AffLinkId']) || empty($link['LinkName']))
					continue;
				$this->oLinkFeed->fixEnocding($this->info, $link, "feed");
				$arr_return["AffectedCount"] ++;
				$count ++;
				$links[] = $link;
				if (($arr_return['AffectedCount'] % 100) == 0)
				{
					$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);
					$links = array();
				}
			}
			echo sprintf("call api %s...%s result(s) find.\n", $method, $count);
		}
		if (count($links) > 0)
			$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);
		
		return $arr_return;
	}
	
	function GetAllLinksFromAffByMerID($merinfo)
	{
		$arr_return = array("AffectedCount" => 0, "UpdatedCount" => 0, "Detail" => array(), );
		$request = array("AffId" => $this->info["AffId"], "method" => "get", );
		$methods = array('coupon', 'text', 'banner');
		$links = array();
		foreach ($methods as $method)
		{
			$url = sprintf('http://api.pepperjamnetwork.com/20120402/publisher/creative/%s?apiKey=%s&format=csv&programId=%s', $method, API_KEY_6, $merinfo['IdInAff']);
			$r = $this->oLinkFeed->GetHttpResult($url, $request);
			$content = $r["content"];
			$data = @fgetcsv_str($content);
			$count = 0;
			foreach ((array)$data as $v)
			{
				$link = array(
						"AffId" => $this->info["AffId"],
						"AffMerchantId" => $v['program_id'],
						"AffLinkId" => sprintf('c_%s_%s', $v['id'], $v['program_id']),
						"LinkName" => sprintf('%s', $v['name']),
						"LinkDesc" => sprintf('%s', $v['description']),
						"LinkStartDate" => parse_time_str($v['start_date'], 'Y-m-d H:i:s', false),
						"LinkEndDate" => parse_time_str($v['end_date'], 'Y-m-d H:i:s', false),
						"LinkPromoType" => 'N/A',
						"LinkHtmlCode" => '',
						"LinkCode" => '',
						"LinkOriginalUrl" => '',
						"LinkImageUrl" => '',
						"LinkAffUrl" => '',
						"DataSource" => '64',
				);
				switch ($method)
				{
					case 'coupon':
						$link['LinkCode'] = $v['coupon'];
						$link['LinkPromoType'] = 'COUPON';
						$link['LinkAffUrl'] = $v['code'];
						$link['LinkHtmlCode'] = create_link_htmlcode_image($link);
						break;
					case 'text':
						$link['LinkAffUrl'] = $v['tracking_url'];
						$link['LinkHtmlCode'] = $v['code'];
						$link['LinkPromoType'] = $this->oLinkFeed->getPromoTypeByLinkContent($link['LinkName']);
						$code = get_linkcode_by_text($link['LinkName']);
						if (!empty($code))
						{
							$link['LinkCode'] = $code;
							$link['LinkPromoType'] = 'COUPON';
						}
						break;
					case 'banner':
						$link['LinkAffUrl'] = $v['tracking_url'];
						$link['LinkHtmlCode'] = $v['code'];
						$link['LinkPromoType'] = $this->oLinkFeed->getPromoTypeByLinkContent($link['LinkName']);
						$code = get_linkcode_by_text($link['LinkName']);
						if (!empty($code))
						{
							$link['LinkCode'] = $code;
							$link['LinkPromoType'] = 'COUPON';
						}
						if (preg_match('@img src="(.*?)"@', $link['LinkHtmlCode'], $g))
							$link['LinkImageUrl'] = $g[1];
						break;
					default:
						break;
				}
				if (empty($link['AffLinkId']) || empty($link['LinkName']))
					continue;
				$this->oLinkFeed->fixEnocding($this->info, $link, "feed");
				$arr_return["AffectedCount"] ++;
				$count ++;
				$links[] = $link;
				if (($arr_return['AffectedCount'] % 100) == 0)
				{
					$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);
					$links = array();
				}
			}
			echo sprintf("program:%s, call api %s...%s result(s) find.\n", $merinfo['IdInAff'], $method, $count);
		}
		if (count($links) > 0)
			$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);
	}

	function GetProgramFromAff()
	{
		$check_date = date("Y-m-d H:i:s");
		echo "Craw Program start @ {$check_date}\r\n";

		$this->getProgramByApi();
		$this->getProgramByPage();

		$this->checkProgramOffline($this->info["AffId"], $check_date);
		echo "Craw Program end @ ".date("Y-m-d H:i:s")."\r\n";
	}
	
	function GetProgramByPage()
	{
		echo "\tGet Program by page start\r\n";
		$objProgram = new ProgramDb();
		$arr_prgm = array();
		$program_num = 0;
		$request = array("AffId" => $this->info["AffId"], "method" => "get", "postdata" => "", );

		// step 1,login
		$this->oLinkFeed->LoginIntoAffService($this->info["AffId"],$this->info);
		// get SupportDeepurl
		print "\n Get SupportDeepurl\n";
		$hasSupportDeepurl = false;
		$SupportDeepurl_arr = array();
		$SupportDeepurl_arr = $this->getSupportDUT();
		if(count($SupportDeepurl_arr) > 100)
			$hasSupportDeepurl = true;

		// Step 1 Get all merchants
		$strUrl = "http://www.pepperjamnetwork.com/affiliate/program/manage?&csv=1";
		$cache_file = $this->oLinkFeed->fileCacheGetFilePath($this->info["AffId"],"merchant_csv_".date("YmdH").".dat", "cache_merchant");
		if(!$this->oLinkFeed->fileCacheIsCached($cache_file))
		{
			$r = $this->oLinkFeed->GetHttpResult($strUrl, $request);
			$result = $r["content"];
			$this->oLinkFeed->fileCachePut($cache_file,$result);
		}
		$str_header = 'Program ID,Program Name,Deep Linking,Product Feed,Email,Phone,Allowed Promotional Methods,Prohibited States,Generic Link,Website URL,Logo,Locking Period,Cookie Duration,Commission,Join Date,Affidavit Required';
		$cache_file = $this->oLinkFeed->fileCacheGetFilePath($this->info["AffId"],"merchant_csv_".date("YmdH").".dat", "cache_merchant");
		if(!$this->oLinkFeed->fileCacheIsCached($cache_file))
		{
			$strUrl = "http://www.pepperjamnetwork.com/affiliate/program/manage?&csv=1";			
			$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
			$result = $r["content"];		
			print "Get Merchant CSV.\n";
			$this->oLinkFeed->fileCachePut($cache_file,$result);
			if(stripos($result,$str_header) === false){
				mydie("die: wrong csv file: $cache_file");
				continue;
			}
		}

		//Open CSV File
		$fhandle = fopen($cache_file, 'r');
		if(!$fhandle)
			mydie("open $cache_file failed.\n");
		while ($line = fgetcsv ($fhandle, 50000, ','))
		{
			//Program ID,Program Name,Deep Linking,Product Feed,Email,Phone,Allowed Promotional Methods,Prohibited States,Generic Link,Website URL,Logo,Locking Period,Cookie Duration,Commission,Join Date,Affidavit Required
			$strMerID = intval($line[0]);
			if ($strMerID < 1)
				continue;
			$strMerName = $line[1];
			$SupportDeepurl = $line[2];
			$tmp_email = $line[4];
			$tmp_phone = $line[5];
			//$tmp_email = $line[6];
			$tmp_prohibited_states = $line[7];
			$AffDefaultUrl = $line[8];
			$Homepage = $line[9];
			//$tmp_logo = $line[10];
			//$tmp_phone = $line[11];
			$ReturnDays = $line[12];
			$CommissionExt_bk = $line[13];
			$JoinDate = $line[14];
			//$tmp_affidavit_required = $line[15];
			$SubAffPolicyExt = "";
			if($tmp_prohibited_states)
				$SubAffPolicyExt = "Prohibited States: ".$tmp_prohibited_states;
			if($JoinDate)
				$JoinDate = date("Y-m-d H:i:s", strtotime($JoinDate));
			//program_detail
			$prgm_url = "http://www.pepperjamnetwork.com/affiliate/program/details?programId=$strMerID";
			$prgm_arr = $this->oLinkFeed->GetHttpResult($prgm_url, $request);
			$prgm_detail = $prgm_arr["content"];
			$TargetCountryExt = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<img src="/images/flags/', ' title="'), '"'));
			$CategoryExt = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, '<strong>Categories:</strong>', '</div>'));
			$Contacts = "Manager: ".trim(strip_tags($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, '<strong>Manager:</strong>', '</div>')));
			$Contacts .= ", Email: ".$tmp_email;
			$Contacts .= ", Phone: ".$tmp_phone;
			$Contacts .= ", Address: ".trim(strip_tags($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<strong>Address:</strong>', '<div>'), '</div>')));
			$SEMPolicyExt = "Suggested Keywords:".trim(strip_tags($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, '<h3>Suggested Keywords:</h3>', '<h3>')));
			$SEMPolicyExt .= ", \nRestricted Keywords:".trim(strip_tags($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, '<h3>Restricted Keywords:</h3>', '</div>')));
			$CommissionExt = trim(strip_tags($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, 'Default Terms', '* Incentives for a monthly period')));
			if(empty($CommissionExt))
				$CommissionExt = $CommissionExt_bk;
			if($hasSupportDeepurl && isset($SupportDeepurl_arr[$strMerID]))
			{
				$SupportDeepurl = $SupportDeepurl_arr[$strMerID]['SupportDeepurl'];
				$AffDefaultUrl = $SupportDeepurl_arr[$strMerID]['AffDefaultUrl'];
			}
			$arr_prgm[$strMerID] = array(
				"Name" => addslashes(html_entity_decode(trim($strMerName))),
				"AffId" => $this->info["AffId"],
				"TargetCountryExt" => addslashes($TargetCountryExt),
				"CategoryExt" => addslashes($CategoryExt),
				"Contacts" => addslashes($Contacts),
				"IdInAff" => $strMerID,
				"CreateDate" => $JoinDate,
				//"StatusInAff" => $StatusInAff,						//'Active','TempOffline','Offline'
				//"StatusInAffRemark" => addslashes($StatusInAffRemark),
				//"Partnership" => $Partnership,						//'NoPartnership','Active','Pending','Declined','Expired','Removed'
				//"Description" => addslashes($desc),
				"Homepage" => addslashes($Homepage),
				"CommissionExt" => addslashes($CommissionExt),
				//"EPC30d" => addslashes(preg_replace("/[^0-9.]/", "", $EPC30d)),
				"CookieTime" => $ReturnDays,
				"SEMPolicyExt" => addslashes($SEMPolicyExt),
				//"TermAndCondition" => addslashes($TermAndCondition),
				"SubAffPolicyExt" => addslashes($SubAffPolicyExt),
				"LastUpdateTime" => date("Y-m-d H:i:s"),
				"DetailPage" => $prgm_url,
				"SupportDeepUrl" => $SupportDeepurl,
				"AffDefaultUrl" => $AffDefaultUrl,
			);
			if(count($arr_prgm) >= 100){
				$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
				$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
				$arr_prgm = array();
			}
			$program_num++;
		}
		if(count($arr_prgm)){
			$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
			$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
			unset($arr_prgm);
		}
		echo "\tGet Program by page end\r\n";
		if($program_num < 10)
			mydie("die: program count < 10, please check program.\n");
		echo "\tUpdate ({$program_num}) program.\r\n";
		echo "\tSet program country int.\r\n";
		$objProgram->setCountryInt($this->info["AffId"]);
	}
	
	function checkProgramOffline($AffId, $check_date){
		$objProgram = new ProgramDb();
		$prgm = array();
		$prgm = $objProgram->getNotUpdateProgram($this->info["AffId"], $check_date);
		
		if(count($prgm) > 30){
			mydie("die: too many offline program (".count($prgm).").\n");
		}else{			
			$objProgram->setProgramOffline($this->info["AffId"], $prgm);
			echo "\tSet (".count($prgm).") offline program.\r\n";
		}
	}
	
	function getSupportDUT()
	{
		$request = array("AffId" => $this->info["AffId"], "method" => "get", "postdata" => "", );
		$str_url = "http://www.pepperjamnetwork.com/affiliate/creative/generic?website=&sid=&deep_link=&encrypted=0&rows_per_page=2000";
		$tmp_arr = $this->oLinkFeed->GetHttpResult($str_url, $request);
		$result = $tmp_arr["content"];
		$SupportDeepurl_arr = array();

		//parse HTML
		$strLineStart = '<td class="creative">';
		$nLineStart = 0;
		while ($nLineStart >= 0){
			$nLineStart = stripos($result, $strLineStart, $nLineStart);
			if ($nLineStart === false) break;
			$AffDefaultUrl = trim(strip_tags($this->oLinkFeed->ParseStringBy2Tag($result, array('tracking-link', 'value="'), '"', $nLineStart)));
			$SupportDeepurl = trim(strip_tags($this->oLinkFeed->ParseStringBy2Tag($result, array('Deep linking', '<span>'), '</span>', $nLineStart)));
			$strMerID = $this->oLinkFeed->ParseStringBy2Tag($result, 'data-id="', '"', $nLineStart);
			$strMerID = intval($strMerID);
			if($SupportDeepurl == "allowed"){
				$SupportDeepurl_arr[$strMerID]["SupportDeepurl"] = "YES";
			}else{
				$SupportDeepurl_arr[$strMerID]["SupportDeepurl"] = "NO";
			}
			$SupportDeepurl_arr[$strMerID]["AffDefaultUrl"] = $AffDefaultUrl;
		}
		// if there is a link named Deep Linking
		// the program is SupportDeepurl YES
		$q = "SELECT `AffMerchantId`,`LinkAffUrl` FROM `affiliate_links_6` WHERE `LinkName`='Deep Linking'";
		echo $q."\n";
		$rows = $this->oLinkFeed->objMysql->getRows($q);
		foreach ($rows as $row)
		{
			$strMerID = $row['AffMerchantId'];
			if (!empty($strMerID) && !empty($row['LinkAffUrl']))
			{
				$SupportDeepurl_arr[$strMerID]["SupportDeepurl"] = "YES";
				$SupportDeepurl_arr[$strMerID]["AffDefaultUrl"] = $row['LinkAffUrl'];
			}
		}
		return $SupportDeepurl_arr;
	}

	function getProgramByApi(){
		echo "\tGet Program by api start\r\n";
		$objProgram = new ProgramDb();
		list($arr_prgm, $program_num, $page, $hasNextPage) = array(array(), 0, 1, true);
		$request = array("AffId" => $this->info["AffId"], "method" => "get", "postdata" => "",);

		while($hasNextPage)
		{
			$apiurl = sprintf("http://api.pepperjamnetwork.com/20120402/publisher/advertiser?apiKey=%s&format=xml&page=%s", API_KEY_6, $page);
			$cache_file = $this->oLinkFeed->fileCacheGetFilePath($this->info["AffId"],"merchant_xml_{$page}_".date("YmdH").".dat", "cache_merchant");
			if(!$this->oLinkFeed->fileCacheIsCached($cache_file))
			{
				$r = $this->oLinkFeed->GetHttpResult($apiurl, $request);
				$result = $r["content"];
				$this->oLinkFeed->fileCachePut($cache_file,$result);
			}

			$xml = new DOMDocument();
			$xml->load($cache_file);
			$page_info = $xml->getElementsByTagName("total_pages");
			$total_pages = $page_info->item(0)->nodeValue;
			if($page >= $total_pages) $hasNextPage = false;
			$page++;

			//parse XML
			$advertiser_list = $xml->getElementsByTagName("data");
			foreach($advertiser_list as $advertiser)
			{
				$advertiser_info = array();
				$childnodes = $advertiser->getElementsByTagName("*");
				foreach($childnodes as $node){
					if(isset($advertiser_info[$node->nodeName]))continue;
					$advertiser_info[$node->nodeName] = trim($node->nodeValue);
				}
				$strMerID = $advertiser_info['id'];
				$strMerName = $advertiser_info['name'];
				$desc = $advertiser_info['description'];
				$TermAndCondition = trim(strip_tags($this->oLinkFeed->ParseStringBy2Tag($desc, 'Terms & Conditions:', '</div>')));
				$desc = trim(strip_tags($desc));
				//$Homepage = $advertiser_info['website'];
				//$advertiser_info['prohibited_states'];
				//$advertiser_info['mobile_tracking'];
				$StatusInAffRemark = $advertiser_info['status'];
				//joined, revoked_advertiser, applied, declined_advertiser, invited, revoked_publisher, declined_publisher, no_relationship
				if($StatusInAffRemark == "joined"){
					$Partnership = "Active";
				}elseif($StatusInAffRemark == "revoked_advertiser"){
					$Partnership = "Expired";
				}elseif($StatusInAffRemark == "applied"){
					$Partnership = "Pending";
				}elseif($StatusInAffRemark == "declined_advertiser"){
					$Partnership = "Declined";
				}elseif($StatusInAffRemark == "invited"){
					$Partnership = "Pending";
				}elseif($StatusInAffRemark == "revoked_publisher"){
					$Partnership = "Removed";
				}elseif($StatusInAffRemark == "declined_publisher"){
					$Partnership = "Removed";
				}else{
					$Partnership = "NoPartnership";
				}
				//$CookieTime = $advertiser_info['cookie_duration'];
				//$advertiser_info['currency']; $advertiser_info['percentage_payout']; $advertiser_info['flat_payout'];
				//$JoinDate = $advertiser_info['join_date'];
				//$JoinDate = date("Y-m-d H:i:s", strtotime($JoinDate));
				//$Contacts = $advertiser_info['contact_name'] . ", Phone: " . $advertiser_info['phone'] . ", Email: " . $advertiser_info['email'];
				$arr_prgm[$strMerID] = array(
					"Name" => addslashes(html_entity_decode(trim($strMerName))),
					"AffId" => $this->info["AffId"],
					"IdInAff" => $strMerID,
					"StatusInAff" => "Active",						//'Active','TempOffline','Offline'
					"StatusInAffRemark" => addslashes($StatusInAffRemark),
					"Partnership" => $Partnership,						//'NoPartnership','Active','Pending','Declined','Expired','Removed'
					"Description" => addslashes($desc),
					"TermAndCondition" => addslashes($TermAndCondition),
					"LastUpdateTime" => date("Y-m-d H:i:s"),
					"MobileFriendly" => 'UNKNOWN'
				);
				if ($advertiser_info['mobile_tracking'] == 'Enabled')
					$advertiser_info['mobile_tracking'] = 'YES';
				$program_num++;
				if(count($arr_prgm) >= 100){
					$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
					$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
					$arr_prgm = array();
				}
			}
		}
		if(count($arr_prgm)){
			$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
			$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
			unset($arr_prgm);
		}
		echo "\tGet Program by api end\r\n";
		if($program_num < 10)
			mydie("die: program count < 10, please check program.\n");
		echo "\tUpdate ({$program_num}) program.\r\n";
	}
}

