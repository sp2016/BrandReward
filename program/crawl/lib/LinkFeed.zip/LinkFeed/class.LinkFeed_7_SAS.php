<?php

require_once 'text_parse_helper.php';
define('AFFID_INAFF_7', '252822');
define('API_TOKEN_7', 'tVfx3axFRbASsHZG');
define('API_SECRET_KEY_7', 'DHz6wv4t6BWxyu2nOJh4sy6z9EIvcc7r');
define('API_VERSION_7', 1.8);

class LinkFeed_7_SAS
{
	function __construct($aff_id,$oLinkFeed)
	{
		$this->oLinkFeed = $oLinkFeed;
		$this->info = $oLinkFeed->getAffById($aff_id);
		$this->debug = isset($oLinkFeed->debug) ? $oLinkFeed->debug : false;
		
		$this->file = "programlog_{$aff_id}_".date("Ymd_His").".csv";
	}

	function getCouponFeed()
	{
		$arr_return = array("AffectedCount" => 0, "UpdatedCount" => 0, "Detail" => array(), );
		$request = array("AffId" => $this->info["AffId"], "method" => "get", "postdata" => "", );

		//coupons
		$actionVerb = "couponDeals";
		$t = gmdate(DATE_RFC1123);
		$sigHash = hash("sha256", sprintf('%s:%s:%s:%s', API_TOKEN_7, $t, $actionVerb, API_SECRET_KEY_7));
		$request['addheader'] = array("x-ShareASale-Date: $t", "x-ShareASale-Authentication: $sigHash");
		$url = sprintf("https://shareasale.com/x.cfm?action=%s&affiliateId=%s&token=%s&version=%s", $actionVerb, AFFID_INAFF_7, API_TOKEN_7, API_VERSION_7);
		$r = $this->oLinkFeed->GetHttpResult($url, $request);
		$content = trim($r['content']);
		$data = @csv_string_to_array($content, '|', "\r\n");
		if (empty($data) || !is_array($data))
			return $arr_return;
		$links = array();
		foreach ($data as $v)
		{
			$link = array(
					"AffId" => $this->info["AffId"],
					"AffMerchantId" => $v['Merchant Id'],
					"AffLinkId" => $v['Deal Id'],
					"LinkName" => html_entity_decode($v['Title']),
					"LinkDesc" => html_entity_decode(sprintf('%s', $v['Description'])),
					"LinkStartDate" => '0000-00-00 00:00:00',
					"LinkEndDate" => '0000-00-00 00:00:00',
					"LinkPromoType" => 'COUPON',
					"LinkHtmlCode" => '',
					"LinkCode" => $v['Coupon Code'],
					"LinkOriginalUrl" => '',
					"LinkImageUrl" => $v['BigImage'],
					"LinkAffUrl" => $v['Tracking URL'],
					"DataSource" => 39,
				);
			if (!empty($v['Start Date']))
			{
				$date = strtotime($v['Start Date']);
				if ($date > 946713600)
					$link['LinkStartDate'] = date('Y-m-d h:i:s', $date);
			}
			if (!empty($v['End Date']))
			{
				$date = strtotime($v['End Date']);
				if ($date > 946713600)
					$link['LinkEndDate'] = date('Y-m-d h:i:s', $date);
			}
			if (!empty($v['Restrictions']))
				$link['LinkDesc'] .= ', |Restrictions:' . html_entity_decode($v['Restrictions']);
			if (empty($link['LinkCode']))
			{
				$code = get_linkcode_by_text($link['LinkName'] .'|'. $link['LinkDesc']);
				if (!empty($code))
					$link['LinkCode'] = $code;
			}
			$link['LinkHtmlCode'] = create_link_htmlcode_image($link);
			if (empty($link['AffLinkId']) || empty($link['LinkAffUrl']) || empty($link['LinkName']))
				continue;
			$this->oLinkFeed->fixEnocding($this->info, $link, "feed");
			$arr_return["AffectedCount"] ++;
			$links[] = $link;
			if (($arr_return["AffectedCount"] % 100) == 0)
			{
				$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);
				$links = array();
			}
		}
		echo sprintf("get coupons complete. %s links(s) found. \n", $arr_return["AffectedCount"]);
		if(count($links) > 0)
			$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);

		//text links and banners by modifiedDate
		$actionVerb = "merchantCreative";
		$t = gmdate(DATE_RFC1123);
		$sigHash = hash("sha256", sprintf('%s:%s:%s:%s', API_TOKEN_7, $t, $actionVerb, API_SECRET_KEY_7));
		$request['addheader'] = array("x-ShareASale-Date: $t", "x-ShareASale-Authentication: $sigHash");
		$modifiedDate = urlencode(date('m/d/Y', time() - 2592000));
		$url = sprintf("https://shareasale.com/x.cfm?action=%s&affiliateId=%s&token=%s&modifiedDate=%s&version=%s", $actionVerb, AFFID_INAFF_7, API_TOKEN_7, $modifiedDate, API_VERSION_7);
		$r = $this->oLinkFeed->GetHttpResult($url, $request);
		$content = trim($r['content']);
		$data = @csv_string_to_array($content, '|', "\r\n");
		if (empty($data) || !is_array($data))
			return $arr_return;
		$links = array();
		foreach ($data as $v)
		{
			$link = array(
					"AffId" => $this->info["AffId"],
					"AffMerchantId" => $v['Merchant ID'],
					"AffLinkId" => $v['Banner Id'],
					"LinkName" => html_entity_decode($v['Name']),
					"LinkDesc" => html_entity_decode(sprintf('%s', $v['Text'])),
					"LinkStartDate" => '0000-00-00 00:00:00',
					"LinkEndDate" => '0000-00-00 00:00:00',
					"LinkPromoType" => 'DEAL',
					"LinkHtmlCode" => '',
					"LinkCode" => '',
					"LinkOriginalUrl" => '',
					"LinkImageUrl" => $v['Image Url'],
					"LinkAffUrl" => $v['Click Url'],
					"DataSource" => 39,
			);
			if (!empty($v['Modified Date']))
			{
				$date = strtotime($v['Modified Date']);
				if ($date > 946713600)
					$link['LinkStartDate'] = date('Y-m-d h:i:s', $date);
			}
			if (!empty($v['Alt Text']) && ($v['Alt Text'] != $v['Text']))
			{
				if (empty($link['LinkDesc']))
					$link['LinkDesc'] .= html_entity_decode($v['Alt Text']);
				else
					$link['LinkDesc'] .= '. ' . html_entity_decode($v['Alt Text']);
			}
			$code = get_linkcode_by_text($link['LinkName'] .'|'. $link['LinkDesc']);
			if (!empty($code))
			{
				$link['LinkCode'] = $code;
				$link['LinkPromoType'] = 'COUPON';
			}
			else
				$link['LinkPromoType'] = $this->oLinkFeed->getPromoTypeByLinkContent($link['LinkName'] . $link['LinkDesc']);
			$link['LinkHtmlCode'] = create_link_htmlcode_image($link);
			if (empty($link['AffLinkId']) || empty($link['LinkAffUrl']) || empty($link['LinkName']))
				continue;
			$this->oLinkFeed->fixEnocding($this->info, $link, "feed");
			$arr_return["AffectedCount"] ++;
			$links[] = $link;
			if (($arr_return["AffectedCount"] % 100) == 0)
			{
				$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);
				$links = array();
			}
		}
		echo sprintf("get text & banner links complete, %s links(s) found. \n", $arr_return["AffectedCount"]);
		if(count($links) > 0)
			$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);
		return $arr_return;
	}

	function GetAllLinksFromAffByMerID($merinfo)
	{
		$arr_return = array("AffectedCount" => 0, "UpdatedCount" => 0, "Detail" => array(), );
		$request = array("AffId" => $this->info["AffId"], "method" => "get", "postdata" => "", );
		// Get the text and banner links by modifiedDate from the getCouponFeed function.
		// Get the text and banner links by merchantId from the this function.
		// Note: API report requests are limited to 1000 per month.
		$actionVerb = "merchantCreative";
		$t = gmdate(DATE_RFC1123);
		$sigHash = hash("sha256", sprintf('%s:%s:%s:%s', API_TOKEN_7, $t, $actionVerb, API_SECRET_KEY_7));
		$request['addheader'] = array("x-ShareASale-Date: $t", "x-ShareASale-Authentication: $sigHash");
		$url = sprintf("https://shareasale.com/x.cfm?action=%s&affiliateId=%s&token=%s&merchantId=%s&version=%s", $actionVerb, AFFID_INAFF_7, API_TOKEN_7, $merinfo['IdInAff'], API_VERSION_7);
		$r = $this->oLinkFeed->GetHttpResult($url, $request);
		$content = trim($r['content']);
		$data = @csv_string_to_array($content, '|', "\r\n");
		if (empty($data) || !is_array($data))
			return $arr_return;
		$links = array();
		foreach ($data as $v)
		{
			$link = array(
					"AffId" => $this->info["AffId"],
					"AffMerchantId" => $merinfo['IdInAff'],
					"AffLinkId" => $v['Banner Id'],
					"LinkName" => html_entity_decode($v['Name']),
					"LinkDesc" => html_entity_decode(sprintf('%s', $v['Text'])),
					"LinkStartDate" => '0000-00-00 00:00:00',
					"LinkEndDate" => '0000-00-00 00:00:00',
					"LinkPromoType" => 'DEAL',
					"LinkHtmlCode" => '',
					"LinkCode" => '',
					"LinkOriginalUrl" => '',
					"LinkImageUrl" => $v['Image Url'],
					"LinkAffUrl" => $v['Click Url'],
					"DataSource" => 39,
				);
			if (!empty($v['Modified Date']))
			{
				$date = strtotime($v['Modified Date']);
				if ($date > 946713600)
					$link['LinkStartDate'] = date('Y-m-d h:i:s', $date);
			}
			if (!empty($v['Alt Text']) && ($v['Alt Text'] != $v['Text']))
			{
				if (empty($link['LinkDesc']))
					$link['LinkDesc'] .= html_entity_decode($v['Alt Text']);
				else
					$link['LinkDesc'] .= '. ' . html_entity_decode($v['Alt Text']);
			}
			$code = get_linkcode_by_text($link['LinkName'] .'|'. $link['LinkDesc']);
			if (!empty($code))
			{
				$link['LinkCode'] = $code;
				$link['LinkPromoType'] = 'COUPON';
			}
			else
				$link['LinkPromoType'] = $this->oLinkFeed->getPromoTypeByLinkContent($link['LinkName'] . $link['LinkDesc']);
			$link['LinkHtmlCode'] = create_link_htmlcode_image($link);
			if (empty($link['AffLinkId']) || empty($link['LinkAffUrl']) || empty($link['LinkName']))
				continue;
			$this->oLinkFeed->fixEnocding($this->info, $link, "feed");
			$arr_return["AffectedCount"] ++;
			$links[] = $link;
			if (($arr_return["AffectedCount"] % 100) == 0)
			{
				$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);
				$links = array();
			}
		}
		echo sprintf("program: %s, %s links(s) found. \n", $merinfo['IdInAff'], $arr_return["AffectedCount"]);
		if(count($links) > 0)
			$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);
		// the AffectedCount is not a regular value so the AffectedCount is set to 0.
		// $arr_return['AffectedCount'] = 0;
		return $arr_return;
	}
	
	function getInvalidLinks()
	{
		$arr_return = array("AffectedCount" => 0, "UpdatedCount" => 0, "Detail" => array(), );
		$request = array("AffId" => $this->info["AffId"], "method" => "get", "postdata" => "", );
		$actionVerb = "invalidLinks";
		$t = gmdate(DATE_RFC1123);
		$sigHash = hash("sha256", sprintf('%s:%s:%s:%s', API_TOKEN_7, $t, $actionVerb, API_SECRET_KEY_7));
		$request['addheader'] = array("x-ShareASale-Date: $t", "x-ShareASale-Authentication: $sigHash");
		$url = sprintf("https://shareasale.com/x.cfm?action=%s&affiliateId=%s&token=%s&version=%s", $actionVerb, AFFID_INAFF_7, API_TOKEN_7, API_VERSION_7);
		$r = $this->oLinkFeed->GetHttpResult($url, $request);
		$content = trim($r['content']);
		$data = @csv_string_to_array($content, '|', "\r\n");
		if (empty($data) || !is_array($data) || count($data) < 1)
			return;
		$links = array();
		foreach ($data as $v)
		{
			if (empty($v['Banner ID']))
				continue;
			$link = array(
					'affiliate' => $this->info["AffId"],
					'LinkID' => trim($v['Banner ID']),
					'ReferralUrl' => trim($v['Referrer']),
					'ProgramID' => trim($v['Merchant ID']),
					'Reason' => trim($v['Reason']),
					'OccuredDate' => parse_time_str($v['Date']),
			);
			$links[] = $link;
		}
		return $links;
	}

	function GetProgramByPage()
	{
		$request = array(
			"AffId" => $this->info["AffId"],
			"method" => "post",
			"postdata" => "", 
		);
		
		//step 1,login
		$this->oLinkFeed->LoginIntoAffService($this->info["AffId"],$this->info);

		//step 2,get all exists merchant
		//$arrAllExistsMerchants = $this->oLinkFeed->GetAllExistsAffMerIDForCheckByAffID($this->info["AffId"]);

		//Step 3, Get all merchants
		list($nNumPerPage, $bHasNextPage, $nPageNo, $start, $max_start, $Cnt, $UpdateCnt) = array(50, true, 1, 1, 2, 0, 0);

		$objProgram = new ProgramDb();
		$arr_prgm = array();

		while($bHasNextPage && $max_start >= $start)
		{
			$start = ($nPageNo - 1) * $nNumPerPage + 1;
			$temp = time() . rand(1000,9999);

			$strUrl = "https://www.shareasale.com/a-ajaxsearch.cfm?searchType=basicKeyword&keyword=&start=" . $start .  "&order=&resultFilter=&cookielength=Any&epc=&avgsale=&reversalrate=&ascordesc=DESC&lstExclude=&temp=" . $temp;

			$request["method"] = "get";
			$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
			$result = $r["content"];

			print "<br>\n Get Merchant List : Page: $nPageNo <br>\n";
			//parse HTML
			$strLineStart = '<td class="col1"';
			$nLineStart = 0;
			$bStart = true;
			while ($nLineStart >= 0)
			{
				if($this->debug) print "Process $Cnt  ";

				$nLineStart = stripos($result, $strLineStart, $nLineStart);
				if ($nLineStart === false)
				{
					echo "strLineStart: $strLineStart not found, break\n";
					if ($bStart == true){
						$bHasNextPage = false;
					}
					break;
				}
				$bStart = false;
				// ID 	Name 	EPC 	Status
				$strEPC = 0;

				//ID <a href="/a-viewmerchant.cfm?merchantID=29560" target="_blank">GoPhoto</a>
				$strMerID = $this->oLinkFeed->ParseStringBy2Tag($result,'"/a-viewmerchant.cfm?merchantID=','"',$nLineStart);
				if($strMerID === false)
				{
					echo "strMerID not found, break\n";
					break;
				}
				$strMerID = trim($strMerID);
				if(!$strMerID) continue;

				//name
				$strMerName = $this->oLinkFeed->ParseStringBy2Tag($result,">","<",$nLineStart);
				if($strMerName === false)
				{
					echo "strMerName not found, continue\n";
					continue;
				}
				$strMerName = html_entity_decode(trim($strMerName));
				if($this->debug) echo "strMerName: $strMerName\n";
				if(!$strMerName) continue;
				
				//Homepage
				$Homepage = $this->oLinkFeed->ParseStringBy2Tag($result, array('<div style="margin-bottom:3px;text-align:left;">', '<a href="'), '"', $nLineStart);
				//CategoryExt
				$CategoryExt = "";
				$homepage_link = str_replace(array("http://", "https://"),"",$Homepage);
				$category = trim(strip_tags($this->oLinkFeed->ParseStringBy2Tag($result, "{$homepage_link}</a></div>", 'ID:', $nLineStart)));
				if($category){
					$CategoryExt = $category;
				}
				//JoinDate
				$JoinDate = trim($this->oLinkFeed->ParseStringBy2Tag($result, '<b>Active on:</b>', '</div>', $nLineStart));
				if($JoinDate){
					$JoinDate = date("Y-m-d H:i:s", strtotime($JoinDate));
				}
				
				$strStatus = $this->oLinkFeed->ParseStringBy2Tag($result, array('margin-top:6px;margin-left:20px;','[ '),' ]', $nLineStart);
				$strStatus = trim(strip_tags($strStatus));
				if($this->debug) echo "strStatus: $strStatus\n";//'Active','TempOffline','Expired'

				if($strStatus == 'ENROLLED IN PROGRAM'){
					$StatusInAff = 'Active';
					$Partnership = "Active";
				}
				elseif($strStatus == 'Pending'){
					$StatusInAff = 'Active';
					$Partnership = "Pending";
				}
				elseif($strStatus == 'Declined'){
					$StatusInAff = 'Active';
					$Partnership = "Declined";
				}
				elseif($strStatus == 'JOIN PROGRAM'){
					$StatusInAff = 'Active';
					$Partnership = "NoPartnership";
				}
				else{
					mydie("strStatus is wrong: $strStatus\n");
				}
				
				//commission
				$CommissionExt = trim(strip_tags($this->oLinkFeed->ParseStringBy2Tag($result, '<td class="col2" valign="top" align="center" width="90">', '</td>', $nLineStart)));
				//ReturnDays
				$ReturnDays = trim($this->oLinkFeed->ParseStringBy2Tag($result, '<div class="quickTip" helpkey="TG">', '</div>', $nLineStart));
				//EPCDefault 7d
				$EPCDefault = trim($this->oLinkFeed->ParseStringBy2Tag($result, array('7 Day</td>', '<td>'), '</td>', $nLineStart));
				//EPC30d
				$EPC30d = trim($this->oLinkFeed->ParseStringBy2Tag($result, array('30 Day</td>', '<td>'), '</td>', $nLineStart));
				
				//program
				//program_detail
				$prgm_url = "https://www.shareasale.com/a-viewmerchant.cfm?merchantID=$strMerID";
				$prgm_arr = $this->oLinkFeed->GetHttpResult($prgm_url, $request);
				$prgm_detail = $prgm_arr["content"];
				
				$country = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('/flags/', 'alt="'), '"'));
				$desc = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<strong>Merchant provided description:</strong>', '<div class="sbar mertxt">'), '</div>'));
				$TermAndCondition = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<strong>Merchant provided <i>Terms of Agreement</i>:</strong>', '<div class="sbar mertxt">'), '</div>'));
				$program_status = trim(strip_tags($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, 'Program Status:', '<br>')));
				if(strpos($program_status,"Closed") !== false){
					$StatusInAff = "Offline";
				}
				if(empty($CategoryExt)){
					$CategoryExt = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<table cellspacing="0" class="sbar mpStats">', $strMerName, 'target="_blank"', '<br/>'), '<br/>'));
				}
				
				//$StatusInAff = trim(strip_tags(($this->oLinkFeed->ParseStringBy2Tag($result, 'Program Status:', '<br>', $nLineStart))));
				/*if(strpos($prgm_detail, "a-joinprogram.cfm")){
					$Partnership = "Active";
				}*/

				$SEMPolicyExt = "";
				$sem_url = "https://www.shareasale.com/a-viewPPCkeywords.cfm?merchantID=$strMerID";
				$sem_arr = $this->oLinkFeed->GetHttpResult($sem_url, $request);
				$sem_detail = $sem_arr["content"];
				$sem_Start = 0;

				$sem_tmp = trim($this->oLinkFeed->ParseStringBy2Tag($sem_detail, '<table width=75% align=center class=sbar cellpadding=8>', '</table>', $sem_Start));
				$sem_arr_tmp = explode("<tr>", $sem_tmp);
				if(count($sem_arr_tmp) > 2){
					$SEMPolicyExt = "<table>".$sem_tmp."</table>";
					$SEMPolicyExt = str_replace(array("<br>","<br/>"),"",$SEMPolicyExt);
				}

				$sem_tmp = trim($this->oLinkFeed->ParseStringBy2Tag($sem_detail, '<table width=75% align=center class=sbar cellpadding=8>', '</table>', $sem_Start));
				if($sem_tmp){
					$SEMPolicyExt .= "<table>".$sem_tmp."</table>";
				}

				$BonusExt = "";
				$bonus_url = "https://www.shareasale.com/a-viewbonuscampaign.cfm?merchantID=$strMerID";
				$bonus_arr = $this->oLinkFeed->GetHttpResult($bonus_url, $request);
				$bonus_detail = $bonus_arr["content"];
				$bonus_tmp = trim($this->oLinkFeed->ParseStringBy2Tag($bonus_detail, '<table align=center class=sbar width="95%" border="0" cellspacing="0" cellpadding="5">', '</table>'));
				$bonus_arr_tmp = explode("<tr>", $bonus_tmp);
				if(count($bonus_arr_tmp) > 3){
					$BonusExt = "<table>".$bonus_tmp."</table>";
					$BonusExt = str_replace(array("<br>","<br/>"),"",$BonusExt);
				}

				$arr_prgm[$strMerID] = array(
					"Name" => addslashes(html_entity_decode(trim($strMerName))),
					"AffId" => $this->info["AffId"],
					"CategoryExt" => addslashes($CategoryExt),
					"IdInAff" => addslashes($strMerID),
					"JoinDate" => $JoinDate,
					"StatusInAff" => $StatusInAff,						//'Active','TempOffline','Offline'
					"StatusInAffRemark" => addslashes($strStatus),
					"Partnership" => $Partnership,						//'NoPartnership','Active','Pending','Declined','Expired','Removed'
					"Description" => addslashes($desc),
					"Homepage" => addslashes($Homepage),
					"CommissionExt" => addslashes($CommissionExt),
					"EPCDefault" => addslashes(preg_replace("/[^0-9.]/", "", $EPCDefault)),
					"EPC30d" => addslashes(preg_replace("/[^0-9.]/", "", $EPC30d)),
					"CookieTime" => addslashes($ReturnDays),
					"TermAndCondition" => addslashes($TermAndCondition),
					"TargetCountryExt" => addslashes($country),
					"SEMPolicyExt" => addslashes($SEMPolicyExt),
					"BonusExt" => addslashes($BonusExt),
					"LastUpdateTime" => date("Y-m-d H:i:s"),
					"DetailPage" => $prgm_url,
				);
				//print_r($arr_prgm);
				//exit;
				if(count($arr_prgm) >= 200){
					$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
					$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
					$arr_prgm = array();
				}
				$Cnt++;
			}

			if(count($arr_prgm)){
				$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
				$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
				unset($arr_prgm);
			}

			if($nPageNo == 1 && preg_match("/\\[([0-9]*[01]) - ([0-9]+)\\]/",$result,$matches))
			{
				//try to fix pagesize [1 - 50]
				$new_pagesize = $matches[2] - $matches[1] + 1;
				if($new_pagesize >= 50 && $new_pagesize <= 500)
				{
					$nNumPerPage = $new_pagesize;
				}
				//try to find max page
				preg_match_all("/\\[([0-9]*[01]) - ([0-9]+)\\]/",$result,$matches,PREG_SET_ORDER);
				foreach($matches as $set => $set_matches)
				{
					if($set_matches[1] > $max_start) $max_start = $set_matches[1];
				}
			}
			$nPageNo++;
		}//per page	
		
		$objProgram->setProgramOffline($this->info["AffId"]);
		$objProgram->setCountryInt($this->info["AffId"]);
	}

	function GetProgramFromAff()
	{
		$check_date = date("Y-m-d H:i:s");
		echo "Craw Program start @ {$check_date}\r\n";

		$this->GetProgramByApi();
		$this->checkProgramOffline($this->info["AffId"], $check_date);

		echo "Craw Program end @ ".date("Y-m-d H:i:s")."\r\n";
	}
	
	function GetProgramByApi(){
		echo "\tGet Program by api start\r\n";
		$objProgram = new ProgramDb();
		$arr_prgm = array();
		$program_num = 0;
		$arr_prgm_name = array();

		$myAffiliateID = '252822';
		$APIToken = "tVfx3axFRbASsHZG";
		$APISecretKey = "DHz6wv4t6BWxyu2nOJh4sy6z9EIvcc7r";
		$myTimeStamp = gmdate(DATE_RFC1123);

		$APIVersion = 1.2;
		$actionVerb = "merchantStatus";
		$sig = $APIToken.':'.$myTimeStamp.':'.$actionVerb.':'.$APISecretKey;
		$sigHash = hash("sha256",$sig);
		$myHeaders = array("x-ShareASale-Date: $myTimeStamp","x-ShareASale-Authentication: $sigHash");

		$ch = curl_init();
		$url = "https://shareasale.com/x.cfm?action=$actionVerb&affiliateId=$myAffiliateID&token=$APIToken&version=$APIVersion";
		//Merchant Id, Merchant, WWW, Program Status, Program Category, Sale Comm, Lead Comm, Hit Comm, Approved, Link Url
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_HTTPHEADER,$myHeaders);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		$returnResult = curl_exec($ch);

		if ($returnResult) {
			echo "\tProcessing Data.\r\n";
			//parse HTTP Body to determine result of request
			if (stripos($returnResult,"Error Code ")) {
				// error occurred
				trigger_error($returnResult,E_USER_ERROR);
			}
			else{
				// success
				//echo $returnResult;
				$arr_feed = array();
				$arr_feed = explode("\n",$returnResult);
				//print_r($arr_feed);exit;
				//echo count($arr_feed);
				$line_number = 0;
				$cnt = 0;
				$line_one = "Merchant Id|Merchant|WWW|Program Status|Program Category|Sale Comm|Lead Comm|Hit Comm|Approved|Link Url";
				$arrToUpdate = array();
				foreach($arr_feed as $line){
					$line_number++;
					if($line_number == 1){
						if(trim($line) != $line_one){
							echo "$line","\n";
							mydie("die: wrong API format: at line $line\n");
						}
						continue;
					}

					$row = array();
					$row = explode("|",$line);

					if(!count($row) || !isset($row[0])){
						//print_r($row);
						continue;
					}
					$name = isset($row[1]) ? trim($row[1]) : "";
					//print_r($row);exit;
					//if(trim($row[1]) != "") continue;
					$StatusInAffRemark = "";
					$StatusInAff = "Offline";
					if(isset($row[3])){
						$StatusInAffRemark = $row[3];
						if($row[3] == "Closed"){
							$StatusInAff = "Offline";
						}elseif($row[3] == "LowFunds"){
							$StatusInAff = "Active";
						}elseif($row[3] == "Online"){
							$StatusInAff = "Active";
						}elseif($row[3] == "TemporarilyOffline"){
							$StatusInAff = "TempOffline";
						}else{
							$StatusInAff = "Offline";
						}
					}

					$Partnership = "NoPartnership";
					if(isset($row[8])){
						if($row[8] == "Yes"){
							$Partnership = "Active";
						}elseif($row[8] == "Pending"){
							$Partnership = "Pending";
						}elseif($row[8] == "Declined"){
							$Partnership = "Declined";
						}else{
							$Partnership = "NoPartnership";
						}
					}

					$AffDefaultUrl = isset($row[9]) ? trim($row[9]) : "";
					$strMerID = $row[0];
					$Homepage = isset($row[2]) ? trim($row[2]) : "";
					$CommissionExt = isset($row[5]) ? trim($row[5]) : "";

					if(trim($name)){
						$arr_prgm_name[$strMerID] = array(
							"AffId" => $this->info["AffId"],
							"Name" => addslashes($name),
							"Homepage" => addslashes($Homepage),
							"CategoryExt" => isset($row[4]) ? addslashes($row[4]) : "",
							"CommissionExt" => addslashes($CommissionExt),
							"IdInAff" => addslashes($strMerID),
							"StatusInAff" => $StatusInAff,						//'Active','TempOffline','Offline'
							"StatusInAffRemark" => addslashes($StatusInAffRemark),
							"Partnership" => $Partnership,						//'NoPartnership','Active','Pending','Declined','Expired','Removed'
							"LastUpdateTime" => date("Y-m-d H:i:s"),
							"AffDefaultUrl" => addslashes($AffDefaultUrl)
						);
					}else{
						$arr_prgm[$strMerID] = array(
							"AffId" => $this->info["AffId"],
							"Homepage" => addslashes($Homepage),
							"CategoryExt" => isset($row[4]) ? addslashes($row[4]) : "",
							"CommissionExt" => addslashes($CommissionExt),
							"IdInAff" => addslashes($strMerID),
							"StatusInAff" => $StatusInAff,						//'Active','TempOffline','Offline'
							"StatusInAffRemark" => isset($row[3]) ? addslashes($row[3]) : "",
							"Partnership" => $Partnership,						//'NoPartnership','Active','Pending','Declined','Expired','Removed'
							"LastUpdateTime" => date("Y-m-d H:i:s"),
							"AffDefaultUrl" => addslashes($AffDefaultUrl)
						);
					}
					$program_num++;

					if(count($arr_prgm) >= 100){
						$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
						$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
						echo "saving...\n";
						$arr_prgm = array();
					}
					if(count($arr_prgm_name) >= 100){
						$objProgram->updateProgram($this->info["AffId"], $arr_prgm_name);
						$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm_name);
						echo "saving...\n";
						$arr_prgm_name = array();
					}
				}
				if(count($arr_prgm)){
					$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
					$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
					unset($arr_prgm);
				}
				if(count($arr_prgm_name)){
					$objProgram->updateProgram($this->info["AffId"], $arr_prgm_name);
					$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm_name);
					unset($arr_prgm_name);
				}
			}
		}
		else{
			// connection error
			trigger_error(curl_error($ch),E_USER_ERROR);
			mydie("die: get info by Api failed.\n");
		}

		curl_close($ch);
		echo "\tGet Program by api end\r\n";

		if($program_num < 10){
			mydie("die: program count < 10, please check program.\n");
		}
		echo "\tUpdate ({$program_num}) program.\r\n";
		echo "\tSet program country int.\r\n";
		$objProgram->setCountryInt($this->info["AffId"]);
	}

	function checkProgramOffline($AffId, $check_date){
		$objProgram = new ProgramDb();
		$prgm = array();
		$prgm = $objProgram->getNotUpdateProgram($this->info["AffId"], $check_date);

		if(count($prgm) > 30){
			mydie("die: too many offline program (".count($prgm).").\n");
		}else{
			$objProgram->setProgramOffline($this->info["AffId"], $prgm);
			echo "\tSet (".count($prgm).") offline program.\r\n";
		}
	}
}

