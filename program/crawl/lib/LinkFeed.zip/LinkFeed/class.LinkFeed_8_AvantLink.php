<?php

require_once 'text_parse_helper.php';
define('AFFID_INAFF_8', '4724');

class LinkFeed_8_AvantLink
{
	function __construct($aff_id,$oLinkFeed)
	{
		$this->oLinkFeed = $oLinkFeed;
		$this->info = $oLinkFeed->getAffById($aff_id);
		$this->debug = isset($oLinkFeed->debug) ? $oLinkFeed->debug : false;
		
		$this->file = "programlog_{$aff_id}_".date("Ymd_His").".csv";
	}
	
	function Login(){
		$islogined = false;
		$this->oLinkFeed->clearHttpInfos($this->info["AffId"]);
		$strUrl = "https://www.avantlink.com/signin";
		$request = array(
			"AffId" => $this->info["AffId"],
			"method" => "get",
			"postdata" => "",
		);
		$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
		$result = $r["content"];
		$_token = urlencode($this->oLinkFeed->ParseStringBy2Tag($result, array('name="_token"', 'value="'), '"'));		

		$this->info["AffLoginPostString"] .= "&_token=".$_token;
		//echo $this->info["AffLoginPostString"];		
		
		$request = array(
			"AffId" => $this->info["AffId"],
			"method" => $this->info["AffLoginMethod"],
			"postdata" => $this->info["AffLoginPostString"]			
		);
		$r = $this->oLinkFeed->GetHttpResult($this->info["AffLoginUrl"], $request);		
		if($r["code"] == 200){
			if(stripos($r["content"], $this->info["AffLoginVerifyString"]) !== false)
			{
				echo "verify succ: " . $this->info["AffLoginVerifyString"] . "\n";
				$islogined = true;
			}else{
				echo "verify login failed(".$this->info["AffLoginVerifyString"].") <br>\n";
			}
		}
		
		if(!$islogined){
			mydie("die: login failed for aff({$this->info["AffId"]}) <br>\n");
		}else{
			$_md5 = urlencode($this->oLinkFeed->ParseStringBy2Tag($r["content"], 'href="/signin/account/3894/', '"'));
			$this->info["AffLoginSuccUrl"] .= $_md5;
			$request = array("AffId" => $this->info["AffId"], "method" => "get");
			$r = $this->oLinkFeed->GetHttpResult($this->info["AffLoginSuccUrl"], $request);			
		}
	}

	function getCouponFeed()
	{
		$arr_return = array("AffectedCount" => 0, "UpdatedCount" => 0, "Detail" => array(), );
		$request = array("AffId" => $this->info["AffId"], "method" => "get", "postdata" => "", );
		$url = "http://www.avantlink.com/coupons/coupon_feed.php?cfi=4257&pw=4724";
		$r = $this->oLinkFeed->GetHttpResult($url, $request);
		$content = $r["content"];
		$data = @fgetcsv_str($content);
		$links = array();
		foreach ((array)$data as $v)
		{
			if (empty($v['Coupon Link']))
				continue;
			$link = array(
					"AffId" => $this->info["AffId"],
					"LinkName" =>  $v['Coupon Offer'],
					"LinkDesc" =>  '',
					"LinkStartDate" => parse_time_str($v['Coupon Start'], null, false),
					"LinkEndDate" => parse_time_str($v['Coupon Expiration'], null, true),
					"LinkPromoType" => 'COUPON',
					"LinkHtmlCode" => '',
					"LinkCode" => $v['Coupon Code'],
					"LinkOriginalUrl" => '',
					"LinkImageUrl" => '',
					"LinkAffUrl" => $v['Coupon Link'],
					"DataSource" => 11,
			);
			if (preg_match('@\&mi=(\d+)&mli=(\d+)@', $link['LinkAffUrl'], $g))
			{
				$link['AffMerchantId'] = $g[1];
				$link['AffLinkId'] = 'c_' . $g[2];
			}
			if (empty($link['LinkCode']))
			{
				$code = get_linkcode_by_text($link['LinkName']);
				if (!empty($code))
					$link['LinkCode'] = $code;
			}
			if ($v["Coupon Type"] == 'image')
			{
				if (preg_match('@^http:@', $v['Coupon Offer']))
					$link['LinkImageUrl'] = $v['Coupon Offer'];
				if (!empty($link['LinkCode']))
					$link['LinkName'] = sprintf('%s, Use Coupon Code: %s', $v['Merchant Name'], $link['LinkCode']);
				else 
					$link['LinkName'] = sprintf('%s', $v['Merchant Name']);
			}
			$link['LinkHtmlCode'] = create_link_htmlcode_image($link);
			if (empty($link['AffLinkId']) || empty($link['AffLinkId']) || empty($link['LinkName']))
				continue;
			$this->oLinkFeed->fixEnocding($this->info, $link, "feed");
			$arr_return["AffectedCount"] ++;
			$links[] = $link;
			if (($arr_return["AffectedCount"] % 100) == 0)
			{
				$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);
				$links = array();
			}
		}
		echo sprintf("get coupons complete. %s links(s) found. \n", $arr_return["AffectedCount"]);
		if(count($links) > 0)
			$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);

		return $arr_return;
	}

	function GetAllLinksFromAffByMerID($merinfo)
	{
		$arr_return = array("AffectedCount" => 0, "UpdatedCount" => 0, );
		$request = array("AffId" => $this->info["AffId"], "method" => "post", "postdata" => "", );
		$this->Login();
		$url = sprintf("https://www.avantlink.com/affiliate/ads.php?lngMerchantId=%s", $merinfo['IdInAff']);
		$r = $this->oLinkFeed->GetHttpResult($url,$request);
		$content = $r["content"];
		preg_match_all('@\[(\'<a.*?)\]\s,@', $content, $chapters);
		if (!empty($chapters) && !empty($chapters[1]) && is_array($chapters[1]))
		{
			$links = array();
			foreach ($chapters[1] as $line)
			{
				$v = mem_getcsv($line, ',', "'");
				if (empty($v) || !is_array($v) || count($v) < 10)
					continue;
				$link = array(
						"AffId" => $this->info["AffId"],
						"AffMerchantId" => $merinfo['IdInAff'],
						"LinkName" =>  '',
						"LinkDesc" =>  '',
						"LinkStartDate" => parse_time_str($v[6], null, false),
						"LinkEndDate" => parse_time_str($v[7], null, false),
						"LinkPromoType" => '',
						"LinkHtmlCode" => '',
						"LinkCode" => '',
						"LinkOriginalUrl" => '',
						"LinkImageUrl" => '',
						"LinkAffUrl" => '',
						"DataSource" => 12,
				);
				if (preg_match('@<img src="(.*?)"@', $v[1], $g))
				{
					$link['LinkImageUrl'] = 'http://www.avantlink.com/affiliate/' . $g[1];
					$link['LinkName'] = trim(html_entity_decode(strip_tags($v[3])));
				}
				else
				{
					$link['LinkName'] = trim(html_entity_decode(strip_tags($v[2])));
				}
				if (preg_match('@lngMerchantLinkId=(.*?)\&@', $v[0], $g))
				{
					$link['AffLinkId'] = $g[1];
					$link['LinkAffUrl'] = sprintf('http://www.avantlink.com/click.php?tt=ml&amp;ti=%s&amp;pw=4724', $link['AffLinkId']);
				}
				if (empty($link['AffLinkId']) || empty($link['LinkAffUrl']) || empty($link['LinkName']))
					continue;
				$url = sprintf("https://www.avantlink.com/affiliate/ad_source.php?lngMerchantId=%s&lngMerchantLinkId=%s&lngPublisherAdGroupId=0&strLinkType=&blnGetCouponsOnly=0&strSearchTerm=&Base=",
					$link['AffMerchantId'], $link['AffLinkId']);
				$desc = '';
				try 
				{
					$r = $this->oLinkFeed->GetHttpResult($url, $request);
					$desc = $r["content"];
				}
				catch (Exception $e)
				{}
				if (preg_match('@linkPreview"><h3>(.*?)</h3>@ms', $desc, $g));
					$link['LinkDesc'] = trim(html_entity_decode(strip_tags($g[1])));
				$link['LinkPromoType'] = $this->oLinkFeed->getPromoTypeByLinkContent($link['LinkName'] . ' ' . $link['LinkDesc']);
				$code = get_linkcode_by_text($link['LinkName'] . '|' . $link['LinkDesc']);
				if (!empty($code) || $v[8] == 'Yes')
				{
					$link['LinkCode'] = $code;
					$link['LinkPromoType'] = 'COUPON';
				}
				$link['LinkHtmlCode'] = create_link_htmlcode_image($link);
				$link['AffLinkId'] = 'l_' . $link['AffLinkId'];
				$this->oLinkFeed->fixEnocding($this->info, $link, "feed");
				$arr_return["AffectedCount"] ++;
				$links[] = $link;
			}
			echo sprintf("program:%s, %s links(s) found.\n", $merinfo['IdInAff'], count($links));
			if(count($links) > 0)
				$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);
		}
		return $arr_return;
	}
	
	function getProgramByStatus($status, $country)	
	{		
		$request = array(
			"AffId" => $this->info["AffId"],
			"method" => "post",
			"postdata" => "", 
		);
		
		$objProgram = new ProgramDb();
		$arr_prgm = array();
		
		echo "get $status merchants for " . $this->info["AffName"] . "\n";
		
		if($country == "ca"){
			$domain = "https://classic.avantlink.ca";
			$TargetCountryExt = 'CA';
		}else{			
			$domain = "https://classic.avantlink.com";
			$TargetCountryExt = 'US';
		}
		$strUrl = "{$domain}/affiliate/merchants.php";
		$request["postdata"] = "strRelationStatus=" . $status . "&lngMerchantCategoryId=0&strProductKeywords=&cmdFilter=Get+Merchants";
		$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
		$result = $r["content"];

		$Cnt = 0;
		$UpdateCnt = 0;

		//parse HTML
		$nLineStart = 0;
		$strLinksArrayData = $this->oLinkFeed->ParseStringBy2Tag($result, 'var g_arrData_rptlist_201=[', '];', $nLineStart);
		$arrTmpLine = explode("\n", $strLinksArrayData);
		foreach($arrTmpLine as $strLine)
		{
			$strLine = trim($strLine);
			if ($strLine == '') continue;
			
			if(preg_match("/^,?\\[(.*)\\]$/",$strLine,$matches)) $strLine = $matches[1];
			else
			{
				echo "line skipped: $strLine\n";
			}
			
			eval("\$js_mer_info = array($strLine);");
			if($js_mer_info === false) mydie("die: eval failed: $strLine\n");
			
			$StatusInAff = "Active";
			$StatusInAffRemark = "";
			if($status == "active"){
				list($temp,$temp2,$strMerID,$strMerName,$CategoryExt,$Commission_Action,$Commission_Type,$Commission_Rate,$ReturnDays,$Sales_Volume,$Conversion_Rate,$Reversal_Rate,$Average_Sale_Amount,$Date_Joined) = $js_mer_info;
				$JoinDate = date("Y-m-d H:i:s", strtotime($Date_Joined));			
				$CommissionExt = $Commission_Rate;
				$Partnership = "Active";	
			}
			elseif($status == "no-relationship"){
				list($temp,$strMerName,$CategoryExt,$Commission_Action,$Commission_Type,$Commission_Rate,$ReturnDays,$Sales_Volume,$Conversion_Rate,$Reversal_Rate,$Average_Sale_Amount) = $js_mer_info;
				
				$JoinDate = "";
				$CommissionExt = $Commission_Rate;
				$Partnership = "NoPartnership";
			}
			elseif($status == "pending"){
				list($temp,$strMerName,$CategoryExt,$Commission_Action,$Commission_Type,$Commission_Rate,$ReturnDays,$Sales_Volume,$Conversion_Rate,$Reversal_Rate,$Average_Sale_Amount) = $js_mer_info;
				
				$JoinDate = "";
				$CommissionExt = $Commission_Rate;
				$Partnership = "Pending";				
			}
			else{
				list($temp,$reason,$strMerName,$CategoryExt,$Commission_Action,$Commission_Type,$Commission_Rate,$ReturnDays,$Sales_Volume,$Conversion_Rate,$Reversal_Rate,$Average_Sale_Amount) = $js_mer_info;
				
				$JoinDate = "";
				$CommissionExt = $Commission_Rate;
				//'NoPartnership','Active','Pending','Declined','Expired','WeDeclined'
				if($reason == "No longer active in the AvantLink network."){
					$StatusInAff = "Offline";
					$Partnership = "Expired";
				}elseif($reason == "Merchant denied your application to their program."){
					$Partnership = "Declined";
				}elseif($reason == "Merchant terminated their association with you."){
					$Partnership = "Expired";
				}else{
					$Partnership = "Expired";					
				}
				$StatusInAffRemark = $reason;
			}
			
			//a href="merchant_details.php?lngMerchantId=10072">800-Ski-Shop.com</a>
			//'Merchant denied your application to their program.','Altrec.com Outdoors','Outdoor/Recreation','sale','percent',' 10.00%','120','1.48%','15.31%','Configure inactive link handling '
			//pending: '<a href="merchant_details.php?lngMerchantId=11109">Brooklyn Battery Works</a>'
			if(preg_match("/lngMerchantId=([0-9]*)\\\">(.*)<\\/a>/",$strMerName,$matches))
			{
				//double check $strMerID
				$strMerID = $matches[1];
				$strMerName = trim(strip_tags($matches[2]));
			}
			else
			{
				mydie("die: parse failed: $strLine\n");
			}
			
			/*if($status == "active"){
				$StatusInAff = "Active";
			}
			elseif($status == "inactive"){				
				$StatusInAff = "Active";
			}
			elseif($status == "no-relationship"){			
				$StatusInAff = "Active";
			}
			elseif($status == "pending"){
				$StatusInAff = "Active";
			}
			else{
				mydie("die: wrong status($status)");
			}*/
			
			$RankInAff = trim($this->oLinkFeed->ParseStringBy2Tag($Sales_Volume, array('volume_'), '.'));
									
			//program
			//program_detail
			$prgm_url = "{$domain}/affiliate/merchant_details.php?lngMerchantId=$strMerID";
			$prgm_arr = $this->oLinkFeed->GetHttpResult($prgm_url, $request);
			$prgm_detail = $prgm_arr["content"];
			
			$prgm_line = 0;
			
			//$StatusInAff = $strStatus;//'Active','TempOffline','Expired'
			//statusinfaffremark
			//$StatusInAffRemark = $strStatus;
			
			$Homepage = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<strong>Merchant:</strong>', '<td><a href="'), '"', $prgm_line));
			$Contact = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<strong>Contact:</strong>', '<td>'), '</td>', $prgm_line));
			$Contact_email = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<strong>Contact Email:</strong>', 'mailto:'), '">', $prgm_line));
			$Contacts = $Contact.", Emial: ".$Contact_email;			
			
			$desc = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<strong>Program Description:</strong>', '<td>'), '</td>', $prgm_line));
			$NumberOfOccurrences = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<strong>Referral Ocurrences:</strong>', '<td>'), '</td>', $prgm_line));
			/*if($NumberOfOccurrences == "Unlimited"){
				$NumberOfOccurrences = -1;
			}*/
			
			$SubAffPolicyExt = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<strong>Reversal Policy:</strong>', '<td>'), '</td>', $prgm_line));
			
			$BonusExt = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<strong>Performance Incentives:</strong>', '<td>'), '</table>', $prgm_line));
			if($BonusExt){
				 $BonusExt .= "</table>";
			}
			
			$TermAndCondition = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<strong>Terms and Conditions:</strong>', '<td valign="top">'), '</td>', $prgm_line));
			if(empty($TermAndCondition))
				$TermAndCondition = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<strong>Terms and Conditions:</strong>', '<td>'), '</td>', $prgm_line));
			
			$arr_prgm[$strMerID] = array(
				"Name" => addslashes(html_entity_decode(trim($strMerName))),
				"AffId" => $this->info["AffId"],
				"CategoryExt" => addslashes($CategoryExt),
				"TargetCountryExt" => $TargetCountryExt,
				"Contacts" => addslashes($Contacts),				
				"IdInAff" => $strMerID,
				"RankInAff" => intval($RankInAff),
				"CreateDate" => $JoinDate,
				"StatusInAff" => $StatusInAff,						//'Active','TempOffline','Offline'
				"StatusInAffRemark" => $StatusInAffRemark,
				"Partnership" => $Partnership,						//'NoPartnership','Active','Pending','Declined','Expired','WeDeclined'				
				"Description" => addslashes($desc),
				"Homepage" => $Homepage,
				"CommissionExt" => addslashes($CommissionExt),
				"BonusExt" => addslashes($BonusExt),
				"CookieTime" => $ReturnDays,
				"NumberOfOccurrences" => addslashes($NumberOfOccurrences),
				"TermAndCondition" => addslashes($TermAndCondition),
				"SubAffPolicyExt" => addslashes($SubAffPolicyExt),
				"LastUpdateTime" => date("Y-m-d H:i:s"),
				"DetailPage" => $prgm_url,
				"SupportDeepUrl" => "YES"
			);
			
			$Cnt++;
	
			if(count($arr_prgm) >= 100){
				$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
				$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
				$arr_prgm = array();
			}
		}
		
		if(count($arr_prgm)){
			$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
			$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
			$arr_prgm = array();
		}		
		
		$objProgram->setCountryInt($this->info["AffId"]);		
		
		return $Cnt;
	}
	
	function GetProgramByPage()
	{
		echo "\tGet Program by page start\r\n";		
		$program_num = 0;
		//step 1,login
		$this->Login();

		//step 2,get all exists merchant
		//$arrAllExistsMerchants = $this->oLinkFeed->GetAllExistsAffMerIDForCheckByAffID($this->info["AffId"]);

		$arrStatus4List = array("active","inactive","no-relationship","pending");
		foreach($arrStatus4List as $status)
		{
			$program_num += $this->getProgramByStatus($status, "us");
		}
		
		echo "\tGet Program by page end\r\n";
		
		if($program_num < 10){
			mydie("die: program count < 10, please check program.\n");
		}
		
		echo "\tUpdate ({$program_num}) program.\r\n";
		
	}
	
	function GetProgramFromAff()
	{	
		$check_date = date("Y-m-d H:i:s");
		echo "Craw Program start @ {$check_date}\r\n";
		
		$this->GetProgramByPage();		
		$this->checkProgramOffline($this->info["AffId"], $check_date);

		echo "Craw Program end @ ".date("Y-m-d H:i:s")."\r\n";
	}
	
	function checkProgramOffline($AffId, $check_date){		
		$objProgram = new ProgramDb();
		$prgm = array();
		$prgm = $objProgram->getNotUpdateProgram($this->info["AffId"], $check_date);
		
		if(count($prgm) > 30){
			mydie("die: too many offline program (".count($prgm).").\n");
		}else{			
			$objProgram->setProgramOffline($this->info["AffId"], $prgm);
			echo "\tSet (".count($prgm).") offline program.\r\n";
		}
	}

}
?>
