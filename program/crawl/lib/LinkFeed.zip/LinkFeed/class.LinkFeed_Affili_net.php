<?php
require_once 'text_parse_helper.php';

class LinkFeed_Affili_net
{
	function LoginIntoAffService()
	{
		//get para __VIEWSTATE and then process default login
		if(!isset($this->info["AffLoginPostStringOrig"])) {
			$this->info["AffLoginPostStringOrig"] = $this->info["AffLoginPostString"];
		}
		$request = array("AffId" => $this->info["AffId"], "method" => "get", "postdata" => "",);
		$url = $this->info["AffLoginUrl"];
		$r = $this->oLinkFeed->GetHttpResult($url, $request);
		$content = $r["content"];
		$param = array(
				'__EVENTTARGET' => 'ctl00$body$btnLogin',
				'__EVENTARGUMENT' => '',
				'__VIEWSTATE' => '',
				'__VIEWSTATEGENERATOR' => '',
				'__EVENTVALIDATION' => '',
				);
		$keywords = array('__VIEWSTATE', '__VIEWSTATEGENERATOR', '__EVENTVALIDATION');
		foreach ($keywords as $keyword){
			if (preg_match(sprintf('@id="%s" value="(.*?)"@', $keyword), $content, $g)){
				$param[$keyword] = $g[1];
			}else{
				mydie("login failed: $keyword");
			}
		}
		$this->info["AffLoginPostString"] = http_build_query($param) . "&" . $this->info["AffLoginPostStringOrig"];
		$this->oLinkFeed->LoginIntoAffService($this->info["AffId"], $this->info, 2, true, true, false);
		return "stophere";
	}

	private function getCredentialToken()
	{
		if (empty($this->credentialToken))
		{
			$client = new SoapClient('https://api.affili.net/V2.0/Logon.svc?wsdl', array('trace'=>true));
			$this->credentialToken = $client->Logon(array('Username' => $this->API_USERNAME, 'Password' => $this->API_PASSWORD, 'WebServiceType' => 'Publisher'));
		}
		return $this->credentialToken;
	}

	function getCouponFeed()
	{
		$arr_return = array("AffectedCount" => 0,"UpdatedCount" => 0,"Detail" => array());

		$data = $this->soapGetVoucherCodes(array(
						'PublisherId' => $this->API_USERNAME,
						'ProgramId' => 0,
						'VoucherCode' => null,
						'Query' => null,
						'StartDate' => date('Y-m-d'),
						'EndDate' => date('Y-m-d', time() + 604800)
					));
		$links = array();
		if (!empty($data) && !empty($data->VoucherCodeCollection) && !empty($data->VoucherCodeCollection->VoucherCodeCollection) && is_array($data->VoucherCodeCollection->VoucherCodeCollection))
		{
			foreach ($data->VoucherCodeCollection->VoucherCodeCollection as $v)
			{
				$link = array(
						"AffId" => $this->info["AffId"],
						"AffMerchantId" => $v->ProgramId,
						"LinkDesc" => '',
						"LinkStartDate" => '0000-00-00 00:00:00',
						"LinkEndDate" => '0000-00-00 00:00:00',
						"LinkPromoType" => 'DEAL',
						"LinkOriginalUrl" => "",
						"LinkHtmlCode" => $v->IntegrationCode,
						"AffLinkId" => $v->Id,
						"LinkName" => $v->Description,
						"LinkCode" => $v->Code,
						"LinkImageUrl" => "",
						"LinkAffUrl" => "",
						"DataSource" => $this->DataSource,
				);
				if (!empty($v->StartDate))
				{
					$date = strtotime($v->StartDate);
					if ($date > 946713600)
						$link['LinkStartDate'] = date('Y-m-d 00:00:00', $date);
				}
				if (!empty($v->EndDate))
				{
					$date = strtotime($v->EndDate);
					if ($date > 946713600)
						$link['LinkEndDate'] = date('Y-m-d 23:59:59', $date);
				}
				if (preg_match('@<a href="(.*?)"@', $link['LinkHtmlCode'], $g))
					$link['LinkAffUrl'] = $g[1];
				if (!empty($link['LinkCode']))
					$link['LinkPromoType'] = 'COUPON';
				else
					$link['LinkPromoType'] = $this->oLinkFeed->getPromoTypeByLinkContent($link['LinkName']);
				if (empty($link['AffLinkId']) || empty($link['LinkName']) || empty($link['LinkAffUrl']))
					continue;
				$links[] = $link;
			}
		}
		echo sprintf("get coupon by api...%s link(s) found.\n", count($links));
		if (count($links) > 0)
			$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);
		return $arr_return;
	}

	function GetAllLinksFromAffByMerID($merinfo)
	{
		$arr_return = array("AffectedCount" => 0, "UpdatedCount" => 0, );
		list($page, $limit, $total, $links) = array(0, 100, 0, array());
		do
		{
			$page ++;
			$links = array();
			$r = $this->soapSearchCreatives($merinfo['IdInAff'], $page, $limit);
			if (empty($r) || empty($r->CreativeCollection) || empty($r->CreativeCollection->Creative))
				break;
			$total = (int)$r->TotalResults;
			$data = $r->CreativeCollection->Creative;
			if (!is_array($data) && !empty($data))
				$data = array($data);
			foreach ((array)$data as $v)
			{
				$link = array(
					"AffId" => $this->info["AffId"],
					"AffMerchantId" => $merinfo['IdInAff'],
					"AffLinkId" => sprintf('%s_%s_%s', $merinfo['IdInAff'], $v->CreativeTypeEnum, $v->CreativeNumber),
					"LinkName" => html_entity_decode(trim($v->Title)),
					"LinkDesc" => '',
					"LinkStartDate" => '0000-00-00',
					"LinkEndDate" => '0000-00-00',
					"LinkPromoType" => 'N/A',
					"LinkHtmlCode" => $v->IntegrationCode,
					"LinkOriginalUrl" => '',
					"LinkImageUrl" => '',
					"LinkAffUrl" => '',
					"DataSource" => $this->DataSource,
				);
				if (!empty($v->BannerStub))
				{
					$link['LinkImageUrl'] = $v->BannerStub->BannerURL;
					$link['LinkDesc'] = $v->BannerStub->AltTag;
				}
				if (!empty($v->TextStub))
					$link['LinkDesc'] = $v->TextStub->Header;
				$code = get_linkcode_by_text_de($link['LinkName'] . '|' . $link['LinkDesc']);
				if (!empty($code))
				{
					$link['LinkPromoType'] = 'COUPON';
					$link['LinkCode'] = $code;
				}
				else
					$link['LinkPromoType'] = $this->oLinkFeed->getPromoTypeByLinkContent($link['LinkName']);
				if (preg_match('@a href="(.*?)"@i', $link['LinkHtmlCode'], $g))
					$link['LinkAffUrl'] = $g[1];
				if (empty($link['AffLinkId']) || empty($link['LinkName']) || empty($link['LinkHtmlCode']))
					continue;
				$this->oLinkFeed->fixEnocding($this->info, $link, "feed");
				$links[] = $link;
				$arr_return["AffectedCount"] ++;
			}
			echo sprintf("program:%s, page:%s, %s links(s) found. \n", $merinfo['IdInAff'], $page, count($links));
			if(count($links) > 0)
				$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);
			sleep(1);
		}while($page * $limit < $total && $page * $limit < 9999);
		return $arr_return;
	}

	private function getSoapToken()
	{
		if ($this->soapToken)
			return $this->soapToken;
		$this->oLinkFeed->clearHttpInfos(63);
		$logon = new SoapClient("https://api.affili.net/V2.0/Logon.svc?wsdl", array('trace'=> true));
		$token = $logon->Logon(array(
				'Username'  => $this->API_USERNAME,
				'Password'  => $this->API_PASSWORD,
				'WebServiceType' => 'Publisher'
		));
		$this->soapToken = $token;
		echo sprintf("Logon token %s created at %s.\n", $token, date('Y-m-d H:i:s', time()));
		return $this->soapToken;
	}
	
	private function soapGetVoucherCodes($GetVoucherCodesRequestMessage, $retry = 2){
		$token = $this->getSoapToken();
		$client = $this->soapInboxClient;
		if (!$client)
		{
			$client = new SoapClient('https://api.affili.net/V2.0/PublisherInbox.svc?wsdl', array('trace'=> true));
			$this->soapInboxClient = $client;
		}
		try
		{
			$r = $client->GetVoucherCodes(array(
				'CredentialToken' => $token,
				'GetVoucherCodesRequestMessage' => $GetVoucherCodesRequestMessage
			));
		}
		catch (Exception $e)
		{
			if (preg_match('@Illegal characters@', $e->getMessage()))
			{
				// this exception may caused by the server catch it and return null
				echo sprintf("%s Exception return null\n", $e->getMessage());
				return null;
			}
			// try to relogon.
			$this->soapToken = null;
			$retry --;
			if ($retry < 0)
				throw $e;
			echo sprintf("%s Exception sleep 120...\n", $e->getMessage());
			sleep(120);
			return $this->soapGetVoucherCodes($IdInAff, $page, $limit, $retry);
		}
		return $r;
	}

	private function soapSearchCreatives($IdInAff, $page, $limit, $retry = 2)
	{
		$token = $this->getSoapToken();
		$client = $this->soapClient;
		if (!$client)
		{
			$client = new SoapClient('https://api.affili.net/V2.0/PublisherCreative.svc?wsdl', array('trace'=> true));
			$this->soapClient = $client;
		}
		try 
		{
			$r = $client->SearchCreatives(array(
				'CredentialToken' => $token,
				'DisplaySettings' => array('CurrentPage' => $page, 'PageSize' => $limit),
				'SearchCreativesQuery' => array(
						'CreativeTypes' => array('Text', 'Banner'),
						'ProgramIds' => array($IdInAff),
						)
			));
		}
		catch (Exception $e)
		{
			if (preg_match('@Illegal characters@', $e->getMessage()))
			{
				// this exception may caused by the server catch it and return null
				echo sprintf("%s Exception return null\n", $e->getMessage());
				return null;
			}
			// try to relogon.
			$this->soapToken = null;
			$retry --;
			if ($retry < 0)
				throw $e;
			echo sprintf("%s Exception sleep 120...\n", $e->getMessage());
			sleep(120);
			return $this->soapSearchCreatives($IdInAff, $page, $limit, $retry);
		}
		return $r;
	}

	function GetProgramFromAff()
	{
		$check_date = date("Y-m-d H:i:s");
		echo "Craw Program start @ {$check_date}\r\n";

		$this->GetProgramByApi();
		$this->GetProgramMobileFriendly();
		$this->checkProgramOffline($this->info["AffId"], $check_date);

		echo "Craw Program end @ ".date("Y-m-d H:i:s")."\r\n";
	}
	
	function GetProgramMobileFriendly()
	{
		echo "\tGetProgramMobileFriendly.\n";
		$this->oLinkFeed->LoginIntoAffService($this->info["AffId"],$this->info);
		$request = array("AffId" => $this->info["AffId"], "method" => "get",);
		$url = sprintf("http://publisher.affili.net/Programs/ProgramListExport.aspx?wspw=ONBGkuGeq0u0yKBFwGzg");
		$r = $this->oLinkFeed->GetHttpResult($url, $request);
		$content = $r['content'];
		$content = str_replace("\r", "\n", $content);
		$rows = fgetcsv_str($content, 0, ';', '"');
		$programs = array();
		$objProgram = new ProgramDb();
		foreach ($rows as $row){
			if (empty($row) || empty($row['Program ID']) || !is_numeric($row['Program ID']))
				continue;
			$id = $row['Program ID'];
			$programs[$id] = array("AffId" => $this->info["AffId"], 'IdInAff' => $id, 'MobileFriendly' => 'UNKNOWN', 'Name' => addslashes(trim($row['Title'])));
			$id = $row['Program ID'];
			if (!empty($row['Mobile'])){
				$programs[$id]['MobileFriendly'] = 'YES';
			}
			if(count($programs) >= 100){
				$objProgram->updateProgram($this->info["AffId"], $programs);
				$programs = array();
			}
		}
		if(count($programs)){
			$objProgram->updateProgram($this->info["AffId"], $programs);
		}
	}

	function GetProgramByApi()
	{
		echo "\tGet Program by api start\r\n";
		$objProgram = new ProgramDb();
		$arr_prgm = array();
		$program_num = 0;
		
		$prgm_homepage = array();

		/* <LIVE DATA> */
		define ("WSDL_LOGON", "https://api.affili.net/V2.0/Logon.svc?wsdl");
		define ("WSDL_PROG",  "https://api.affili.net/V2.0/PublisherProgram.svc?wsdl");

		$Username = $this->API_USERNAME; // the publisher ID
		$Password = $this->API_PASSWORD; // the publisher web services password
		$SOAP_LOGON = new SoapClient(WSDL_LOGON, array('trace'=> true));
		$Token = $SOAP_LOGON->Logon(array(
				'Username'  => $Username,
				'Password'  => $Password,
				'WebServiceType' => 'Publisher'
				));

		$params = array('Query' => '');
		try {
			$SOAP_REQUEST = new SoapClient(WSDL_PROG, array('trace'=> true));
			$req = $SOAP_REQUEST->GetAllPrograms(array(
					'CredentialToken' => $Token,
					'GetProgramsRequestMessage' => $params
					));
			$total = $req->TotalRecords;
			foreach($req->Programs->ProgramSummary as $prgm){
				$strMerID = $prgm->ProgramId;
				if(!$strMerID) continue;

				$Partnership = "NoPartnership";
				$StatusInAffRemark = $prgm->PartnershipStatus;
				if($StatusInAffRemark == 'Active'){
					$Partnership = 'Active';
				}elseif($StatusInAffRemark == 'Declined'){
					$Partnership = 'Declined';
				}elseif($StatusInAffRemark == 'Waiting'){
					$Partnership = 'Pending';
				}elseif($StatusInAffRemark == 'Paused'){
					$Partnership = 'Expired';
				}elseif($StatusInAffRemark == 'NotApplied'){
					$Partnership = 'NoPartnership';
				}
				$StatusInAff = 'Active';
				
				if ($this->info["AffId"] == 26 && $strMerID == '12489')
				{
					// the api return Expired
					// but the partnership is active in the page
					// change to get it in the page
					// temporarily just set to active
					$Partnership = 'Active';
					$StatusInAff = 'TempOffline';
				}

				$CommissionExt = '
				PayPerSale: '.$prgm->CommissionRates->PayPerSale->MinRate.' - '.$prgm->CommissionRates->PayPerSale->MaxRate.',
				PayPerLead: '.$prgm->CommissionRates->PayPerLead->MinRate.' - '.$prgm->CommissionRates->PayPerLead->MaxRate.',
				PayPerClick: '.$prgm->CommissionRates->PayPerClick->MinRate.' - '.$prgm->CommissionRates->PayPerClick->MaxRate.'
				';
				
				//$homepage = "";
				//$homepage =  $this->oLinkFeed->findFinalUrl($prgm->Url, array("nobody" => "unset"));

				$arr_prgm[$strMerID] = array(
					"AffId" => $this->info["AffId"],
					"IdInAff" => $strMerID,	
					"Name" => addslashes($prgm->ProgramTitle),
					//"Homepage" => strlen($homepage) ? $homepage : $prgm->Url,
					"Description" => addslashes($prgm->Description),
					"TermAndCondition" => addslashes($prgm->Limitations),
					"StatusInAffRemark" => addslashes($StatusInAffRemark),
					"StatusInAff" => $StatusInAff,						//'Active','TempOffline','Offline'
					"Partnership" => $Partnership,					//'NoPartnership','Active','Pending','Declined','Expired','WeDeclined'
					"DetailPage" => "http://publisher.affili.net/Programs/programInfo.aspx?pid=$strMerID",
					"LastUpdateTime" => date("Y-m-d H:i:s"),
					"CommissionExt" => addslashes($CommissionExt),
				);
				
				$prgm_homepage[$strMerID] = array(
													"IdInAff" => $strMerID,
													"Homepage" => $prgm->Url
												);

				$program_num++;
				if(count($arr_prgm) >= 100){
					$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
					//$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
					$arr_prgm = array();
				}
			}
		} catch( Exception $e ) {
			mydie("die: Api error.\n");
		}

		if(count($arr_prgm)){
			$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
			//$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
			unset($arr_prgm);
		}

		echo "\tGet Program by api end\r\n";
		if($program_num < 10){
			mydie("die: program count < 10, please check program.\n");
		}
		echo "\tUpdate ({$program_num}) program.\r\n";
		echo "\tSet program country int.\r\n";
		$objProgram->setCountryInt($this->info["AffId"]);
		
		
		echo "start check program url";
		$arr_prgm = array();
		foreach($prgm_homepage as $v){
			if($v["Homepage"]){				
				$homepage =  $this->oLinkFeed->findFinalUrl($v["Homepage"], array("nobody" => "unset"));
				if($homepage){
					$arr_prgm[$v["IdInAff"]] = array(
													"AffId" => $this->info["AffId"],
													"IdInAff" => $v["IdInAff"],
													"Homepage" => $homepage
												);
					if(count($arr_prgm) >= 100){
						$objProgram->updateProgram($this->info["AffId"], $arr_prgm);						
						$arr_prgm = array();
					}
				}
			}
		}
		if(count($arr_prgm)){
			$objProgram->updateProgram($this->info["AffId"], $arr_prgm);			
			unset($arr_prgm);
		}
		
	}

	function checkProgramOffline($AffId, $check_date){
		$objProgram = new ProgramDb();
		$prgm = array();
		$prgm = $objProgram->getNotUpdateProgram($this->info["AffId"], $check_date);
		if(count($prgm) > 30){
			mydie("die: too many offline program (".count($prgm).").\n");
		}else{
			$objProgram->setProgramOffline($this->info["AffId"], $prgm);
			echo "\tSet (".count($prgm).") offline program.\r\n";
		}
	}
}

