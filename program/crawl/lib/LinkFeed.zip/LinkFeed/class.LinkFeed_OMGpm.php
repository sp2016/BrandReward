<?php
class LinkFeed_OMGpm //for 57,125,163.240
{
	
	function GetProgramFromAff()
	{	
		$check_date = date("Y-m-d H:i:s");
		echo "Craw Program start @ {$check_date}\r\n";
		
		$this->GetProgramByPage();		
		$this->checkProgramOffline($this->info["AffId"], $check_date);

		echo "Craw Program end @ ".date("Y-m-d H:i:s")."\r\n";
	}
	
	function GetProgramByPage()
	{
		echo "\tGet Program by page start\r\n";
		$objProgram = new ProgramDb();
		$arr_prgm = array();
		$program_num = 0;

		$request = array(
			"AffId" => $this->info["AffId"],
			"method" => "get",
		);

		$aff_country_id = array(	57 => array(1, 2),		//United Kingdom, France, United States(20)
									125 => array(22, 24),	//Australia, New Zealand
									163 => array(0, 110, 135, 170, 189, 205, 228), //ALL, Indonesia, Malaysia, Philippines, Singapore, Thailand, Global
									240 => array(26)
								);

		$aff_info = array(	57 => array("Agency" => 1, "Affiliate" => 141509, "Hash" => "5627c3994678168f14c89f2e0ac7d16c", "WID" => 30634),
							125 => array("Agency" => 47, "Affiliate" => 191911, "Hash" => "8E1422CDB3AE0D628265F4B733C00EFB", "WID" => 34526),
							163 => array("Agency" => 118, "Affiliate" => 382508, "Hash" => "22903A290D34C7A39487A7CDE43F3CBB", "WID" => 42902),
							240 => array("Agency" => 95, "Affiliate" => 428397, "Hash" => "5076F899ABE19BA931617AF2E3516836", "WID" => 47521)
						);
		$country_id_arr = $aff_country_id[$this->info["AffId"]];
		$Agency = $aff_info[$this->info["AffId"]]["Agency"];
		$Affiliate = $aff_info[$this->info["AffId"]]["Affiliate"];
		$Hash = $aff_info[$this->info["AffId"]]["Hash"];
		$WID = "&WID=".$aff_info[$this->info["AffId"]]["WID"];
		
		foreach($country_id_arr as $country_id){			
			print "check country($country_id)\n";
			// get program from csv.
			$str_header = 'MerchantName,MerchantLogoURL,ProductName,ProductDescription,PID,Sector,CountryCode,PayoutType,CookieDuration,ProductFeedAvailable,DeepLinkEnabled,UidTracking,ProgrammeStatus,WebsiteURL,TrackingURL,Commission';
			$cache_file = $this->oLinkFeed->fileCacheGetFilePath($this->info["AffId"],"program_country{$country_id}.csv","cache_merchant");
			if(!$this->oLinkFeed->fileCacheIsCached($cache_file))
			{
				$strUrl = "http://admin.omgpm.com/v2/Reports/Affiliate/ProgrammesExport.aspx?Agency=$Agency&Country={$country_id}&Affiliate=$Affiliate&Search=&Sector=0&UidTracking=False&PayoutTypes=&ProductFeedAvailable=False&Format=CSV&AuthHash=$Hash&AuthAgency=$Agency&AuthContact=$Affiliate&ProductType=0";	
				$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
				$result = $r["content"];
				print "Get country($country_id) files \n";
				if(stripos($result,$str_header) === false) mydie("die: wrong csv file: $cache_file");
				$this->oLinkFeed->fileCachePut($cache_file,$result);	
			}
			
			//Open CSV File			
			$fhandle = fopen($cache_file, 'r');
			
			while($line = fgetcsv ($fhandle, 5000))
			{
				foreach($line as $k => $v) $line[$k] = trim($v);			
				
				if (trim($line[1]) == 'MerchantLogoURL') continue;
				
				$MerchantName = $line[0];			
				$ProductName = $line[2];
				$desc = $line[3];
				$IdInAff = intval($line[4]);			
				$CategoryExt = $line[5];
				$TargetCountryExt = $line[6];
				$PayoutType = $line[7];			
				$ReturnDays = $line[8];
				//$ProductFeedAvailable = $line[9];
				$SupportDeepurl = $line[10];			
				//$UidTracking = $line[11];
				$StatusInAffRemark = $line[12];
				$Homepage = $line[13];			
				$AffDefaultUrl = $line[14];
				$CommissionExt = $line[15];
				
				
				$prgm_name = $MerchantName . "-" . $ProductName;
				
				$CommissionExt .= "PayoutType: ".$PayoutType;
				
				if($StatusInAffRemark == "Not Applied"){
					$Partnership = "NoPartnership";
				}elseif($StatusInAffRemark == "Rejected"){
					$Partnership = "Declined";
				}elseif($StatusInAffRemark == "Live"){
					$Partnership = "Active";
				}elseif($StatusInAffRemark == "Cancelled"){
					$Partnership = "Expired";
				}elseif($StatusInAffRemark == "Waiting"){
					$Partnership = "Pending";
				}else{
					$Partnership = "NoPartnership";
				}
				
				if($AffDefaultUrl) $AffDefaultUrl.=$WID;
				
				//$prgm_url = "https://admin.omgpm.com/v2/programmes/affiliate/viewprogramme.aspx?ProductID=$IdInAff&ContactWebsiteID=28440";
				
				$arr_prgm[$IdInAff] = array(
					"AffId" => $this->info["AffId"],	
					"IdInAff" => $IdInAff,
					"Name" => addslashes($prgm_name),
					"CategoryExt" => addslashes($CategoryExt),
					"TargetCountryExt" => $TargetCountryExt,
					"Homepage" => addslashes($Homepage),
					"Description" => addslashes($desc),				
					"CommissionExt" => addslashes($CommissionExt),
					"CookieTime" => addslashes($ReturnDays),
					"StatusInAffRemark" => addslashes($StatusInAffRemark),
					"StatusInAff" => 'Active',						//'Active','TempOffline','Offline'
					"Partnership" => $Partnership,						//'NoPartnership','Active','Pending','Declined','Expired','WeDeclined'						
					"LastUpdateTime" => date("Y-m-d H:i:s"),
					//"DetailPage" => $prgm_url,
					"SupportDeepurl" => $SupportDeepurl,
					"AffDefaultUrl" => $AffDefaultUrl
				);
				//print_r($arr_prgm);exit;
				$program_num++;			
				
				if(count($arr_prgm) >= 100){
					$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
					$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
					$arr_prgm = array();
				}
			}
			fclose($fhandle);
		}
				
		if(count($arr_prgm)){
			$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
			$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
			unset($arr_prgm);
		}
		
		
		/*$r = $this->oLinkFeed->GetHttpResult("https://admin.omgpm.com/en/clientarea/affiliates/affiliate_campaigns.asp", $request);			
		$result = $r["content"];
				
		//parse HTML	
		$strLineStart = '<th>Merchant</th>';
		$nLineStart = stripos($result, $strLineStart, 0);		
	
		$strLineStart = '<tr';
		while ($nLineStart >= 0){
			$nLineStart = stripos($result, $strLineStart, $nLineStart);
			if ($nLineStart === false) break;
			
			$StatusInAff = 'Active';
			//merchant name
			$strMerName = trim($this->oLinkFeed->ParseStringBy2Tag($result, '<td>', "</td>", $nLineStart));
			if ($strMerName === false) break;
			if(stripos($strMerName, "Closed") !== false){
				$StatusInAff = 'Offline';
			}

			//program name
			$prgm_name = trim($this->oLinkFeed->ParseStringBy2Tag($result, '<td>', "</td>", $nLineStart));
			if ($prgm_name === false) break;
			if(stripos($prgm_name, "Closed") !== false){
				$StatusInAff = 'Offline';
			}
			
			$prgm_name = trim(str_ireplace(array("(Closed)", "Closed -"), "", $prgm_name));
			$CommissionExt = trim($this->oLinkFeed->ParseStringBy2Tag($result, '<td>', "</td>", $nLineStart));
			$PayoutType = trim($this->oLinkFeed->ParseStringBy2Tag($result, '<td>', "</td>", $nLineStart));
			$CookieTime = trim($this->oLinkFeed->ParseStringBy2Tag($result, '<td>', "</td>", $nLineStart));
			$ProductFeed = trim($this->oLinkFeed->ParseStringBy2Tag($result, '<td>', "</td>", $nLineStart));
			$UID = trim($this->oLinkFeed->ParseStringBy2Tag($result, '<td>', "</td>", $nLineStart));
			$StatusInAffRemark = trim($this->oLinkFeed->ParseStringBy2Tag($result, '<td>', "</td>", $nLineStart));
			
			$Partnership = "NoPartnership";
			if($StatusInAffRemark == "Live"){
				$Partnership = "Active";
			}elseif($StatusInAffRemark == "Cancelled"){
				$Partnership = "Expired";
			}elseif($StatusInAffRemark == "Rejected"){
				$Partnership = "Declined";
			}elseif($StatusInAffRemark == "Not Applied"){
				$Partnership = "Declined";
			}elseif($StatusInAffRemark == "Waiting"){
				$Partnership = "Pending";
			}
			
			$prgm_url = "https://admin.omgpm.com".trim($this->oLinkFeed->ParseStringBy2Tag($result, 'href="', '"', $nLineStart));
			$prgm_id = intval($this->oLinkFeed->ParseStringBy2Tag($prgm_url, 'ProductID=', "&"));
					
			$arr_prgm[$prgm_id] = array(
				"AffId" => $this->info["AffId"],	
				"IdInAff" => $prgm_id,
				"Name" => addslashes($prgm_name),
				//"Homepage" => addslashes($Homepage),
				//"Description" => addslashes($desc),
				"StatusInAffRemark" => $StatusInAffRemark,
				"CommissionExt" => addslashes($CommissionExt),
				"CookieTime" => $CookieTime,
				"StatusInAff" => $StatusInAff,						//'Active','TempOffline','Offline'
				"Partnership" => $Partnership,						//'NoPartnership','Active','Pending','Declined','Expired','WeDeclined'						
				"LastUpdateTime" => date("Y-m-d H:i:s"),
				"DetailPage" => $prgm_url,
			);
		}*/
		
		
		echo "\tGet Program by page end\r\n";
		
		if($program_num < 10){
			mydie("die: program count < 10, please check program.\n");
		}
		
		echo "\tUpdate ({$program_num}) program.\r\n";
		echo "\tSet program country int.\r\n";
		$objProgram->setCountryInt($this->info["AffId"]);
	}
	
	function checkProgramOffline($AffId, $check_date){		
		$objProgram = new ProgramDb();
		$prgm = array();
		$prgm = $objProgram->getNotUpdateProgram($this->info["AffId"], $check_date);
		
		if(count($prgm) > 30){
			mydie("die: too many offline program (".count($prgm).").\n");
		}else{			
			$objProgram->setProgramOffline($this->info["AffId"], $prgm);
			echo "\tSet (".count($prgm).") offline program.\r\n";
		}
	}
}
?>
