<?php

require_once 'text_parse_helper.php';

class LinkFeed_TD
{
	function LoginIntoAffService()
	{
		//get para __VIEWSTATE and then process default login
		$request = array(
			"AffId" => $this->info["AffId"],
			"method" => "post",
			"postdata" => $this->info["AffLoginPostString"],
			"maxredirs" => 4,//if we dont set this, it will be failed at the fifth redir
			//"verbose" => 1, //for debug
			//"referer" => "https://publisher.tradedoubler.com/index.html",
			//"autoreferer" => 1,
		);
		$strUrl = $this->info["AffLoginUrl"];
		$arr = $this->oLinkFeed->GetHttpResult($strUrl,$request);
		$request = array("AffId" => $this->info["AffId"], "method" => "get",);
		$strUrl = "https://publisher.tradedoubler.com/publisher/aStartPage.action";
		$arr = $this->oLinkFeed->GetHttpResult($strUrl,$request);
		if($this->info["AffLoginVerifyString"] && stripos($arr["content"], $this->info["AffLoginVerifyString"]) !== false)
		{
			echo "verify succ: " . $this->info["AffLoginVerifyString"] . "\n";
			return true;
		}
		else
		{
			print_r($arr);
			echo "verify failed: " . $this->info["AffLoginVerifyString"] . "\n";
		}
		return false;
	}

	function getSiteId()
	{
		$arr_return = array();
		switch($this->info["AffId"])
		{
			case 5: // UK
				$arr_return["en_GB"]["1550868"] = "UK"; //"Couponsnapshot UK";
				break;
			case 133: // UK
				$arr_return["en_GB"]["1470197"] = "US"; //"Coupon Snapshot";note: us is also for GB 
				break;
			case 27: // IE
				$arr_return["en_IE"]["1634367"] = "IE"; //"Irelandvouchercodes.com [IE]";
				break;
			case 35: // DE
				$arr_return["de_DE"]["1781705"] = "DE"; //"CouponSnapshot DE";
				break;
			case 415: // AT
				$arr_return["de_DE"]["2489540"] = "AT"; //"CouponSnapshot DE";
				break;
			case 429: // CH
				$arr_return["de_DE"]["2502032"] = "CH"; //"CouponSnapshot DE";
				break;
			case 469: // FR
				$arr_return["de_DE"]["2525860"] = "FR"; //"CouponSnapshot DE";
				break;
			default:
				mydie("die:Wrong AffID for LinkFeed_TD\n");
		}
		return $arr_return;
	}

	function getSiteId_simple()
	{
		switch($this->info["AffId"])
		{
			case 5: // UK
				return 1550868;
			case 133: // UK
				return 1470197;
			case 27: // IE
				return 1634367;
			case 35: // DE
				return 1781705;
			case 415: //AT
				return 2489540;
			case 429: //CH
				return 2502032;
			case 469: //FR
				return 2525860;
			default:
				mydie("die:Wrong AffID for LinkFeed_TD\n");
		}
	}

	function getCouponFeed()
	{
		$arr_return = array("AffectedCount" => 0,"UpdatedCount" => 0,"Detail" => array());
		$request = array("AffId" => $this->info["AffId"], "method" => "get", "postdata" => "");
		// coupons by api
		$tokens = array(
				5 => "6877C6CA527D1D1AC66457380E369CF6CBF5329B",	//Couponsnapshot UK
				27 => "04CA8B5BD13C0C90F619FB0EFA5847668CBC2989",	//Couponsnapshot IE
				35 => "F729220D1504863DC90D1206EC500E11FEA3ED57",	//CouponSnapshot DE
				133 => "FB4F79B3F20B9ECADC449C8349F279176A2A49FA",	//CouponSnapshot US
				415 => "02A7D2B32B07AF82143E7F3626A5B3070DD287D4",   //CouponSnapshot AT
				429 => "99B6A09A1E0A40FD08AF6B08D3E871452664FA7A"	//AlleCodes CH
		);
		$token = $tokens[$this->info["AffId"]];
		if(empty($token))
			mydie("Api token not exist. \n");
		$url = "http://api.tradedoubler.com/1.0/vouchers.json?token={$token}";
		$r = $this->oLinkFeed->GetHttpResult($url, $request);
		$content = $r['content'];
		// sometime the td api server input charater 7bf at start of the josn and 0 at end of the json
		// and the end of the ] is missing.
		// this maybe the api server wrong.
		// fix the json and wait td change it.
		// remove the 7bf and the 0 charater and add ].
		$content = trim($content);
		if (substr($content, 0, 3) == '7bf')
			$content = substr($content, 3);
		if (substr($content, -1, 1) == '0')
			$content = substr($content, 0, -1);
		$content = trim($content);
		if (substr($content, -1, 1) == '}')
			$content .= ']';
		// above code is the fixing json code.
		// delete when the server runs normal.
		$data = @json_decode($content);
		$links = array();
		foreach((array)$data as $v)
		{
			$link = array(
					"AffId" => $this->info["AffId"],
					"AffMerchantId" => $v->programId,
					"AffLinkId" => $v->id,
					"LinkName" => trim($v->title),
					"LinkDesc" => trim($v->description),
					"LinkStartDate" => parse_time_str(trim($v->startDate), 'millisecond', false),
					"LinkEndDate" => parse_time_str(trim($v->endDate), 'millisecond', false),
					"LinkPromoType" => 'COUPON',
					"LinkHtmlCode" => '',
					"LinkCode" => trim($v->code),
					"LinkOriginalUrl" => empty($v->landingUrl) ? '' : trim($v->landingUrl),
					"LinkImageUrl" => empty($v->logoPath) ? '' : trim($v->logoPath),
					"LinkAffUrl" => trim($v->defaultTrackUri),
					"DataSource" => $this->DataSource["feed"],
			);
			$link['LinkHtmlCode'] = create_link_htmlcode($link);
			if (empty($link['AffMerchantId']) || empty($link['LinkName']) || empty($link['AffLinkId']))
				continue;
			$arr_return["AffectedCount"] ++;
			$links [] = $link;
			if(sizeof($links) > 100)
			{
				$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);
				$links = array();
			}
		}
		if (sizeof($links) > 0)
			$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);
		echo sprintf("get coupon by api...%s link(s) found.\n", $arr_return['AffectedCount']);
		return $arr_return;
	}

	function GetAllLinksFromAffByMerID($merinfo)
	{
		// get banner & text links by page.
		$aff_mer_id = $merinfo["AffMerchantId"];
		$arr_return = array("AffectedCount" => 0,"UpdatedCount" => 0,);
		$request = array("AffId" => $this->info["AffId"],"method" => "post","postdata" => "",);
		$site_id = $this->getSiteId_simple();
		$searchTypes = array('ge', 'textLinks');
		$links = array();
		$this->oLinkFeed->LoginIntoAffService($this->info["AffId"],$this->info);
		list($nNumPerPage, $bHasNextPage, $nPageNo) = array(100, true, 1);
		while($bHasNextPage && $nPageNo < 50)
		{
			$request["method"] = "post";
			$url = "https://publisher.tradedoubler.com/pan/aGEList.action";
			$request["postdata"] = sprintf("programGEListParameterTransport.currentPage=%s&searchPerformed=true&searchType=ge&programGEListParameterTransport.programIdOrName=%s&programGEListParameterTransport.deepLinking=&programGEListParameterTransport.tariffStructure=&programGEListParameterTransport.siteId=%s&programGEListParameterTransport.orderBy=lastUpdated&programGEListParameterTransport.websiteStatusId=&programGEListParameterTransport.pageSize=%s&programAdvancedListParameterTransport.directAutoApprove=&programGEListParameterTransport.graphicalElementTypeId=&programGEListParameterTransport.specialConditionId=&programGEListParameterTransport.graphicalElementSize=&programGEListParameterTransport.width=&programGEListParameterTransport.height=&programGEListParameterTransport.lastUpdated=&programGEListParameterTransport.graphicalElementNameOrId=&programGEListParameterTransport.showGeGraphics=true&programAdvancedListParameterTransport.pfAdToolUnitName=&programAdvancedListParameterTransport.pfAdToolProductPerCell=&programAdvancedListParameterTransport.pfAdToolDescription=&programAdvancedListParameterTransport.pfTemplateTableRows=&programAdvancedListParameterTransport.pfTemplateTableColumns=&programAdvancedListParameterTransport.pfTemplateTableWidth=&programAdvancedListParameterTransport.pfTemplateTableHeight=&programAdvancedListParameterTransport.pfAdToolContentUnitRule=",
				$nPageNo, $aff_mer_id, $site_id, $nNumPerPage);
			$r = $this->oLinkFeed->GetHttpResult($url,$request);
			$content = $r["content"];
			preg_match_all('@onClick="hideGEIframe\((\d+)\);(.*?)<td colspan="14".*?>.*?</tr>@ms', $content, $chapters);
			foreach ((array)$chapters[0] as $key => $chapter)
			{
				$link = array(
						"AffId" => $this->info["AffId"],
						"AffMerchantId" => $aff_mer_id,
						"AffLinkId" => $chapters[1][$key],
						"LinkName" => '',
						"LinkDesc" => '',
						"LinkStartDate" => '0000-00-00',
						"LinkEndDate" => '0000-00-00',
						"LinkPromoType" => 'N/A',
						"LinkHtmlCode" => '',
						"LinkCode" => '',
						"LinkOriginalUrl" => '',
						"LinkImageUrl" => '',
						"LinkAffUrl" => '',
						"DataSource" => $this->DataSource["website"],
				);
				$link['LinkAffUrl'] = sprintf('http://clkuk.tradedoubler.com/click?p=%s&a=%s&g=%s', $aff_mer_id, $site_id, $link['AffLinkId']);
				if (preg_match('@<span id="geText\d+">(.*?)</span>@ms', $chapter, $g))
					$link['LinkName'] = html_entity_decode(strip_tags(trim($g[1])));
				if (preg_match('@<td>\s+(\d+/\d+/\d+)</td>@', $chapter, $g))
					$link['LinkStartDate'] = parse_time_str($g[1], 'd/m/Y', false);
				if (preg_match('@<td>\s+JPG/GIF</td>@i', $chapter))
				{
					$link['LinkImageUrl'] = sprintf('http://www.tradedoubler.com/pan/aGEGraphicalElementPreview.action?programId=%s&graphicalElementId=%s', $aff_mer_id, $link['AffLinkId']);
					if (preg_match('@<td colspan="14" style="z-index: 1; position: relative;">(.*?)</td>@ms', $chapter, $g))
					{
						$g[1] = str_replace('src="/pan/', 'src="http://www.tradedoubler.com/pan/', $g[1]);
						$link['LinkDesc'] = str_replace('<iframe  src="/', '<iframe  src="http://www.tradedoubler.com/', $g[1]);
					}
				}
				else if (preg_match('@<td>\s+Text links</td>@i', $chapter))
				{
					if (preg_match('@<td colspan="14" style="z-index: 1; position: relative;">(.*?)</td>@ms', $chapter, $g))
						$link['LinkName'] = trim(html_entity_decode(strip_tags($g[1])));
					$link['LinkPromoType'] = $this->oLinkFeed->getPromoTypeByLinkContent($link['LinkName']);
					$link['LinkHtmlCode'] = create_link_htmlcode($link);
				}
				else
					$link['LinkHtmlCode'] = create_link_htmlcode($link);
				$code = get_linkcode_by_text($link['LinkName']);
				if (!empty($code))
				{
					$link['LinkPromoType'] = 'COUPON';
					$link['LinkCode'] = $code;
				}
				if (empty($link['AffLinkId']) || empty($link['LinkName']))
					continue;
				$this->oLinkFeed->fixEnocding($this->info,$arr_one_link,"link");
				$links[] = $link;
				$arr_return["AffectedCount"] ++;
			}
			echo sprintf("get link by page...program:%s, page:%s, %s link(s) found.\n", $aff_mer_id, $nPageNo, count($links));
			if (count($links) > 0)
				$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($links);
			$links = array();
			$bHasNextPage = false;
			if (preg_match('@\&nbsp;\d+\&nbsp;(.*?)</div>@', $content, $g))
			{
				if (preg_match('@A HREF="@i', $g[1]))
					$bHasNextPage = true;
			}
			$nPageNo ++;
		}
		return $arr_return;
	}

	function GetProgramByPage()
	{
		$this->oLinkFeed->LoginIntoAffService($this->info["AffId"],$this->info);
		$arrCountrySite = $this->getSiteId();
		foreach($arrCountrySite as $conutry => $sites)
		{
			foreach($sites as $site_id => $contry_code)
			{
				$arr_result = $this->GetProgramBySiteId($site_id,$contry_code);
			}
		}
	}

	function GetProgramFromAff()
	{
		$check_date = date("Y-m-d H:i:s");
		echo "Craw Program start @ {$check_date}\r\n";
		$this->GetProgramByPage();
		$this->checkProgramOffline($this->info["AffId"], $check_date);
		echo "Craw Program end @ ".date("Y-m-d H:i:s")."\r\n";
	}

	function GetProgramBySiteId($site_id,$contry_code)
	{
		echo "\tGet Program by page start\r\n";
		$objProgram = new ProgramDb();
		$arr_prgm = array();
		$program_num = 0;

		$arr_return = array();
		$request = array("AffId" => $this->info["AffId"],"method" => "post","postdata" => "",);

		$nNumPerPage = 100;
		$nPageNo = 1;

		while(1)
		{
			if ($nPageNo == 1){
				$strUrl = "https://publisher.tradedoubler.com/pan/aProgramList.action";
				$request["method"] = "post";
				$request["postdata"] = "programGEListParameterTransport.currentPage=".$nPageNo."&searchPerformed=true&searchType=prog&programGEListParameterTransport.programIdOrName=&programGEListParameterTransport.deepLinking=&programGEListParameterTransport.tariffStructure=&programGEListParameterTransport.siteId=" . $site_id . "&programGEListParameterTransport.orderBy=statusId&programAdvancedListParameterTransport.websiteStatusId=&programGEListParameterTransport.pageSize=" . $nNumPerPage . "&programAdvancedListParameterTransport.directAutoApprove=&programAdvancedListParameterTransport.mobile=&programGEListParameterTransport.graphicalElementTypeId=&programGEListParameterTransport.graphicalElementSize=&programGEListParameterTransport.width=&programGEListParameterTransport.height=&programGEListParameterTransport.lastUpdated=&programGEListParameterTransport.graphicalElementNameOrId=&programGEListParameterTransport.showGeGraphics=true&programAdvancedListParameterTransport.pfAdToolUnitName=&programAdvancedListParameterTransport.pfAdToolProductPerCell=&programAdvancedListParameterTransport.pfAdToolDescription=&programAdvancedListParameterTransport.pfTemplateTableRows=&programAdvancedListParameterTransport.pfTemplateTableColumns=&programAdvancedListParameterTransport.pfTemplateTableWidth=&programAdvancedListParameterTransport.pfTemplateTableHeight=&programAdvancedListParameterTransport.pfAdToolContentUnitRule=";
				$this->oLinkFeed->GetHttpResult($strUrl,$request);
			}
			$strUrl = "https://publisher.tradedoubler.com/pan/aProgramList.action?categoryChoosen=false&programGEListParameterTransport.currentPage=".$nPageNo."&programGEListParameterTransport.pageSize=".$nNumPerPage."&programGEListParameterTransport.pageStreamValue=true";

			$request["postdata"] = "";
			$request["method"] = "get";

			$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
			$result = $r["content"];

			//parse HTML
			$strLineStart = 'showPopBox(event, getProgramCodeAffiliate';
			$nLineStart = 0;
			$bStart = 1;
			while(1)
			{
				$nLineStart = stripos($result,$strLineStart,$nLineStart);
				if($nLineStart === false && $bStart == 1) break 2;
				if($nLineStart === false) break;
				$bStart = 0;

				$strMerID = $this->oLinkFeed->ParseStringBy2Tag($result, 'getProgramCodeAffiliate(', ',', $nLineStart);
				if($strMerID === false) break;
				$strMerID = trim($strMerID);

				//name
				$strMerName = $this->oLinkFeed->ParseStringBy2Tag($result, ">","</a>", $nLineStart);
				if($strMerName === false) break;
				$strMerName = html_entity_decode(trim($strMerName));
				
				$CategoryExt = $this->oLinkFeed->ParseStringBy2Tag($result, '<td>', '</td>', $nLineStart);
				
				$arr_pattern = array();
				for($i=0;$i<8;$i++) $arr_pattern[] = "<td>";
				$EPC90d = $this->oLinkFeed->ParseStringBy2Tag($result,$arr_pattern, '</td>', $nLineStart);
				if($EPC90d === false) break;
				$EPC90d = trim(html_entity_decode(strip_tags($EPC90d)));
				if($EPC90d == "") $EPC90d = "";
				
				$EPCDefault = $this->oLinkFeed->ParseStringBy2Tag($result,'<td>','</td>', $nLineStart);
				if($EPCDefault === false) break;
				$EPCDefault = trim(html_entity_decode(strip_tags($EPCDefault)));
				if($EPCDefault == "") $EPCDefault = "";
				$MobileFriendly = trim(strtoupper($this->oLinkFeed->ParseStringBy2Tag($result, array('<td>','<td>'), '</td>', $nLineStart)));
				if ($MobileFriendly != 'YES' && $MobileFriendly != 'NO')
					$MobileFriendly = 'UNKNOWN';
				$strStatus = $this->oLinkFeed->ParseStringBy2Tag($result, '<td>', '</td>', $nLineStart);
				if($strStatus === false) break;
				$strStatus = trim(strip_tags($strStatus));
				if(0 && $contry_code == "DE")
				{
					//warning: im not very sure for those de status ...
					if(stripos($strStatus,'Akzeptiert') !== false) $strStatus = 'approval';
					elseif(stripos($strStatus,'Unter Beobachtung') !== false) $strStatus = 'pending';
					elseif(stripos($strStatus,'Beendet') !== false) $strStatus = 'declined';
					elseif(stripos($strStatus,'In Bearbeitung') !== false) $strStatus = 'pending';
					elseif(stripos($strStatus,'Programmbewerbung') !== false) $strStatus = 'not apply';
					elseif(stripos($strStatus,'Abgelehnt') !== false) $strStatus = 'declined';
					else mydie("die: Unknown Status: $strStatus <br>\n");
				}
				else
				{
					if(stripos($strStatus,'Accepted') !== false) $strStatus = 'approval';
					elseif(stripos($strStatus,'Under Consideration') !== false) $strStatus = 'pending';
					elseif(stripos($strStatus,'Denied') !== false) $strStatus = 'declined';
					elseif(stripos($strStatus,'On Hold') !== false) $strStatus = 'siteclosed';
					elseif(stripos($strStatus,'Apply') !== false) $strStatus = 'not apply';
					elseif(stripos($strStatus,'Ended') !== false) $strStatus = 'declined';
					else mydie("die: Unknown Status: $strStatus <br>\n");
				}

				if(stripos($strMerName,'Closed') !== false) $strStatus = 'siteclosed';
				// when closing get the closing time and set to siteclosed when the time is less than now
				elseif(stripos($strMerName,'closing') !== false || stripos($strMerName,'pausing') !== false)
				{
					if (preg_match('@\d\d\.\d\d\.\d\d\d\d@', $strMerName, $g))
					{
						if (strtotime($g[1]) < time())
							$strStatus = 'siteclosed';
					}
					if (preg_match('@(\d+)\/(\d+)\/(\d\d)\]@', $strMerName, $g))
					{
						if (strtotime(sprintf("20%s-%s-%s", $g[3], $g[2], $g[1])) < time())
							$strStatus = 'siteclosed';
					}
					if (preg_match('@(\d+)\/(\d+)\/(\d\d\d\d)\]@', $strMerName, $g))
					{
						if (strtotime(sprintf("%s-%s-%s", $g[3], $g[2], $g[1])) < time())
							$strStatus = 'siteclosed';
					}
					echo $strMerName."---".$strStatus."\n";
				}
				elseif(stripos($strMerName,'paused') !== false) $strStatus = 'siteclosed';
				elseif(stripos($strMerName,'set to pause') !== false) $strStatus = 'siteclosed';
				if($strStatus == 'approval'){
					$Partnership = "Active";
					$StatusInAff = "Active";
				}elseif($strStatus == 'pending'){
					$Partnership = "Pending";
					$StatusInAff = "Active";
				}elseif($strStatus == 'declined'){
					$Partnership = "Declined";
					$StatusInAff = "Active";
				}elseif($strStatus == 'not apply'){
					$Partnership = "NoPartnership";
					$StatusInAff = "Active";
				}else{
					$Partnership = "NoPartnership";
					$StatusInAff = "Offline";
				}
				$request["method"] = "get";
				$request["postdata"] = "";
				$prgm_url = "https://publisher.tradedoubler.com/pan/aProgramTextRead.action?programId={$strMerID}&affiliateId={$site_id}";
				$prgm_arr = $this->oLinkFeed->GetHttpResult($prgm_url, $request);
				$prgm_detail = $prgm_arr["content"];
				$desc = "<div>" . trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail,'<div id="publisher-body">', '<div id="publisher-footer">'));
				$desc = preg_replace("/[\\r|\\n|\\r\\n|\\t]/is", '', $desc);
				$desc = preg_replace('/<([a-z]+?)\s+?.*?>/i','<$1>', $desc);

				preg_match_all('/<([a-z]+?)>/i', $desc, $res_s);
				preg_match_all('/<\/([a-z]+?)>/i', $desc, $res_e);

				//egg's pain
				$tags_arr = array();
				foreach($res_s[1] as $v){
					if(strtolower($v) != "br"){
						if(isset($tags_arr[$v])){
							$tags_arr[$v] += 1;
						}else{
							$tags_arr[$v] = 1;
						}
					}
				}
				foreach($res_e[1] as $v){
					if(strtolower($v) != "br" && isset($tags_arr[$v])){
						$tags_arr[$v] -=1;
					}
				}
				foreach($tags_arr as $k => $v){
					for($i = 0; $i < $v; $i++){
						$desc .= "</$k>";
					}
				}

				$overview_url = "https://publisher.tradedoubler.com/pan/aProgramInfoApplyRead.action?programId={$strMerID}&affiliateId={$site_id}";
				$overview_arr = $this->oLinkFeed->GetHttpResult($overview_url, $request);
				$overview_detail = $overview_arr["content"];
				$Homepage = trim($this->oLinkFeed->ParseStringBy2Tag($overview_detail, array('Visit the site', '<a href="'), '"'));
				$CommissionExt = trim($this->oLinkFeed->ParseStringBy2Tag($overview_detail, '<b>Commission structure</b>', '</table>')) . "</table>";

				$SupportDeepUrl = strtoupper(trim($this->oLinkFeed->ParseStringBy2Tag($overview_detail, array('Deep linking', '<td nowrap="nowrap">'), '</td>')));
				if($SupportDeepUrl == "YES"){
					$SupportDeepUrl = "YES";
				}elseif($SupportDeepUrl == "NO"){
					$SupportDeepUrl = "NO";
				}else{
					$SupportDeepUrl = "UNKNOWN";
				}

				$links_url = "https://publisher.tradedoubler.com/pan/aProgramInfoLinksRead.action?programId={$strMerID}&affiliateId={$site_id}";
				$links_arr = $this->oLinkFeed->GetHttpResult($links_url, $request);
				$links_detail = $links_arr["content"];

				$g_id = intval($this->oLinkFeed->ParseStringBy2Tag($links_detail, array('/pan/aInfoCenterLinkInfo.action', 'geId='), '&'));
				$AffDefaultUrl = "";
				if($g_id > 0){
					$AffDefaultUrl = "http://clkuk.tradedoubler.com/click?p({$strMerID})a({$site_id})g({$g_id})";
				}

				/*if($site_id == "1550868"){
					$TargetCountryExt = "UK";
				}elseif($site_id == "1470197"){
					$TargetCountryExt = "US";
				}elseif($site_id == "1634367"){
					$TargetCountryExt = "IE";
				}elseif($site_id == "1781705"){
					$TargetCountryExt = "DE";
				}elseif($site_id == "2489540"){
					$TargetCountryExt = "AT";
				}else{
					break;
				}*/
				$TargetCountryExt = $contry_code;
				
				//find homepage	
				if($tmp_url = $this->oLinkFeed->findFinalUrl($Homepage)){
					$Homepage = $tmp_url;
				}
				
				$arr_prgm[$strMerID] = array(
					"Name" => addslashes($strMerName),
					"AffId" => $this->info["AffId"],
					//"Contacts" => $Contacts,
					"TargetCountryExt" => $TargetCountryExt,
					"IdInAff" => $strMerID,
					//"JoinDate" => date("Y-m-d H:i:s", strtotime($row["joinDate"])),
					"StatusInAffRemark" => $strStatus,
					"StatusInAff" => $StatusInAff,						//'Active','TempOffline','Offline'
					"Partnership" => $Partnership,						//'NoPartnership','Active','Pending','Declined','Expired','WeDeclined'
					"Description" => addslashes($desc),
					"Homepage" => $Homepage,
					"EPCDefault" => preg_replace("/[^0-9.]/", "", $EPCDefault),
					"EPC90d" => preg_replace("/[^0-9.]/", "", $EPC90d),
					//"TermAndCondition" => addslashes($TermAndCondition),
					"SupportDeepUrl" => $SupportDeepUrl,
					"LastUpdateTime" => date("Y-m-d H:i:s"),
					"DetailPage" => $prgm_url,
					"MobileFriendly" => $MobileFriendly,
					"AffDefaultUrl" => addslashes($AffDefaultUrl),
					"CommissionExt" => addslashes($CommissionExt),
				);
				$program_num++;
				if(count($arr_prgm) >= 100){
					$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
					//$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
					$arr_prgm = array();
				}
			}
			$nPageNo++;
			
			if(count($arr_prgm)){
				$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
				//$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
				$arr_prgm = array();
			}
		}
		echo "\tGet Program by page end\r\n";
		if($program_num < 10){
			mydie("die: program count < 10, please check program.\n");
		}
		echo "\tUpdate ({$program_num}) program.\r\n";
		echo "\tSet program country int.\r\n";
		$objProgram->setCountryInt($this->info["AffId"]);
	}

	function checkProgramOffline($AffId, $check_date){
		$objProgram = new ProgramDb();
		$prgm = array();
		$prgm = $objProgram->getNotUpdateProgram($this->info["AffId"], $check_date);
		
		if(count($prgm) > 30){
			mydie("die: too many offline program (".count($prgm).").\n");
		}else{			
			$objProgram->setProgramOffline($this->info["AffId"], $prgm);
			echo "\tSet (".count($prgm).") offline program.\r\n";
		}
	}
}

