<?php
class LinkFeed_Webgains //for 14,13,18,34,208
{
	function GetMerchantListFromAff()
	{
		$arr_return = array("AffectedCount" => 0,"UpdatedCount" => 0,);
		return $arr_return;
		//step 1,login
		$this->oLinkFeed->LoginIntoAffService($this->info["AffId"],$this->info);
		$this->SwitchWebgainsToSelectWebSite();

		//step 2,get all exists merchant
		$arrAllExistsMerchants = $this->oLinkFeed->GetAllExistsAffMerIDForCheckByAffID($this->info["AffId"]);

		$request = array("AffId" => $this->info["AffId"],"method" => "post","postdata" => "",);

		print "<br>\n Get Merchant List   <br>\n";
		$request["postdata"] = "action=list&updatenumperscreen=1&sortby=liveDate&sortdir=desc&numperpage=0";
		$strUrl = "http://us.webgains.com/affiliates/program.html";
		$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
		$result = $r["content"];
		
		//parse HTML
		$strLineStart = '<td style="text-align:left;"><a href="/affiliates/program.html?action=view&programID=';

		$nLineStart = 0;
		while ($nLineStart >= 0){
			//print "Process $Cnt  ";
			$nLineStart = stripos($result, $strLineStart, $nLineStart);
			if ($nLineStart === false) {
				break;
			}
			
			// ID 	Name 	EPC 	Status
			//ID
			$strMerID = $this->oLinkFeed->ParseStringBy2Tag($result, 'programID=', '"', $nLineStart);
			if($strMerID === false) continue;
			$strMerID = trim($strMerID);

			//name
			$strMerName = $this->oLinkFeed->ParseStringBy2Tag($result, array('<span style', '">'), '</span>', $nLineStart);
			if($strMerName === false) mydie("die: parse merchant name failed.");
			$strMerName = trim($strMerName);
			$strMerName = html_entity_decode($strMerName);

			$arr_pattern = array();
			for($i=0;$i<5;$i++) $arr_pattern[] = "<td";
			$arr_pattern[] = '>';

			//EPC
			$strEPC = $this->oLinkFeed->ParseStringBy2Tag($result,$arr_pattern,'</td>',$nLineStart);
			$strEPC = trim($strEPC);
			if (strpos($strEPC, 'n/a') !== false) $strEPC = 0;
			else $strEPC = html_entity_decode($strEPC);

			//Status
			$strStatus_block = $this->oLinkFeed->ParseStringBy2Tag($result,'<td style="width:60px;" nowrap>', '</td>', $nLineStart);
			$strStatus = trim(strip_tags($strStatus_block));

			if (stripos($strStatus, 'LEAVE') !== false) $strStatus = 'approval';
			elseif (stripos($strStatus, 'JOIN') !== false) $strStatus = 'not apply';
			elseif (stripos($strStatus, 'MORE') !== false) $strStatus = 'not apply';
			elseif (stripos($strStatus, 'Suspended') !== false) $strStatus = 'siteclosed';
			elseif (stripos($strStatus, 'REAPPLY') !== false) $strStatus = 'declined';
			elseif (stripos($strStatus, 'Application under consideration') !== false) $strStatus = 'pending';
			elseif (stripos($strStatus, 'Membership under review') !== false) $strStatus = 'pending';
			else mydie("die: unknown Status: $strStatus \n");
			
			$arr_return["AffectedCount"] ++;
			$arr_update = array(
				"AffMerchantId" => $strMerID,
				"AffId" => $this->info["AffId"],
				"MerchantName" => html_entity_decode($strMerName),
				"MerchantEPC30d" => "-1",
				"MerchantEPC" => $strEPC,
				"MerchantStatus" => $strStatus,
				"MerchantRemark" => "",
			);
			$this->oLinkFeed->fixEnocding($this->info,$arr_update,"merchant");
			if($this->oLinkFeed->UpdateMerchantToDB($arr_update,$arrAllExistsMerchants)) $arr_return["UpdatedCount"] ++;
		}
		
		$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateAllExistsAffMerIDButCannotFetched($this->info["AffId"], $arrAllExistsMerchants);
		return $arr_return;
	}

	function getCouponFeed()
	{
		$arr_return = array("AffectedCount" => 0,"UpdatedCount" => 0,"Detail" => array(),);
		$request = array("AffId" => $this->info["AffId"],"method" => "post","postdata" => "",);
		
		$title = 'program,start date,expiry date,voucher code,description,discount,destination url,commission';
		//step 2, download banner links
		$cache_file = $this->oLinkFeed->fileCacheGetFilePath($this->info["AffId"],"feed.dat","cache_feed");
		if(!$this->oLinkFeed->fileCacheIsCached($cache_file))
		{
			//step 1,login
			$this->oLinkFeed->LoginIntoAffService($this->info["AffId"],$this->info);
			$this->SwitchWebgainsToSelectWebSite();
			
			$strUrl = 'http://us.webgains.com/affiliates/vouchers.html?raw=downloadCSV';
			$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
			$result = $r["content"];
			
			if(stripos($result,$title) === false)
			{
				print_r($r);
				mydie("die: get feed failed, title not found \n");
			}
			
			$this->oLinkFeed->fileCachePut($cache_file,$result);
		}
		if(!file_exists($cache_file)) return $arr_return;
		
		$all_merchant_name = $this->oLinkFeed->getAllAffMerchant($this->info["AffId"],"","MerchantName");
		
		//Open CSV File
		$arr_title = explode(",",$title);
		foreach($arr_title as $i => $v) $arr_title[$i] = trim($v,'"');
		$col_count = sizeof($arr_title);
		
		$fhandle = fopen($cache_file, 'r');
		$arrToUpdate = array();
		while($line = fgetcsv($fhandle, 50000))
		{
			//program,start date,expiry date,voucher code,description,discount,destination url,commission
			if($line[0] == '' || $line[0] == 'program') continue;
			if(sizeof($line) != $col_count + 1)
			{
				echo "warning: invalid line found: " . implode(",",$line) . "\n";
				continue;
			}
			
			$row = array();
			foreach($arr_title as $i => $title) $row[$title] = $line[$i];
			//
			$aff_mer_name  = trim($row["program"]);
			if($aff_mer_name == '') continue;

			$start_date  = trim($row["start date"]);
			$end_date  = trim($row["expiry date"]);
			$couponcode = trim($row["voucher code"]);
			$link_desc  = trim($row["description"]);
			$link_name = $strDiscount = trim($row["discount"]);
			$html_code = trim($row["destination url"]);
			
			//http://track.webgains.com/click.html?wgcampaignid=48215&wgprogramid=867,7%,
			if(preg_match("/wgcampaignid=([^&]*)&wgprogramid=([^&]*)/i",$html_code,$matches))
			{
				$link_id = "c_" . $matches[1] . "_" . $matches[2];
				if($couponcode) $link_id .= "_" . $couponcode;
				//if($strDiscount) $link_id .= "_" . $strDiscount;
			}
			else mydie("die: unknown destination url format: $html_code \n");
			
			if(!isset($all_merchant_name[$aff_mer_name])) continue;
			$aff_mer_id = $all_merchant_name[$aff_mer_name]["AffMerchantId"];
			
			if ($strDiscount != '') $link_desc  .= '. Discount Detail: ' . $strDiscount;
			if ($couponcode != '') $link_desc  .= '. Voucher Code: ' . $couponcode;

			$promo_type = 'coupon';

			$arr_one_link = array(
				"AffId" => $this->info["AffId"],
				"AffMerchantId" => $aff_mer_id,
				"AffLinkId" => $link_id,
				"LinkName" => $link_name,
				"LinkDesc" => $link_desc,
				"LinkStartDate" => $start_date,
				"LinkEndDate" => $end_date,
				"LinkPromoType" => $promo_type,
				"LinkHtmlCode" => $html_code,
				"LinkOriginalUrl" => "",
				"LinkImageUrl" => "",
				"LinkAffUrl" => $html_code,
				"DataSource" => $this->DataSource["feed"],
			);

			$this->oLinkFeed->fixEnocding($this->info,$arr_one_link,"feed");
			$arrToUpdate[] = $arr_one_link;
			$arr_return["AffectedCount"] ++;
			if(!isset($arr_return["Detail"][$aff_mer_id]["AffectedCount"])) $arr_return["Detail"][$aff_mer_id]["AffectedCount"] = 0;
			$arr_return["Detail"][$aff_mer_id]["AffectedCount"] ++;

			if(sizeof($arrToUpdate) > 100)
			{
				$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($arrToUpdate);
				$arrToUpdate = array();
			}
		}
		fclose($fhandle);
		
		if(sizeof($arrToUpdate) > 0)
		{
			$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($arrToUpdate);
			$arrToUpdate = array();
		}
		return $arr_return;
	}

	function GetAllLinksFromAffByMerID($merinfo,$newonly=true)
	{
		$aff_id = $this->info["AffId"];
		$AffMerchantId = $merinfo["AffMerchantId"];
		$strUKSiteID = $this->getSiteId();
		$arr_return = array("AffectedCount" => 0, "UpdatedCount" => 0, );
		$request = array("AffId" => $this->info["AffId"], "method" => "post", "postdata" => "", );
		$this->oLinkFeed->LoginIntoAffService($this->info["AffId"],$this->info);
		$this->SwitchWebgainsToSelectWebSite();

		$existing_link_ids = array();
		if($newonly)
		{
			//to speed up for link share
			$existing_link_ids = $this->oLinkFeed->getAllLinksByAffAndMerchant($this->info["AffId"],$AffMerchantId);
		}
		
		//step 2, download links
		$nNumPerPage = 15;
		$nTotalLinkCount = 0;
		$bHasNextPage = true;
		$nPageNo = 1;
		$arrToUpdate = array();
		
		while($bHasNextPage)
		{
			if ($nPageNo == 1){
				$strUrl = "http://us.webgains.com/affiliates/link.html?action=submitsearch&newsearch&programid=$AffMerchantId";
			}
			else{
				$strUrl = "http://us.webgains.com/affiliates/link.html?action=submitsearch&paginate=1&startnum=".(($nPageNo - 1) * $nNumPerPage + 1)."&programid=$AffMerchantId";
			}
			
			$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
			$result = $r["content"];

			if($this->debug) print "Get links Data : Page - $nPageNo <br>\n";

			if ($nPageNo == 1){
				//When open the first page. Try get total links count.
				$nLineStart = 0;
				$nTotalLinkCount = intval(trim($this->oLinkFeed->ParseStringBy2Tag($result, array('records', 'of'), '<br />', $nLineStart)));
				if($this->debug) print "nTotalLinkCount $nTotalLinkCount  <br>\n";
			}

			$strLineStart = 'style="text-decoration:none">+</a>';
			$nLineStart = 0;
			while ($nLineStart >= 0)
			{
				$nLineStart = stripos($result, $strLineStart, $nLineStart);
				if ($nLineStart === false) break;

				$aff_mer_name = $this->oLinkFeed->ParseStringBy2Tag($result, '<td>', '</td>', $nLineStart);
				if ($aff_mer_name === false) break;
				$aff_mer_name = trim($aff_mer_name);

				//Link Type
				$link_type= $this->oLinkFeed->ParseStringBy2Tag($result, '<td>', '</td>', $nLineStart);
				if ($link_type === false) break;
				$link_type = trim($link_type);

				//get Link ID
				$link_id = $this->oLinkFeed->ParseStringBy2Tag($result, '/affiliates/link.html?action=view&linkID=', '">view</a>', $nLineStart);
				if ($link_id === false) break;
				$link_id = trim($link_id);

				if($newonly && isset($existing_link_ids[$link_id]))
				{
					$arr_return["AffectedCount"] ++;
					continue;
				}
				
				//Open Detail Page
				$strDetailUrl = 'http://us.webgains.com/affiliates/link.html?action=view&linkID='.$link_id;
				$r = $this->oLinkFeed->GetHttpResult($strDetailUrl,$request);
				$Detailresult = $r["content"];
				if($r["code"] != 200)
				{
					print "warning: get link detail page failed<br>\n";
					continue;
				}
				
				//parse detail page
				$nDetailLineStart = 0;
				$link_name = $this->oLinkFeed->ParseStringBy2Tag($Detailresult, array('<b>Name</b>', '<td>'), '</td>', $nDetailLineStart);
				//if($link_name === false) break;
				if($link_name === false) mydie("die: link_name not found\n");
				$link_name = trim($link_name);

				//$original_url = $this->oLinkFeed->ParseStringBy2Tag($Detailresult, '<b>Target</b>', '<td>', '</td>', $nDetailLineStart);
				//$original_url = trim($original_url);
				//if ($original_url === false) break;

				$link_src_lastupdate = $this->oLinkFeed->ParseStringBy2Tag($Detailresult, array('<b>Last Modified</b>', '<td>'), '</td>', $nDetailLineStart);
				if($this->debug) print "link_src_lastupdate $link_src_lastupdate  <br>\n";
				if ($link_src_lastupdate === false) break;
				$link_src_lastupdate = date('Y-m-d H:i:s', strtotime(trim($link_src_lastupdate)));
				if($this->debug) print "link_src_lastupdate $link_src_lastupdate  <br>\n";

				if (trim($link_type) == 'graphic')
					$html_code = '<a href="http://track.webgains.com/click.html?wglinkid='.$link_id.'&wgcampaignid='.$strUKSiteID.'"><img border=0 src="http://track.webgains.com/link.html?wglinkid='.$link_id.'&wgcampaignid='.$strUKSiteID.'"/></a>';
				else
					$html_code = '<iframe height="500" frameborder="0" width="700" src="http://us.webgains.com/link_preview.html?js=1&wglinkid='.$link_id.'&wgcampaignid='.$strUKSiteID.'"></iframe>';
				$start_date = date("Y-m-d");
				$end_date = '0000-00-00';
				$link_desc = $link_name;

				$promo_type = $this->oLinkFeed->getPromoTypeByLinkContent($link_desc);
				if($this->debug) print "promo_type $promo_type  <br>\n";

				$arr_one_link = array(
					"AffId" => $merinfo["AffId"],
					"AffMerchantId" => $merinfo["AffMerchantId"],
					"AffLinkId" => $link_id,
					"LinkName" => html_entity_decode($link_name),
					"LinkDesc" => html_entity_decode($link_desc),
					"LinkStartDate" => $start_date,
					"LinkEndDate" => $end_date,
					"LinkPromoType" => $promo_type,
					"LinkHtmlCode" => $html_code,
					"LinkOriginalUrl" => "",
					"LinkImageUrl" => "",
					"LinkAffUrl" => 'http://track.webgains.com/click.html?wglinkid='.$link_id.'&wgcampaignid='.$strUKSiteID,
					"DataSource" => $this->DataSource["website"],
				);
				
				$this->oLinkFeed->fixEnocding($this->info,$arr_one_link,"link");
				$arrToUpdate[] = $arr_one_link;
				$arr_return["AffectedCount"] ++;
				//exit;
			}//page

			if(sizeof($arrToUpdate) > 0)
			{
				$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($arrToUpdate);
				$arrToUpdate = array();
			}
			
			//Check if have next page;
			/// 
			if($this->debug) print " ($nTotalLinkCount > ($nNumPerPage * $nPageNo))  <br>\n";
			if ($nTotalLinkCount > ($nNumPerPage * $nPageNo)){
				$bHasNextPage = true;
				if($this->debug) print " Have NEXT PAGE  <br>\n";
			}
			else{
				$bHasNextPage = false;
				if($this->debug) print " NO NEXT PAGE  <br>\n";
			}
			
			if ($bHasNextPage){
				$nPageNo++;
			}
		}//get links per page

		//step 3, get voucher code
		$strUrl = "http://us.webgains.com/affiliates/vouchers.html?action=list&pid=$AffMerchantId";
		$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
		$result = $r["content"];

		if($this->debug) print "Get Voucher Code List  <br>\n";

		$nLineStart = 0;
		$aff_mer_name = $this->oLinkFeed->ParseStringBy2Tag($result, 'Generic voucher codes for program: ', '</h1>', $nLineStart);
		if($this->debug) print "aff_mer_name $aff_mer_name  <br>\n";
		if ($aff_mer_name !== false)
		{
			$strLineStart = '<tr>';
			while ($nLineStart >= 0){
				$nLineStart = stripos($result, $strLineStart, $nLineStart);
				if ($nLineStart === false) break;

				$voucher_code = $this->oLinkFeed->ParseStringBy2Tag($result, '<td>', '</td>', $nLineStart);
				if($this->debug) print "voucher_code $voucher_code  <br>\n";
				if ($voucher_code === false) break;

				$link_name = $this->oLinkFeed->ParseStringBy2Tag($result, '<td>', '</td>', $nLineStart);
				if($this->debug) print "link_name $link_name  <br>\n";
				if ($link_name === false) break;

				$link_desc = $this->oLinkFeed->ParseStringBy2Tag($result, '<td>', '</td>', $nLineStart);
				if($this->debug) print "link_desc $link_desc  <br>\n";
				if ($link_desc === false) break;

				$original_url = $this->oLinkFeed->ParseStringBy2Tag($result, '<td>', '</td>', $nLineStart);
				if($this->debug) print "original_url $original_url  <br>\n";
				//if ($original_url === false) break;

				$start_date = $this->oLinkFeed->ParseStringBy2Tag($result, '<td>', '</td>', $nLineStart);
				if($this->debug) print "start_date $start_date  <br>\n";
				if ($start_date === false) break;

				$end_date = $this->oLinkFeed->ParseStringBy2Tag($result, '<td>', '</td>', $nLineStart);
				if($this->debug) print "end_date $end_date  <br>\n";
				if ($end_date === false) break;

				//get Link ID
				$link_id = 'voucher_'.$voucher_code.'_'.$link_name;
				$promo_type = 'coupon';
				//$html_code = 'Voucher Code: '.$voucher_code.'. Please just set URL as blank. (using the default url of merchant.). Please note do not add the voucher code if it shows: "not to be used by affiliates" or "Offline code" ';
				$html_code = sprintf('<a href="http://track.webgains.com/click.html?wgcampaignid=%s&wgprogramid=%s&wgtarget=%s">%s</a>', $strUKSiteID, $merinfo['AffMerchantId'], $original_url, $link_name);
				$arr_one_link = array(
						"AffId" => $merinfo["AffId"],
						"AffMerchantId" => $merinfo["AffMerchantId"],
						"AffLinkId" => $link_id,
						"LinkName" => html_entity_decode($link_name),
						"LinkDesc" => html_entity_decode($link_desc),
						"LinkStartDate" => $start_date,
						"LinkEndDate" => $end_date,
						"LinkPromoType" => $promo_type,
						"LinkHtmlCode" => $html_code,
						"LinkCode" => $voucher_code,
						"LinkOriginalUrl" => "",
						"LinkImageUrl" => "",
						"LinkAffUrl" => sprintf('http://track.webgains.com/click.html?wgcampaignid=%s&wgprogramid=%s&wgtarget=%s', $strUKSiteID, $merinfo['AffMerchantId'], $original_url),
						"DataSource" => $this->DataSource["website"],
					);
				$this->oLinkFeed->fixEnocding($this->info,$arr_one_link,"link");
				$arrToUpdate[] = $arr_one_link;
				$arr_return["AffectedCount"] ++;
			}
		}
		if(sizeof($arrToUpdate) > 0)
		{
			$arr_return["UpdatedCount"] += $this->oLinkFeed->UpdateLinkToDB($arrToUpdate);
			$arrToUpdate = array();
		}
		return $arr_return;
	}

	function getSiteId()
	{
		switch($this->info["AffId"])
		{
			case 13: // UK
				return '48214';
			case 14: // US
				return '48215';
			case 18: // IE
				return '55618';
			case 34: // DE
				return '73616';
			case 208: // FR
				return '106671';
			default:
				mydie("die:Wrong AffID for LinkFeed_Webgains\n");
		}
	}
	
	function SwitchWebgainsToSelectWebSite($checkonly=false)
	{
		$strUKSiteID = $this->getSiteId();
		if(isset($this->oLinkFeed->WebgainsCurrentSite) && $this->oLinkFeed->WebgainsCurrentSite == $strUKSiteID) return true;

		$request = array(
			"AffId" => $this->info["AffId"],
			"method" => "post",
			"postdata" => "", 
		);
		
		$strUrl = "http://us.webgains.com/affiliates/index.html";
		$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
		$result = $r["content"];
		
		$nLineStart = 0;
		$strSiteSelected = trim($this->oLinkFeed->ParseStringBy2Tag($result, 'value="'.$strUKSiteID.'"', '>', $nLineStart));
		if (strtolower($strSiteSelected) == 'selected')
		{
			//is UK Site now, do nothing
			if($checkonly) echo "double check site switch result: ok! \n";
			else echo "is $strUKSiteID Site now, do nothing <br> \n";
			
			$this->oLinkFeed->WebgainsCurrentSite = $strUKSiteID;
			return true;
		}
		elseif($checkonly) mydie("die: SwitchWebgainsToSelectWebSite failed.\n");
		else{
			if($this->debug) echo "is NOT $strUKSiteID site now. do switch <br> \n";
			//is NOT $strUKSiteID site now. do switch
			$nLineStart = 0;
			$strUrl = 'http://us.webgains.com/affiliates/index.html';
			$param_globalaction = $this->oLinkFeed->ParseStringBy2Tag($result, array('action="http://us.webgains.com/affiliates/index.html"', 'name="globalaction" value="'), '" />', $nLineStart);
			$param___utma = $this->oLinkFeed->ParseStringBy2Tag($result, 'name="__utma" value="', '" />', $nLineStart);
			$param___utmz = $this->oLinkFeed->ParseStringBy2Tag($result, 'name="__utmz" value="', '" />', $nLineStart);
			$param___utmv = $this->oLinkFeed->ParseStringBy2Tag($result, 'name="__utmv" value="', '" />', $nLineStart);
			$param___utmc = $this->oLinkFeed->ParseStringBy2Tag($result, 'name="__utmc" value="', '" />', $nLineStart);
			$param___utmb = $this->oLinkFeed->ParseStringBy2Tag($result, 'name="__utmb" value="', '" />', $nLineStart);
			$param_wgsite = $this->oLinkFeed->ParseStringBy2Tag($result, 'name="wgsite" value="', '" />', $nLineStart);
			$param_WTSESSID = $this->oLinkFeed->ParseStringBy2Tag($result, 'name="WTSESSID" value="', '" />', $nLineStart);
			$param_usertype = $this->oLinkFeed->ParseStringBy2Tag($result, 'name="usertype" value="', '" />', $nLineStart);
			$param_campaignswitchid = $strUKSiteID;

			$request["postdata"] = 'globalaction='.urlencode($param_globalaction).'&__utma='.urlencode($param___utma).'&__utmz='.urlencode($param___utmz).'&__utmv='.urlencode($param___utmv).'&__utmc='.urlencode($param___utmc).'&__utmb='.urlencode($param___utmb).'&wgsite='.urlencode($param_wgsite).'&WTSESSID='.urlencode($param_WTSESSID).'&usertype='.urlencode($param_usertype).'&campaignswitchid='.urlencode($param_campaignswitchid);

			$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
			return $this->SwitchWebgainsToSelectWebSite(true);
		}
	}
	
	function SwitchWebgainsToSelectWebSiteNew($checkonly=false, $times = 3)
	{
		$strUKSiteID = $this->getSiteId();
		if(isset($this->oLinkFeed->WebgainsCurrentSite) && $this->oLinkFeed->WebgainsCurrentSite == $strUKSiteID) return true;
		
		$request = array(
			"AffId" => $this->info["AffId"],
			"method" => "post",
			"postdata" => "globalaction=switchcampaign&campaignswitchid=$strUKSiteID", 
		);		

		$strUrl = "http://www.webgains.com/publisher/$strUKSiteID";
		$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
		$result = $r["content"];
		
		$strSiteSelected = trim($this->oLinkFeed->ParseStringBy2Tag($result, 'currentCampaign:', ','));
		if (intval($strSiteSelected) == $strUKSiteID)
		{
			//is UK Site now, do nothing
			if($checkonly) echo "double check site switch result: ok! \n";
			else echo "is $strUKSiteID Site now, do nothing <br> \n";
			
			$this->oLinkFeed->WebgainsCurrentSite = $strUKSiteID;
			return true;
		}
		elseif($checkonly) mydie("die: SwitchWebgainsToSelectWebSite failed.\n");
		else{
			if($times > 0){
				$times--;
				if($this->debug) echo "is NOT $strUKSiteID site now. do switch has $times chances.<br> \n";
				//is NOT $strUKSiteID site now. do switch			
				return $this->SwitchWebgainsToSelectWebSiteNew(true, $times);
			}else{
				mydie("die: SwitchWebgainsToSelectWebSite failed, try 3 times.\n");
			}
		}
	}
	
	function GetProgramByPage()
	{
		$objProgram = new ProgramDb();
		$arr_prgm = array();
		//step 1,login
		$this->oLinkFeed->LoginIntoAffService($this->info["AffId"],$this->info);
		$this->SwitchWebgainsToSelectWebSite();

		//step 2,get all exists merchant
		//$arrAllExistsMerchants = $this->oLinkFeed->GetAllExistsAffMerIDForCheckByAffID($this->info["AffId"]);

		$request = array("AffId" => $this->info["AffId"],"method" => "post","postdata" => "",);

		print "<br>\n Get Merchant List   <br>\n";
		$request["postdata"] = "action=list&updatenumperscreen=1&sortby=liveDate&sortdir=desc&numperpage=0";
		$strUrl = "http://us.webgains.com/affiliates/program.html";
		$r = $this->oLinkFeed->GetHttpResult($strUrl,$request);
		$result = $r["content"];
	
		
		//parse HTML
		$strLineStart = '<td style="text-align:left;"><a href="/affiliates/program.html?action=view&programID=';

		$nLineStart = 0;
		while ($nLineStart >= 0){
			//print "Process $Cnt  ";
			$nLineStart = stripos($result, $strLineStart, $nLineStart);
			if ($nLineStart === false) {
				break;
			}
			
			// ID 	Name 	EPC 	Status
			//ID
			$strMerID = $this->oLinkFeed->ParseStringBy2Tag($result, 'programID=', '"', $nLineStart);
			if($strMerID === false) continue;
			$strMerID = trim($strMerID);

			//name
			$strMerName = $this->oLinkFeed->ParseStringBy2Tag($result, array('<span style', '">'), '</span>', $nLineStart);
			if($strMerName === false) mydie("die: parse merchant name failed.");
			$strMerName = trim($strMerName);
			$strMerName = html_entity_decode($strMerName);

			$arr_pattern = array();
			for($i=0;$i<5;$i++) $arr_pattern[] = "<td";
			$arr_pattern[] = '>';

			//EPC
			$strEPC = $this->oLinkFeed->ParseStringBy2Tag($result,$arr_pattern,'</td>',$nLineStart);
			$strEPC = trim($strEPC);
			if (strpos($strEPC, 'n/a') !== false) $strEPC = 0;
			else $strEPC = html_entity_decode($strEPC);
			
			//country
			$TargetCountryExt = $this->oLinkFeed->ParseStringBy2Tag($result,'/images/lang_','.gif',$nLineStart);
			
			//Status
			$strStatus_block = $this->oLinkFeed->ParseStringBy2Tag($result,'<td style="width:60px;" nowrap>', '</td>', $nLineStart);
			$strStatus = trim(strip_tags($strStatus_block));

			if (stripos($strStatus, 'LEAVE') !== false){
				$Partnership = 'Active';
				$StatusInAff = "Active";
			}
			elseif (stripos($strStatus, 'JOIN') !== false){
				$Partnership = 'NoPartnership';
				$StatusInAff = "Active";
			}
			elseif (stripos($strStatus, 'MORE') !== false){
				$Partnership = 'NoPartnership';
				$StatusInAff = "Active";
			}
			elseif (stripos($strStatus, 'Suspended') !== false){
				$Partnership = 'Expired';
				$StatusInAff = "Active";
			}
			elseif (stripos($strStatus, 'REAPPLY') !== false){
				$Partnership = 'Declined';
				$StatusInAff = "Active";
			}
			elseif (stripos($strStatus, 'Application under consideration') !== false){
				$Partnership = 'Pending';
				$StatusInAff = "Active";
			}
			elseif (stripos($strStatus, 'Membership under review') !== false){
				$Partnership = 'Pending';
				$StatusInAff = "Active";
			}
			else mydie("die: unknown Status: $strStatus \n");			
			
			//$this->oLinkFeed->fixEnocding($this->info,$arr_update,"merchant");
			//if($this->oLinkFeed->UpdateMerchantToDB($arr_update,$arrAllExistsMerchants)) $arr_return["UpdatedCount"] ++;
			
			//program
			//program_detail
			$prgm_url = "http://us.webgains.com/affiliates/program.html?action=view&programID=$strMerID";
			$prgm_arr = $this->oLinkFeed->GetHttpResult($prgm_url, $request);
			$prgm_detail = $prgm_arr["content"];
			
			$prgm_line = 0;
			
			/*if($strStatus == 'approval') $Partnership = 'Active';
			elseif($strStatus == 'not apply') $Partnership = 'NoPartnership';
			elseif($strStatus == 'siteclosed') $Partnership = 'Expired';
			elseif($strStatus == 'declined') $Partnership = 'Declined';
			elseif($strStatus == 'pending') $Partnership = 'Pending';
			else $Partnership = 'NoPartnership';*/
				
			$desc = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<td><b>Description</b></td>', '<td>'), '</td>'));
			$keywords = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<td><b>Keywords</b></td>', '<td>'), '</td>'));
			$Homepage = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<td><b>URL</b></td>', 'href="'), '"'));
			$Contacts = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('(Account Manager)</td>', '<td>'), '</td>'));
			$JoinDate = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<td><b>Date Live</b></td>', '<td>'), '</td>'));
			$JoinDate = date("Y-m-d H:i:s", strtotime($JoinDate));
			$CreateDate = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<td><b>Member Since</b></td>', '<td>'), '</td>'));			
			$CreateDate = $CreateDate ? date("Y-m-d H:i:s", strtotime($CreateDate)) : '';
			$ReturnDays = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<td><b>Cookie Length</b></td>', '<td>'), '</td>'));
			$ReturnDays = preg_replace("/[^0-9]/", "", $ReturnDays);
			$CouponCodesPolicyExt = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<td><b>Voucher code enabled</b></td>', '<td>'), '</td>'));
			$CommissionExt = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<td><b>Commissions</b></td>', '<td>'), '</table>'));
			
			//egg's pain
			$CommissionExt = preg_replace("/[\\r|\\n|\\r\\n|\\t]/is", '', $CommissionExt);
			$CommissionExt = preg_replace('/<([a-z]+?)\s+?.*?>/i','<$1>', $CommissionExt);
			preg_match_all('/<([a-z]+?)>/i', $CommissionExt, $res_s);				
			preg_match_all('/<\/([a-z]+?)>/i', $CommissionExt, $res_e);
			$tags_arr = array();
			foreach($res_s[1] as $v){
				if(strtolower($v) != "br"){
					if(isset($tags_arr[$v])){
						$tags_arr[$v] += 1;
					}else{
						$tags_arr[$v] = 1;
					}
				}				
			}
			foreach($res_e[1] as $v){
				if(strtolower($v) != "br"){
					$tags_arr[$v] -=1;
				}
			}
			foreach($tags_arr as $k => $v){
				for($i = 0; $i < $v; $i++){
					$CommissionExt .= "</$k>";
				}
			}
			
			$SEMPolicyExt = "Paid Search Policy : " . trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<td><b>Paid Search Policy</b></td>', '<td>'), '</td>'));
			$SEMPolicyExt .= ", Keyword Restrictions : " . trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<td><b>Keyword Restrictions</b></td>', '<td>'), '</td>'));			
	
			//echo "<hr>".trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<td><b>Commissions</b></td>', '<td>'), '<div class="hint">'));
			$arr_prgm[$strMerID] = array(
				"Name" => addslashes(html_entity_decode(trim($strMerName))),
				"AffId" => $this->info["AffId"],				
				"Contacts" => addslashes($Contacts),
				"IdInAff" => $strMerID,				
				"JoinDate" => $JoinDate,
				"StatusInAffRemark" => $strStatus,
				"StatusInAff" => $StatusInAff,						//'Active','TempOffline','Offline'
				"Partnership" => $Partnership,						//'NoPartnership','Active','Pending','Declined','Expired','WeDeclined'				
				"CreateDate" => $CreateDate,				
				"Description" => addslashes($desc),
				"Homepage" => $Homepage,
				"CommissionExt" => addslashes($CommissionExt),				
				"CookieTime" => $ReturnDays,
				"TargetCountryExt" => addslashes($TargetCountryExt),
				"SEMPolicyExt" => addslashes($SEMPolicyExt),
				"LastUpdateTime" => date("Y-m-d H:i:s"),
				"DetailPage" => $prgm_url,
			);
			//print_r($arr_prgm);
			//exit;
			if(count($arr_prgm) >= 100){
				$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
				$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
				$arr_prgm = array();
			}			
		}
		if(count($arr_prgm)){
			$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
			$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
			unset($arr_prgm);
		}
		
		$objProgram->setCountryInt($this->info["AffId"]);
		
		$this->checkProgramOffline($this->info["AffId"]);
		//$objProgram->setProgramOffline($this->info["AffId"]);		
	}
	
	function GetProgramFromAff()
	{		
		$check_date = date("Y-m-d H:i:s");
		echo "Craw Program start @ {$check_date}\r\n";
		
		$this->GetProgramByApi();
		$this->checkProgramOffline($this->info["AffId"], $check_date);
		
		echo "Craw Program end @ ".date("Y-m-d H:i:s")."\r\n";
	}
	
	function GetProgramByApi()
	{
		echo "\tGet Program by api start\r\n";
		$objProgram = new ProgramDb();
		$arr_prgm = array();
		$program_num = 0;

		$campaignid = $this->getSiteId();

		//step 1,login
		$this->info["AffLoginUrl"] = "http://www.webgains.com/loginform.html?action=login";
		$this->info["AffLoginVerifyString"] = "Ran Chen";
		$this->info["AffLoginSuccUrl"] = "http://www.webgains.com/publisher/$campaignid";
		//$this->info["port"] = 443;
		$this->oLinkFeed->LoginIntoAffService($this->info["AffId"],$this->info);
		$this->SwitchWebgainsToSelectWebSiteNew();
		$request = array("AffId" => $this->info["AffId"],"method" => "get","postdata" => "");

		// get SupportDeepurl
		/*$str_url = "http://www.webgains.com/publisher/$campaignid/ad/index/create-ad/";
		$tmp_arr = $this->oLinkFeed->GetHttpResult($str_url, $request);
		$result = $tmp_arr["content"];
		$result = trim($this->oLinkFeed->ParseStringBy2Tag($result, array('linkGenerator', 'programs: ['), ']'));

		$matches = array();
		preg_match_all('/"key":(\d+),/', $result, $matches);
		$hasSupportDeepurl = false;
		$SupportDeepurl_arr = array();
		
		if(count($matches) && isset($matches[1]) && count($matches[1]) > 100){
			$hasSupportDeepurl = true;
			$SupportDeepurl_arr = array_flip($matches[1]);
		}*/
		
		$request_arr = array('username' => "info@couponsnapshot.com",
							'password' => "Ui%0bf8*fhdh",
							'campaignid' => $campaignid);

		$client  = new SoapClient(INCLUDE_ROOT."wsdl/webgains.wsdl", array('trace'=> true));
		$results = $client->__soapCall("getProgramsWithMembershipStatus", $request_arr);
		if(count($results))
		{
			foreach($results as $v)
			{
				$strMerID = intval($v->programID);
				if(!$strMerID)
					continue;

				$TargetCountryExt = trim(str_ireplace("Webgains", "", $v->programNetworkName));
				$strMerName = trim($v->programName);
				$strStatus = $v->programMembershipStatusName;

				if (stripos($strStatus, 'Live') !== false || $strStatus == 'Joined')
				{
					$Partnership = 'Active';
					$StatusInAff = "Active";
				}
				elseif (stripos($strStatus, 'Not joined') !== false)
				{
					$Partnership = 'NoPartnership';
					$StatusInAff = "Active";
				}
				elseif (stripos($strStatus, 'Suspended') !== false)
				{
					$Partnership = 'Expired';
					$StatusInAff = "Active";
				}
				elseif (stripos($strStatus, 'Rejected') !== false)
				{
					$Partnership = 'Declined';
					$StatusInAff = "Active";
				}
				elseif (stripos($strStatus, 'siteclosed') !== false)
				{
					$Partnership = 'Active';
					$StatusInAff = "Offline";
				}
				else{
					$Partnership = 'NoPartnership';
					$StatusInAff = "Active";
				}
				$desc = $v->programDescription;

				if($strMerName == "closed") {
					$strMerName = str_ireplace("closed", "", $strMerName);
					$strStatus = "closed";
					$StatusInAff = "Offline";
				}

				//program_detail
				//because webgains api is not complated, get info based on website
				//$prgm_url = "http://us.webgains.com/affiliates/program.html?action=view&programID=$strMerID";
				$prgm_url = "http://www.webgains.com/publisher/{$campaignid}/program/view?programID=$strMerID";
				//$prgm_url = "http://www.webgains.com/affiliates/{$campaignid}/program/view?programID={$strMerID}";
				$prgm_arr = $this->oLinkFeed->GetHttpResult($prgm_url, $request);
				$prgm_detail = $prgm_arr["content"];
				
				$Contacts = trim(strip_tags($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('Contact details','Account manager:'), '</h2>')));
				$Contacts .= ", Email: ".trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('Account manager','mailto:'), '"'));
				
				$ReturnDays = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('Cookie period:','<h2>'), '</h2>'));
				$ReturnDays = preg_replace("/[^0-9]/", "", $ReturnDays);
				
				$SEMPolicyExt = "PPC Policy Overview:". trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, 'PPC Policy Overview:', '<br/>'));
				$SEMPolicyExt .= ", Keyword policy details:". trim(strip_tags($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('id="keywordPolicyBox"', '<div class="modal-body">'), '</div>'))); 
				
				$CommissionExt = trim(strip_tags($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('Commission details', '<h2>'), '<span')));
				
				//check support deep_links_	
				$deep_arr = array();			
				$deep_arr = $this->oLinkFeed->GetHttpResult("http://www.webgains.com/front/publisher/program/get-tools/programid/$strMerID", $request);				
				$tmp_obj = new stdClass();
				$tmp_obj = json_decode($deep_arr["content"]);				
				if(@$tmp_obj->deep_links == "Allowed"){
					$SupportDeepurl = "YES";
				}else{
					$SupportDeepurl = "NO";
				}

				/*$Contacts = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('(Account Manager)</td>', '<td>'), '</td>'));				
				$JoinDate = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<td><b>Date Live</b></td>', '<td>'), '</td>'));
				$JoinDate = date("Y-m-d H:i:s", strtotime($JoinDate));
				$CreateDate = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<td><b>Member Since</b></td>', '<td>'), '</td>'));
				$CreateDate = $CreateDate ? date("Y-m-d H:i:s", strtotime($CreateDate)) : '';
				$ReturnDays = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<td><b>Cookie Length</b></td>', '<td>'), '</td>'));
				$ReturnDays = preg_replace("/[^0-9]/", "", $ReturnDays);
				$CouponCodesPolicyExt = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<td><b>Voucher code enabled</b></td>', '<td>'), '</td>'));
				$CommissionExt = trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<td><b>Commissions</b></td>', '<td>'), '</table>'));
				$SEMPolicyExt = "Paid Search Policy : " . trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<td><b>Paid Search Policy</b></td>', '<td>'), '</td>'));
				$SEMPolicyExt .= ", Keyword Restrictions : " . trim($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, array('<td><b>Keyword Restrictions</b></td>', '<td>'), '</td>'));

				*/

				//if(empty($Contacts) && empty($CouponCodesPolicyExt) && empty($CommissionExt)){
				if(empty($Contacts) && empty($CommissionExt)){
					//means program  has 
					$strStatus = "no contact & commission";
					$StatusInAff = "Offline";
				}
				
				$prgm_status = trim(strip_tags($this->oLinkFeed->ParseStringBy2Tag($prgm_detail, '<div class="ribbon-red">', '</div>')));					
				if (stripos($prgm_status, 'Suspended') !== false){
					//$Partnership = 'Expired';
					$StatusInAff = "Offline";
					$strStatus = $prgm_status;
				}
				elseif (stripos($prgm_status, 'Rejected') !== false){
					$Partnership = 'Declined';
					$StatusInAff = "Active";
					$strStatus = $prgm_status;
				}				
				
				/*$CommissionExt = preg_replace("/[\\r|\\n|\\r\\n|\\t]/is", '', $CommissionExt);
				$CommissionExt = preg_replace('/<([a-z]+?)\s+?.*?>/i','<$1>', $CommissionExt);
				preg_match_all('/<([a-z]+?)>/i', $CommissionExt, $res_s);
				preg_match_all('/<\/([a-z]+?)>/i', $CommissionExt, $res_e);
				$tags_arr = array();
				foreach($res_s[1] as $val){
					if(strtolower($val) != "br"){
						if(isset($tags_arr[$val])){
							$tags_arr[$val] += 1;
						}else{
							$tags_arr[$val] = 1;
						}
					}
				}
				foreach($res_e[1] as $val){
					if(strtolower($val) != "br"){
						$tags_arr[$val] -=1;
					}
				}
				foreach($tags_arr as $k => $val){
					for($i = 0; $i < $val; $i++){
						$CommissionExt .= "</$k>";
					}
				}*/

				
				$arr_prgm[$strMerID] = array(
											"Name" => addslashes(html_entity_decode($strMerName)),
											"AffId" => $this->info["AffId"],
											"Homepage" => addslashes($v->programURL),
											"IdInAff" => $strMerID,
											"Contacts" => addslashes($Contacts),
											"TargetCountryExt" => $TargetCountryExt,
											"StatusInAffRemark" => addslashes($strStatus),
											"StatusInAff" => $StatusInAff,						//'Active','TempOffline','Offline'
											"Partnership" => $Partnership,						//'NoPartnership','Active','Pending','Declined','Expired','WeDeclined'
											"Description" => addslashes($desc),
											//"JoinDate" => $JoinDate,
											//"CreateDate" => $CreateDate,
											"CommissionExt" => addslashes($CommissionExt),
											"CookieTime" => $ReturnDays,
											"SEMPolicyExt" => addslashes($SEMPolicyExt),
											"LastUpdateTime" => date("Y-m-d H:i:s"),
											"DetailPage" => $prgm_url,
											"SupportDeepUrl" => $SupportDeepurl,
											);
				/*if($hasSupportDeepurl){
					if($Partnership == 'NoPartnership'){
						$SupportDeepurl = 'UNKNOWN';
					}else{
						$SupportDeepurl = 'NO';
					}
					if(isset($SupportDeepurl_arr[$strMerID])){
						$SupportDeepurl = 'YES';
					}					
					$arr_prgm[$strMerID]["SupportDeepUrl"] = $SupportDeepurl;
				}*/
				
				$program_num++;
				if(count($arr_prgm) >= 100){
					$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
					$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
					$arr_prgm = array();
				}
			}
			if(count($arr_prgm)){
				$objProgram->updateProgram($this->info["AffId"], $arr_prgm);
				$this->oLinkFeed->saveLogs($this->info["AffId"], $this->file, $arr_prgm);
				unset($arr_prgm);
			}
		}else{
			mydie("die: get info by Api failed.\n");
		}
		echo "\tGet Program by api end\r\n";
		
		if($program_num < 10){
			mydie("die: program count < 10, please check program.\n");
		}
		
		echo "\tUpdate ({$program_num}) program.\r\n";
		echo "\tSet program country int.\r\n";
		$objProgram->setCountryInt($this->info["AffId"]);
	}

	function checkProgramOffline($AffId, $check_date){
		$objProgram = new ProgramDb();
		$prgm = array();
		$prgm = $objProgram->getNotUpdateProgram($this->info["AffId"], $check_date);

		if(count($prgm) > 30){
			mydie("die: too many offline program (".count($prgm).").\n");
		}else{			
			$objProgram->setProgramOffline($this->info["AffId"], $prgm);
			echo "\tSet (".count($prgm).") offline program.\r\n";
		}
	}
}

