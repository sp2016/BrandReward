<?php

/**
 *
 * functions to help parse text(html csv and etc.)
 *
 * @author: liwei
 *
 */

// get the coupon code from the text
function get_linkcode_by_text($text)
{
	$regCodes = array(
			array('reg' => '@Enter\s+(\w+)\s+at@mis', 'group' => 1),
			array('reg' => '@\stype(=|,|:|\s)"?(\w+)"? (as|at)@mis', 'group' => 2),
			array('reg' => '@\scode\s?(=|,|:|\s)\s?"?(\w+)@mis', 'group' => 2),
			array('reg' => '@^code\s?(=|,|:|\s)\s?"?(\w+)@mis', 'group' => 2),
			array('reg' => '@\sDiscount voucher\s?(=|,|:|\s)\s?"?(\w+)@mis', 'group' => 2),
			array('reg' => '@^Discount voucher\s?(=|,|:|\s)\s?"?(\w+)@mis', 'group' => 2),
			);
	foreach ($regCodes as $v)
	{
		if (preg_match($v['reg'], $text, $g))
		{
			$r = $g[$v['group']];
			break;
		}
	}
	if (!empty($r))
	{
		if (strlen($r) < 3)
			return;
		if (preg_match('@(banner|need|needed|required|necessary)@is', $r))
			return;
		return $r;
	}
}

function get_linkcode_by_text_de($text)
{
	$regCodes = array(
			array('reg' => '@\scode\s?(=|,|:|\s)\s?"?(\w+)@mis', 'group' => 2),
			array('reg' => '@^code\s?(=|,|:|\s)\s?"?(\w+)@mis', 'group' => 2),
			array('reg' => '@\sGutscheincode\s?(=|,|:|\s)\s?"?(\w+)@mis', 'group' => 2),
			array('reg' => '@^Gutscheincode\s?(=|,|:|\s)\s?"?(\w+)@mis', 'group' => 2),

	);
	foreach ($regCodes as $v)
	{
		if (preg_match($v['reg'], $text, $g))
		{
			$r = $g[$v['group']];
			break;
		}
	}
	if (!empty($r))
	{
		if (strlen($r) < 3)
			return;
		if (preg_match('@(banner|need|needed|required|necessary)@is', $r))
			return;
		return $r;
	}
}

function parse_time_str($text, $format = null, $lastSecond = false)
{
	$r = '0000-00-00';
	if (empty($text))
		return $r;
	if ($text == '0000-00-00' || $text == '0000-00-00 00:00:00' || $text == 'N/A' || $text == 'NA' || $text == 'ongoing')
		return $r;
	if (empty($format))
	{
		$date = strtotime($text);
		if ($date > 946713600) //2000-1-1 to make sure a real time
		{
			if ($lastSecond)
				return date('Y-m-d 23:59:59', $date);
			else
				return date('Y-m-d 00:00:00', $date);
		}
	}
	else if ($format == 'Y-m-d H:i:s')
	{
		$date = strtotime($text);
		if ($date > 946713600)
			return date('Y-m-d H:i:s', $date);
	}
	else if ($format == 'm-d-Y')
	{
		if (preg_match('@(\d+)-(\d+)-(\d+)@', $text, $g))
		{
			$date = strtotime(sprintf("%s-%s-%s", $g[3], $g[1], $g[2]));
			if ($date > 946713600)
			{
				if ($lastSecond)
					return date('Y-m-d 23:59:59', $date);
				else
					return date('Y-m-d 00:00:00', $date);
			}
		}
	}
	else if ($format == 'd/m/Y')
	{
		if (preg_match('@(\d+)/(\d+)/(\d+)@', $text, $g))
		{
			$date = strtotime(sprintf("%s-%s-%s", $g[3], $g[2], $g[1]));
			if ($date > 946713600)
			{
				if ($lastSecond)
					return date('Y-m-d 23:59:59', $date);
				else
					return date('Y-m-d 00:00:00', $date);
			}
		}
	}
	else if ($format == 'd.m.Y')
	{
		if (preg_match('@(\d+)\.(\d+)\.(\d+)@', $text, $g))
		{
			$date = strtotime(sprintf("%s-%s-%s", $g[3], $g[2], $g[1]));
			if ($date > 946713600)
			{
				if ($lastSecond)
					return date('Y-m-d 23:59:59', $date);
				else
					return date('Y-m-d 00:00:00', $date);
			}
		}
	}
	else if ($format == 'd/m/Y H:i')
	{
		if (preg_match('@(\d+)/(\d+)/(\d+) (\d+):(\d+)@', $text, $g))
		{
			$date = strtotime(sprintf("%s-%s-%s %s:%s:00", $g[3], $g[2], $g[1], $g[4], $g[5]));
			if ($date > 946713600)
				return date('Y-m-d H:i:s', $date);
		}
	}
	else if ($format == 'Y-m-d h:i:s A')
	{
		if (preg_match('@(.*?) (AM|PM)@i', $text, $g))
		{
			$date = strtotime($g[1]);
			if ($date > 946713600)
			{
				if ($g[2] == 'pm' || $g[2] == 'PM')
					$date += 43200;
				return date('Y-m-d H:i:s', $date);
			}
		}
	}
	else if ($format == 'millisecond')
	{
		$millisecond = intval($text);
		if ($millisecond > 0)
		{
			$date = (int)($millisecond / 1000);
			if ($date > 946713600)
				return date('Y-m-d H:i:s', $date);
		}
	}
	return $r;
}

// compatible with older code.
// use fgetcsv_str now.
function csv_string_to_array($content, $delimiter = ",", $line_delimiter = "\n")
{
	$r = array();
	$lines = explode($line_delimiter, $content);
	if (empty($lines) || !is_array($lines))
		return $r;
	$titles = array();
	for($i = 0; $i < count($lines); $i ++)
	{
		$fields = mem_getcsv($lines[$i], $delimiter, '"', '"');
		$line = array();
		if ($i == 0)
		{
			$header = $fields;
			continue;
		}
		else if (is_array($fields))
		{
			foreach ($fields as $k => $field)
			{
				if (!empty($header[$k]))
					$line[$header[$k]] = $field;
				else
					$line[$k] = $field;
			}
			$r[] = $line;
		}
	}
	return $r;
}

// $escape is not supported in some version of php.
// ignored parameter $escape.
function fgetcsv_str($content, $length = 0, $delimiter = ",", $enclosure = '"', $escape = '\\')
{
	$handle = fopen("php://memory", "rw");
	fwrite($handle, $content);
	fseek($handle, 0);
	$header = fgetcsv($handle, 4096,  $delimiter, $enclosure);
	$r = array();
	while($fields = fgetcsv($handle, $length, $delimiter, $enclosure))
	{
		$line = array();
		if (is_array($fields))
		{
			foreach ($fields as $k => $field)
			{
				if (!empty($header[$k]))
					$line[$header[$k]] = $field;
				else
					$line[$k] = $field;
			}
			$r[] = $line;
		}
	}
	fclose($handle);
	return $r;
}

function mem_getcsv($input, $delimiter=',', $enclosure='"', $escape=null, $eol=null)
{
	$temp = fopen("php://memory", "rw");
	fwrite($temp, $input);
	fseek($temp, 0);
	$data = fgetcsv($temp, 4096, $delimiter, $enclosure);
	fclose($temp);
	return $data;
}

function str_force_utf8($str)
{
	return preg_replace('/[^(\x20-\x7F)]*/','', $str);
}

function create_link_htmlcode($link)
{
	if (empty($link['LinkAffUrl']))
		return '';
	$url = $link['LinkAffUrl'];
	if (empty($link['LinkName']))
		$name = $url;
	else
		$name = $link['LinkName'];
	return sprintf('<a href="%s">%s</a>', $url, $name);
}

function create_link_htmlcode_image($link)
{
	if (empty($link['LinkAffUrl']))
		return '';
	$url = $link['LinkAffUrl'];
	if (empty($link['LinkName']))
		$name = $url;
	else
		$name = $link['LinkName'];
	if (!empty($link['LinkImageUrl']))
		return sprintf('<a href="%s"><img src="%s" alt="%s"></a>', $url, $link['LinkImageUrl'], $name);
	return sprintf('<a href="%s">%s</a>', $url, $name);
}
